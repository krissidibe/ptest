import React, { useEffect, useState } from "react";
import {country} from '../../utils/country';
import InputComponent from "./InputComponent";
import { IoMdArrowDropdown } from "react-icons/io";
import { IoMdClose } from "react-icons/io";
import { secteurDatas } from "../../utils/secteur";
function InputDropdownActivityComponent({
  labelClassName = "",
  className = "",
  label = "",
  value = "---",
  inputDrop = false,
  openDrop = false,
  handleClickClose=()=>{},
  handleClick=(item)=>{},
  ...props
}) {
  const statutData =  country
  const sexeData = [
    "Homme",
    "Femme",
     
  ];
const [searchValue, setSearchValue] = useState("")
const [customersFiltered, setCustomersFiltered] = useState<any[]>([])
useEffect(()  =>  {
     
  const datasFilter = secteurDatas.filter((item) => item.toLowerCase().includes(searchValue.toLowerCase()))
  setCustomersFiltered(datasFilter)

 /*  const filtered = customers.find(obj => {
    return obj.name.toLowerCase().includes("z");
  });
  console.log(filtered); */ 
  
    }, [searchValue])
    
    return (
      <div className="flex ">
        <div className="relative flex flex-col w-full">
        <IoMdArrowDropdown className="absolute right-3 opacity-50 bottom-[15px]"/>
          {label != "" && (
            <p className={`mb-[5px]   ${labelClassName}`}>{label}</p>
          )}
          <input
          data-dropdown-toggle="dropdown" 
          value={value}
            className={` bg-[#06060600] border-[1px]  placeholder:text-white placeholder:opacity-40 text-white border-white border-opacity-10  px-4 outline-none w-full h-12 ${className}`}
            {...props}
          />
        </div>
 <div className={` ${!openDrop ? "hidden": ""}  absolute inset-0 bg-black/50`}>

 </div>
        <div  className={`absolute z-40 overflow-y-hidden     my-20 top-20 py-10 mb-30 rounded-xl inset-0 mx-[340px]  bg-gradient-to-b from-[#1f1f1f] to-[#0d0d0d]  ${!openDrop ? "hidden": ""} `}>
         <div className="flex flex-row  justify-between px-10 mt-2 mb-5 text-[21px] font-bold">
         <p>{"Veuillez choisir le secteur d'activité"}</p>
         <IoMdClose 
         onClick={handleClickClose}
         className="w-6 h-6 text-white cursor-pointer "/>
         </div>
          
    <div className="flex-1 px-10 ">
    <InputComponent  value={searchValue} onChange={(e)=>{
            setSearchValue(x=> x=e.target.value)
          }}
          className="rounded-md mb-4 focus:border-[#ffffff]"
          />
    </div>
          <div
            className="h-full px-0 py-2 overflow-y-scroll text-sm text-gray-700 dark:text-gray-200"
            aria-labelledby="dropdownDefaultButton"
          >


            
              {customersFiltered.map((item) => (
              <div key={item} onClick={()=>handleClick(item)} className="block mx-12 border-b-[1px]    border-white/10 hover:bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]  cursor-pointer py-4 dark:hover:text-white">
                <span className="ml-1">{item}</span>
              </div>
            ))}  
          </div>
        </div>
      </div>
    );
  

 
}

export default InputDropdownActivityComponent; 
