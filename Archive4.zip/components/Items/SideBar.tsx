import React from "react";
import { RiDashboardFill } from "react-icons/ri";
import { BsFillCreditCardFill } from "react-icons/bs";
import { PiListBulletsFill } from "react-icons/pi";
import { BsPerson, BsTrash3Fill } from "react-icons/bs";
import useMenuStore from "../../utils/MenuStore";
import { useRouter } from "next/router";



 



function SideBar() { 



  
  const menuIndex = useMenuStore()
  const router = useRouter()
  const showSmallMenu = (router.pathname.toString().split('/').length >=3) || (menuIndex.index == 4) ? true : false
  //const increasePopulation = useMenuStore((state) => state.setMenuIndex)
  return (
    <div className={`h-screen ${showSmallMenu ? "min-w-[100px]" : "xl:min-w-[320px] min-w-[92px]"} select-none flex flex-col bg-[#060606] transition-transform duration-500  border-r-[1px] border-r-[#9a9768]  border-opacity-40 `}>
      <div className="min-h-[100px] flex items-center justify-start space-x-4 border-b-[1px]  text-xl font-bold  border-white border-opacity-20">
      
      <div>
        {showSmallMenu
         ? 
         <img className="h-9 ml-[27px]  mt-2    " src="/images/logo-payme.png" />
        :
      <img className="h-9 ml-[40px] mt-2   " src="/images/logo-payme-complet.png" />
      
        }
      </div>
      
      </div>

      <div className="flex flex-col flex-1 mt-4 space-y-1 overflow-y-scroll ">
        <MenuItem
        isSmallMenu={showSmallMenu}
        index={menuIndex.index}
        indexDefault={0}
        handleClick={()=> {
          menuIndex.setMenuIndex(0)
          router.push("/dashboard")
        }}
        
          icon={
            <RiDashboardFill className={`${showSmallMenu ? "absolute    left-[30px] w-10 h-10 mr-6  " :"absolute   left-[30px] w-10 h-10 mr-6 xl:static"}`} />
          }
          name={"Accueil"}
        />
        <MenuItem
        isSmallMenu={showSmallMenu}
        index={menuIndex.index}
        indexDefault={1}
        handleClick={ ()=>{
          menuIndex.setMenuIndex(1)
          router.push("/finances")
        }}
          icon={
            <BsFillCreditCardFill className={`${showSmallMenu ? "absolute  left-[30px] w-10 h-10 mr-6  " :"absolute  left-[30px] w-10 h-10 mr-6 xl:static"}`} />
          }
          name={"Finances"}
        />
        <MenuItem
        isSmallMenu={showSmallMenu}
        index={menuIndex.index}
        indexDefault={2}
        handleClick={()=> {
          menuIndex.setMenuIndex(2)
          router.push("/gestions")
        }}
          icon={
            <PiListBulletsFill className={`${showSmallMenu ? "absolute  left-[30px] w-10 h-10 mr-6  " :"absolute  left-[30px] w-10 h-10 mr-6 xl:static"}`} />
          }
          name={"Gestions"}
        />
        <MenuItem
        isSmallMenu={showSmallMenu}
        index={menuIndex.index}
        indexDefault={3}
        handleClick={()=> {
          menuIndex.setMenuIndex(3)
          router.push("/setting")
        }}
          icon={<BsPerson className={`${showSmallMenu ? "absolute  left-[30px] w-10 h-10 mr-6  " :"absolute  left-[30px] w-10 h-10 mr-6 xl:static"}`} />}
          name={"Compte"}
        />
        <div className="flex-1"></div>
        <MenuItem
        isSmallMenu={showSmallMenu}
        index={menuIndex.index}
        indexDefault={4}
        handleClick={()=> {
          menuIndex.setMenuIndex(4)
          router.push("/trash")
        }}
          icon={<BsTrash3Fill className={`${showSmallMenu ? "absolute  left-[30px] w-10 h-10 mr-6  " :"absolute  left-[26px] w-10 h-10 mr-6 xl:static"}`} />}
          name={"Corbeille"}
        />
        
      </div>
      <div className="mb-14"></div>
    </div>
  );
}

export default SideBar;

function MenuItem({ name, icon,handleClick,indexDefault,index,isSmallMenu=false,className="", }) {
  return (
    <div onClick={handleClick} className={`min-h-[70px] relative ${indexDefault == index ? 'text-primary bg-[#ffffff15] bg-opacity-100' : 'text-[#9e9e9e] bg-gray-400 bg-opacity-10'} flex items-center font-semibold    hover:bg-opacity-10 cursor-pointer bg-opacity-5  text-xl px-10 ${className}`}>
      {icon} <p className={`${isSmallMenu ? "hidden" : "hidden xl:block"} `}>{name}</p>
    </div>
  );
}


//hover:text-primary