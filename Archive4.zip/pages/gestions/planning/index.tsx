import React, { useEffect, useState } from "react";
import InputComponent from "../../../components/UI/InputComponent";
import { BiCheckDouble, BiSearch } from "react-icons/bi";
import { IoMdAddCircle, IoMdClose, IoMdTrash } from "react-icons/io";
import { IoListSharp } from "react-icons/io5";
import { BsCheck, BsCheck2 } from "react-icons/bs";
import { HiPencil } from "react-icons/hi";
import {
  BsFillCalendarCheckFill,
  BsFillCalendar2WeekFill,
} from "react-icons/bs";
import DropdownPlanningItem from "../../../components/menu/DropdownPlanningItem";
import { Menu, Switch } from "@headlessui/react";
import { RiCalendarTodoFill, RiFileEditLine } from "react-icons/ri";
import ButtonComponent from "../../../components/UI/ButtonComponent";
import { MdAccessTimeFilled, MdCalendarViewDay, MdMoreHoriz } from "react-icons/md";
import {
  addNewPlanning,
  deletePlanning,
  fetchAllPlanning,
  updatePlanning,
} from "../../../services/planningService";

import { useGlobalModal } from "../../../utils/use-global-modal";
import {
  addNewPlanningItem,
  deletePlanningItem,
  fetchAllPlanningItem,
  fetchAllWeekPlanningItem,
  searchAllPlanningItem,
  todayAllPlanningItem,
  togglePlanningItem,
  updatePlanningItem,
} from "../../../services/planningItemService";
import { daysFr } from "../../../utils/helpers";
import DropdownPlanningItemOption from "../../../components/menu/DropdownPlanningItemOption";
import { AiFillEye, AiFillEyeInvisible } from "react-icons/ai";
import { useRouter } from "next/router";
function Planning(props) {
  const [colorItemSelect, setColorItemSelect] = useState(0);
  const primariesList = [
    "bg-gray-300",
    "bg-yellow-500",
    "bg-amber-500",
    "bg-purple-500",
    "bg-blue-500",
    "bg-green-500",
  ];
  const primaries = [
    "bg-[#D2D2D2]",
    "bg-[#FFC107]",
    "bg-[#FF9800]",
    "bg-purple-500",
    "bg-blue-500",
    "bg-green-500",
  ];

  const getIconColorIndex = (key) => {
     
    if (key == "gray-300") {
      return 0;
    } else if (key == "yellow-500") {
      return 1;
    } else if (key == "amber-500") {
      return 2;
    } else if (key == "purple-500") {
      return 3;
    } else if (key == "blue-500") {
      return 4;
    } else if (key == "green-500") {
      return 5;
    }

    
  };
  const getIconColor = (key) => {
    let color = "bg-red-400";
    if (key == "bg-[#D2D2D2]") {
      return "bg-gray-500";
    } else if (key == "bg-[#FFC107]") {
      return "bg-[#9E7808]";
    } else if (key == "bg-[#FF9800]") {
      return "bg-[#9e6e26]";
    } else if (key == "bg-purple-500") {
      return "bg-purple-700";
    } else if (key == "bg-blue-500") {
      return "bg-blue-700";
    } else if (key == "bg-green-500") {
      return "bg-green-400";
    }

    return "color";
  };

  const [showIndex, setShowIndex] = useState(0);
  const [addNewListModal, setAddNewListModal] = useState(false);
  const [addNewItem, setAddNewItem] = useState(false);
  const [doneTodo, setDoneTodo] = useState(false);
  const [showItmeTodo, setShowItmeTodo] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isNewListItem, setIsNewListItem] = useState(true);
  const [isLoadingItem, setIsLoadingItem] = useState(true);
  const modal = useGlobalModal();

  const [planning, setPlanning] = useState<Planning[]>([]);
  const [planningItem, setPlanningItem] = useState<PlanningItem[]>([]);
  const [currentplanning, setCurrentPlanning] = useState<Planning>();
  const [currentplanningModal, setCurrentPlanningModal] = useState<Planning>();
  //searchAllPlanningItem

  const [searchValue, setSearchValue] = useState("");
  const [time, setTime] = useState("");
  const [showToday, setShowToday] = useState(false);
  const [showWeek, setShowWeek] = useState(false);
  const [datasFiltered, setDatasFiltered] = useState<any[]>([]);
  const [todayDatas, setTodayDatas] = useState<any[]>([]);
  const [WeekDatas, setWeekDatas] = useState<any[]>([]);
  const router = useRouter();
  const planningInfoDashboard = router.query;
  useEffect(() => {
    if (planningInfoDashboard.id) {
      console.log(planningInfoDashboard);
     
      
    }
    
    (async () => {
      const datas = await searchAllPlanningItem(searchValue);

      const datasToday = await todayAllPlanningItem();
      setTodayDatas((x) => (x = datasToday));




      let date_today = new Date();

  
      let first_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                         - date_today.getDay() +1 ));

let last_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                         - date_today.getDay() + 6 +1));
                       

      const datasWeek = await fetchAllWeekPlanningItem(first_day_of_the_week,last_day_of_the_week);
      setWeekDatas(x=> x= datasWeek)



      setDatasFiltered((x) => (x = datas));
      
 
      setShowToday((x) => (x = false));
    })();
  }, [searchValue, isLoadingItem]);

  const [currentplanningItem, setCurrentPlanningItem] = useState<PlanningItem>({
    name: "",
    color: "",
    content: "",
    date: null,
    isCompleted: false,
  });
  const handleChangeItem = (e) => {
    const { name, value } = e.target;
    setCurrentPlanningItem((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const [listName, setListName] = useState("");
  useEffect(() => {
    (async () => {
      //const dataProjects = await fetchAllProject();
      //setProjects(dataProjects);
      setPlanningItem(await fetchAllPlanningItem(currentplanning?.id));

      setIsLoadingItem(false);
    })();

    return () => {};
  }, [isLoadingItem]);


  const fetchWeekAllDatas = async (startAt,endAt) => {
  
    const datas = await fetchAllWeekPlanningItem(startAt,endAt);
    setWeekDatas(x=> x= datas)
    
    setDoneTodo((x) => (x = false));
    setDatasFiltered((x) => (x = datas as any));

 

    setShowWeek((x) => (x = true));
  };
  const fetchTodayAllDatas = async () => {
 setShowIndex(x=> x= 1);
    setShowWeek(x => x = false)
    const datas = await todayAllPlanningItem();
    setDoneTodo((x) => (x = false));
    setDatasFiltered((x) => (x = datas));

    setShowToday((x) => (x = true));
  };

  useEffect(() => {
    (async () => {
      //const dataProjects = await fetchAllProject();
      //setProjects(dataProjects);
      setPlanning(await fetchAllPlanning());

    //  setIsLoading(false);
      setIsLoading(false);
    })();

    return () => {};
  }, [isLoading]);
  return (
    <div className="flex w-full h-full overflow-y-scroll select-none no-scrollbar">
      
      {(addNewListModal || showItmeTodo) && (
        <div
          onClick={() => {
            setAddNewListModal(false);
            setShowItmeTodo(false);
            setListName("");
          }}
          className="absolute inset-0 z-10 flex items-center justify-center opacity-100 bg-black/50 "
        ></div>
      )}

      {showItmeTodo && (
        <div className="absolute inset-0 flex items-center justify-center ">
          <div className="z-50 ">
            <ItemCard isPopup={true} />
          </div>
        </div>
      )}
      {addNewListModal ||
        (addNewItem && (
          <div
            onClick={() => {
              setAddNewListModal(false);
              setAddNewItem(false);
              setListName("");
            }}
            className="absolute inset-0 z-20 flex items-center justify-center bg-black/40 "
          ></div>
        ))}
      {addNewListModal && (
        <div className="absolute inset-0 flex items-center justify-center ">
          <div className="relative bg-[#212121] z-50  w-[520px] p-5 py-6 rounded-xl">
            <div className="flex items-center justify-between">
              {" "}
              <p className="text-xl font-bold">
                {!isNewListItem ? "Modifier la" : "Ajouter une"} liste{" "}
              </p>{" "}
              <IoMdClose
                onClick={() => {
                  setAddNewListModal(false);
                  setListName("");
                }}
                className="w-6 h-6 text-white cursor-pointer "
              />{" "}
            </div>

            <div className="bg-[#323232]/30 gap-4 p-4 mt-4 rounded-md flex justify-center items-center flex-col">
              <div className="flex items-center gap-2 py-4 pr-2">
                
                {primariesList.map((item, index) => (
                  <div
                    onClick={() => {
                      setColorItemSelect((x) => (x = index));
                      setCurrentPlanningItem((prevState) => ({
                        ...prevState,
                        color: primariesList[index],
                      }));
                    }}
                    className={`${primariesList[index]}  ${
                      index == colorItemSelect
                        ? "w-[60px] h-[60px]"
                        : "w-[30px] h-[30px]"
                    } cursor-pointer rounded-full flex items-center justify-center`}
                  >
                    {/*  <IoListSharp className={` ${index == colorItemSelect ? "  w-[45px] h-[45px]" :"  w-[35px] h-[35px]" }       `} /> */}
                  </div>
                ))}
              </div>
              {/*  <div className="flex items-center  justify-center w-[60px] h-[60px]  bg-blue-500 rounded-full">
                <IoListSharp className="w-[45px] h-[45px] " />
              </div> */}
              <InputComponent
                key={300}
                value={listName}
                onChange={(e) => {
                  setListName(e.target.value);
                }}
                placeholder="Nom de la liste"
                className="rounded-[10px] placeholder:text-center  text-[16px] border-opacity-30 focus:border-[#ffffff]"
              />
            </div>

            <div className="flex items-center justify-end w-full gap-5 mt-0">
              {/*     <ButtonComponent
                handleClick={() => {
                  setAddNewListModal(false);
                }}
                label={"Annuler"}
                className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl cursor-pointer shadow-black/20 bg-[#484848] border-none  rounded-md"
              /> */}
              <ButtonComponent
                key={32}
                handleClick={async () => {
                  if (listName.length < 3) {
                    return;
                  }
 
                  setIsLoading(false);
                  const data = !isNewListItem
                    ? await updatePlanning(
                        currentplanningModal?.id,
                        listName,
                        primariesList[colorItemSelect]
                      )
                    : await addNewPlanning({
                        name: listName,
                        color: primariesList[colorItemSelect]
                          .toString()
                          .replace("bg-", ""),
                      });
                  if (data) {
                    setAddNewListModal(false);
                    setIsLoading(true);
                    if (currentplanning?.name != undefined) {
                      currentplanning.name =
                        currentplanning?.id == currentplanningModal?.id
                          ? listName
                          : currentplanning?.name;
                    }

                    setListName("");
                  }
                }}
                label={!isNewListItem ? "Modifier" : "Ajouter"}
                labelClassName="text-[15px]"
                className={`min-h-[46px] w-full mt-6 mb-4 shadow-xl  shadow-black/20 bg-[#9a9768] border-none  rounded-md ${
                  listName.length >= 3
                    ? "opacity-100 cursor-pointer "
                    : "opacity-30 cursor-default  "
                }`}
              />
            </div>
          </div>
        </div>
      )}

      {addNewItem && (
        <div className="absolute inset-0 flex items-center justify-center ">
          <div className="relative bg-[#212121] z-50  w-[520px] p-5 py-6 rounded-xl">
            <div className="flex items-center justify-between">
              {" "}
              <p className="text-xl font-bold">
                {currentplanningItem?.id ? "Modifier" : "Ajouter"} une tâche{" "}
              </p>{" "}
              <div className="flex items-center justify-center gap-8">
                <div className="flex items-center gap-2 pr-2">
                  {primaries.map((item, index) => (
                    <div
                      onClick={() => {
                        setColorItemSelect((x) => (x = index));
                        setCurrentPlanningItem((prevState) => ({
                          ...prevState,
                          color: primaries[index],
                        }));
                      }}
                      className={`${primaries[index]}  ${
                        index == colorItemSelect
                          ? "w-[19px] h-[19px]"
                          : "w-[13px] h-[13px]"
                      } cursor-pointer rounded-full`}
                    ></div>
                  ))}
                </div>

                <div className="flex items-center justify-center">
                  <div className="bg-[#ffffff0c] rounded-full p-1 mr-2 ">
                    <IoMdTrash
                      onClick={async () => {
                        modal.onSubmit = (
                          <ButtonComponent
                            handleClick={async () => {
                              setIsLoadingItem(false);
                              const data = await deletePlanningItem(
                                currentplanningItem?.id
                              );

                              if (data) {
                                modal.onClose();
                                setAddNewItem(false);
                                setIsLoadingItem(true);
                              }
                            }}
                            label={"Supprimer"}
                            className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                          />
                        );
                        modal.onOpen();
                        modal.setTitle("Êtes-vous sûr ?");
                        modal.setMessage(
                          "Voulez-vous vraiment supprimer cette tâche ?"
                        );
                      }}
                      className="w-5 h-5 text-white cursor-pointer opacity-30 hover:opacity-100 "
                    />{" "}
                  </div>
                  <IoMdClose
                    onClick={() => {
                      setAddNewItem(false);
                      setAddNewListModal(false);
                    }}
                    className="w-6 h-6 text-white cursor-pointer "
                  />{" "}
                </div>
              </div>
            </div>

            <div className="bg-[#323232]/30 gap-4 p-4 mt-4 rounded-md flex justify-center items-center flex-col">
              <InputComponent
                key={21}
                placeholder="Titre"
                name="name"
                value={currentplanningItem?.name}
                onChange={handleChangeItem}
                className="rounded-[10px]    text-[16px] border-opacity-30 focus:border-[#ffffff]"
              />
              <InputComponent
                key={22}
                placeholder="Tâche"
                name="content"
                value={currentplanningItem?.content}
                onChange={handleChangeItem}
                className="rounded-[10px]    text-[16px] border-opacity-30 focus:border-[#ffffff]"
              />
            </div>
            <div className="bg-[#323232]/30  gap-6 relative  px-4 py-2 mt-4 rounded-md flex  items-center justify-center ">
              {/*    <RiCalendarTodoFill className="w-[34px] h-[34px] bottom-[10px] text-[#9a9768] absolute " /> */}

              <div className="flex flex-1 flex-col text-[15px]   leading-4">
                <InputComponent
                  key={43}
                  // value= {currentplanningItem.date.toString().substring(0,16)}
                  value={
                    currentplanningItem?.date
                      ? currentplanningItem?.date.toString().substring(0, 10)
                      : null
                  }
                  name="date"
                  type="date"
                  onChange={handleChangeItem}
                  className={`${
                    currentplanningItem?.date == null
                      ? "opacity-50"
                      : "opacity-100"
                  } dark:[color-scheme:dark] w-full mb-0 h-[50px]    rounded-xl text-[14px] font-light border-opacity-30 focus:border-[#ffffff] focus:border-opacity-100  `}
                />
              </div>
              <div className="flex flex-1 flex-col text-[15px] max-w-[120px]  leading-4">
                <InputComponent
                  key={44}
                  // value= {currentplanningItem.date.toString().substring(0,16)}
                  //currentplanningItem?.date.toString().substring(11, 16)
                  value={currentplanningItem?.date ? time : null}
                  //name="date"
                  type="time"
                  onChange={(e) => {
                    setTime(e.target.value);
                  }}
                  className={`${
                    currentplanningItem?.date == null
                      ? "opacity-50"
                      : "opacity-100"
                  } dark:[color-scheme:dark] w-full mb-0 h-[50px]   rounded-xl text-[14px] font-light border-opacity-30 focus:border-[#ffffff] focus:border-opacity-100  `}
                />
              </div>
            </div>

            {/*         <div className="bg-[#323232]/30 gap-4 relative p-4 py-3 mt-4 rounded-md flex  items-center ">
              <RiCalendarTodoFill className="w-[34px] h-[34px] bottom-[10px] text-[#9a9768] absolute " />
              <div className="flex flex-1 flex-col text-[15px] ml-12 leading-4">
                <p>Date</p>
                <p className="text-[#9a9768]">13/6/2023</p>
              </div>
              <Switch
                //checked={enabled}
                //onChange={setEnabled}
                className={`${
                  true ? "bg-[#9a9768]" : "bg-gray-200"
                } relative inline-flex h-6 w-11 items-center rounded-full`}
              >
                <span className="sr-only">Enable notifications</span>
                <span
                  className={`${
                    true ? "translate-x-6" : "translate-x-1"
                  } inline-block h-4 w-4 transform rounded-full bg-white transition`}
                />
              </Switch>
            </div>
            <div className="bg-[#323232]/30 gap-4 relative p-4 py-3 mt-4 rounded-md flex  items-center ">
              <MdAccessTimeFilled className="w-[34px] h-[34px] bottom-[10px] text-[#9a9768] absolute " />
              <div className="flex flex-1 flex-col text-[15px] ml-12 leading-4">
                <p>Heure</p>
                <p className="text-[#9a9768]">13/6/2023</p>
              </div>
              <Switch
                //checked={enabled}
                //onChange={setEnabled}
                className={`${
                  true ? "bg-[#9a9768]" : "bg-gray-200"
                } relative inline-flex h-6 w-11 items-center rounded-full`}
              >
                <span className="sr-only">Enable notifications</span>
                <span
                  className={`${
                    true ? "translate-x-6" : "translate-x-1"
                  } inline-block h-4 w-4 transform rounded-full bg-white transition`}
                />
              </Switch>
            </div>
 */}
            <div className="flex items-center justify-end w-full gap-5 mt-0">
              {/*     <ButtonComponent
                handleClick={() => {
                  setAddNewListModal(false);
                }}
                label={"Annuler"}
                className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl cursor-pointer shadow-black/20 bg-[#484848] border-none  rounded-md"
              /> */}
              <ButtonComponent
                key={101}
                handleClick={() => {
                  setAddNewItem(false);
                }}
                label={"Annuler"}
                labelClassName="text-[15px]"
                className="min-h-[46px] w-full mt-6 mb-4 shadow-xl cursor-pointer shadow-black/20 bg-[#484848] border-none  rounded-md"
              />
              <ButtonComponent
                key={102}
                handleClick={async () => {
 
 
if(time.length <4 || currentplanningItem.date == null || currentplanningItem.name.length < 3 || currentplanningItem.content.length <3){
  return;

}
              
                  const newTime =
                    currentplanningItem.date.toString() + "T" + time;
                  const oldTime =
                    currentplanningItem.date.toString().substring(0, 11) + "T"  + time;

                    const oldTimeFormat = oldTime.replace("TT","T");
                    const finalTime = new Date(
                      currentplanningItem?.id != undefined ? oldTimeFormat : newTime
                      );
                      

                  if (showToday) {
                  
                    currentplanningItem!.date = finalTime;
                  const ddn =  await updatePlanningItem(
                      currentplanningItem?.id,
                      currentplanningItem
                    );

                    if(ddn){
                       
                         await fetchTodayAllDatas();
                         const datasToday = await todayAllPlanningItem();
  
                      setTodayDatas((x) => (x = datasToday));
                      }


                  
                    setAddNewItem((x) => (x = false));
                    setIsLoading((x) => (x = false));
                    return;
                  }
                
                  if (showWeek ) {

                  

                    
                    currentplanningItem!.date = finalTime;
                 
                 const ddn =   await updatePlanningItem(
                      currentplanningItem?.id,
                      currentplanningItem
                    );
                    


                    if(ddn){
                       
                    const datasToday = await todayAllPlanningItem();

                    setTodayDatas((x) => (x = datasToday));
                    }
 
                    

                    let date_today = new Date();

  
                    let first_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                                       - date_today.getDay() +1 ));
        
        let last_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                                       - date_today.getDay() + 6 +1));
                                       await fetchWeekAllDatas(first_day_of_the_week,last_day_of_the_week)

                    setAddNewItem((x) => (x = false));
                    setIsLoading((x) => (x = false));
                    return;
                  }
                
                  setIsLoadingItem((x) => (x = true));
                  currentplanningItem!.date = finalTime;
                  const data = currentplanningItem?.id
                    ? await updatePlanningItem(
                        currentplanningItem?.id,
                        currentplanningItem
                      )
                    : await addNewPlanningItem(
                        currentplanning.id,
                        currentplanningItem
                      );
                  setAddNewItem(false);
                  setIsLoadingItem((x) => (x = false));
                }}
                label={currentplanningItem?.id ? "Modifier" : "Ajouter"}
                labelClassName="text-[15px]"
                className={`min-h-[46px] w-full mt-6 mb-4 shadow-xl cursor-pointer shadow-black/20 bg-[#9a9768] border-none  rounded-md
                
                ${time.length <4 || currentplanningItem.date == null || currentplanningItem.name.length < 3 || currentplanningItem.content.length <3 ? "opacity-30":""}`}
              />
            </div>
          </div>
        </div>
      )}
      {LeftSection()}

      {currentplanning?.id == null && !showToday && !showWeek  && searchValue.length < 3 && (
        <div className="flex text-[30px] text-[#3c3c3c] flex-col items-center justify-center w-full h-full ">
          <p>Aucun rappel</p>
        </div>
      )}
      {(currentplanning != null || searchValue.length >= 3 || showToday ||  showWeek) && (
        <div className="flex flex-col w-full h-full pt-[72px]  overflow-y-scroll no-scrollbar ">
          <div className="flex justify-between w-full pb-4 border-b px-7 border-white/10">
            <p className="text-[32px] font-bold opacity-40">
              {searchValue.length >= 3 && !showToday && !showWeek && "Resultat du recherche"}
              {showIndex == 0 && currentplanning?.name}
              {showIndex == 1 && "Aujourd'hui"} 
              {showIndex == 2 && "Semaine"}
              
             
            </p>
            <div className="flex">
              <DropdownPlanningItemOption className="">
                <Menu.Item>
                  {({ active }) => (
                    <div
                      onClick={() => {
                        setCurrentPlanning((x) => (x = currentplanning));
                        setListName((x) => (x = currentplanning?.name));
                        setCurrentPlanningModal((x) => (x = currentplanning));
                        setIsNewListItem(false);
                        setAddNewListModal(true);
                      }}
                      className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                        active
                          ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                          : " "
                      }`}
                    >
                      <RiFileEditLine className="min-w-10 min-h-10 " />
                      Modifier
                    </div>
                  )}
                </Menu.Item>
                <Menu.Item>
                  {({ active }) => (
                    <div
                      onClick={async () => {
                        setDoneTodo((x) => (x = !x));
                      }}
                      className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                        active
                          ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                          : " "
                      }`}
                    >
                      {!doneTodo ? (
                        <AiFillEye className="min-w-10 min-h-10 " />
                      ) : (
                        <AiFillEyeInvisible className="min-w-10 min-h-10 " />
                      )}
                      Rappels terminés
                    </div>
                  )}
                </Menu.Item>
              </DropdownPlanningItemOption>

              <ButtonComponent
                key={41}
                label={"Ajouter"}
                labelClassName="font-bold text-[15px]"
                handleClick={() => {
                  setTime("")
                  setCurrentPlanningItem({
                    name: "",
                    content: "",
                    date: null,
                    color: primaries[0],
                  });
                  setAddNewItem((x) => (x = true));
                }}
                className="bg-[#9a9768] border-none min-h-[35px] min-w-[110px] font-semibold ml-8"
              />
            </div>
          </div>

          <div className="flex flex-col overflow-y-scroll no-scrollbar  flex-1 px-10 py-4 pl-[50px]">
            {showToday && doneTodo && (
              <p className="opacity-40 text-[22px]  pb-4">Rappels terminés</p>
            )}
            {(searchValue.length >= 3 ||showIndex > 0) &&
              datasFiltered.map((item, index) => (
                <>
                  {doneTodo &&
                    item.children.filter((item) => item.isCompleted == true)
                      .length != 0 && (
                      <p
                        className={`text-[25px] font-semibold   text-${
                          item.color
                        }  ${
                          index > 0 ? "border-t  pt-2  border-white/10 " : ""
                        }   opacity-100`}
                      >
                        {item.name} 
                      </p>
                    )}

                  {!doneTodo &&
                    item.children.filter((item) => item.isCompleted == false)
                      .length != 0 && (
                      <></>
                    )}
                  {(!doneTodo ||
                    item.children.filter((item) => item.isCompleted == true)
                      .length != 0) && (
                    <div className="mt-0">
                      <div
                        className={`flex flex-row flex-wrap pt-3 pb-5 overflow-y-scroll no-scrollbar gap-2 border-white/10 
                  ${
                    !doneTodo ||
                    item.children.filter((item) => item.isCompleted == true)
                      .length != 0
                      ? " border-b2"
                      : ""
                  }
                 `}
                      >
                        {!doneTodo
                          ? item.children.map((item) => (
                              <div
                                className={`p-1 overflow-hidden ${
                                  item.isCompleted == false ? "flex" : "hidden"
                                } `}
                              >
                                <ItemCard
                                  key={item.id}
                                  item={item}
                                  handleClick={(e) => {
                                    e.stopPropagation();
                                    setCurrentPlanningItem(item);
                                    setShowItmeTodo(true);
                                  }}
                                />
                              </div>
                            ))
                          : item.children.map((item) => (
                              <div
                                className={`p-1 overflow-hidden  ${
                                  item.isCompleted == true ? "flex" : "hidden"
                                }   `}
                              >
                                <ItemCard
                                  key={item.id}
                                  item={item}
                                  handleClick={(e) => {
                                    e.stopPropagation();
                                    setCurrentPlanningItem(item);
                                    setShowItmeTodo(true);
                                  }}
                                />
                              </div>
                            ))}

                        {/*   {item.children.map((item) => (
                      <ItemCard
                        key={item.id}
                        item={item}
                        handleClick={(e) => {
                          e.stopPropagation();
                          setCurrentPlanningItem(item);
                          setShowItmeTodo(true);
                        }}
                      />
                    ))} */}
                      </div>
                    </div>
                  )}
                </>
              ))}

            {searchValue.length < 3 &&  showIndex == 0 && (
              <div className="mt-0">
                <div className="flex flex-row flex-wrap gap-2 pt-3 pb-5 overflow-y-scroll no-scrollbar border-white/10">
                
               
                {!doneTodo && planningItem.filter(i => i.isCompleted == false).length <= 0 && 
                 <div className="flex items-center justify-center w-full h-screen pb-[330px] text-[30px] text-[#3c3c3c]">Aucun contenu</div>}
               {isLoadingItem && [1,2,3,4,5,6,7,8,9,10].map(item=>(

               <ItemCardShimmer  key={item}  />
               )) }
              
         
               
              {!isLoadingItem &&<>
               
               {!doneTodo
                    ? planningItem.map((item) => (
                        <div
                          className={`p-1 overflow-hidden ${
                            item.isCompleted == false ? "flex" : "hidden"
                          } `}
                        >
                          <ItemCard
                            key={item.id}
                            item={item}
                            handleClick={(e) => {
                              e.stopPropagation();
                              setCurrentPlanningItem(item);
                              setShowItmeTodo(true);
                            }}
                          />
                        </div>
                      ))
                    : planningItem.map((item) => (
                        <div className={`p-1 overflow-hidden   `}>
                          <ItemCard
                            key={item.id}
                            item={item}
                            handleClick={(e) => {
                              e.stopPropagation();
                              setCurrentPlanningItem(item);
                              setShowItmeTodo(true);
                            }}
                          />
                        </div>
                      ))}</>}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
  function LeftSection() {
    return (
      <div className=" relative min-w-[401px] max-w-[401px] flex flex-col border-r h-full overflow-y-scroll no-scrollbar pt-[75px] px-5 border-white/10">
        <div className="bg-[#1d1d1d] flex flex-row items-center justify-center p-2 rounded-xl mb-5 ">
          <BiSearch className="w-6 h-6 ml-2 mr-3" />

          <input
            placeholder="Recherche"
            value={searchValue}
            onChange={(e) => {
              setSearchValue(e.target.value);
              setShowToday(x=>x=false);
              setShowWeek(x=>x=false);
              //setCurrentPlanning(x=>x=null);
            }}
            className="w-full bg-transparent rounded-none outline-none placeholder:text-white/70"
          />
        </div>
        <div className="flex justify-between w-full gap-5">
          <div
            onClick={fetchTodayAllDatas}
            className="bg-[#1d1d1d] rounded-xl px-4 py-[10px] w-full cursor-pointer "
          >
            <div className="flex justify-between mb-2">
              <div className="flex items-center justify-center w-[34px] h-[34px] bg-blue-500 rounded-full">
                <RiCalendarTodoFill className="w-[22px] h-[22px] " />
              </div>
              <p className="text-[22px] font-bold">
              {todayDatas[0]?.sizeNotCompleted ?? 0}
             
              </p>
            </div>
            <p className="opacity-30">Aujourd'hui</p>
          </div>
          <div
          
          onClick={ async()=>{
            setShowIndex(x=> x= 2);
            setShowToday(x => x = false)
            setShowWeek(x => x = true)
            let date_today = new Date();

  
            let first_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                               - date_today.getDay() +1 ));

let last_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                               - date_today.getDay() + 6 +1));
                               await fetchWeekAllDatas(first_day_of_the_week,last_day_of_the_week)
 

          }}  
          className="bg-[#1d1d1d] rounded-xl px-4 py-[10px] w-full  cursor-pointer">
            <div className="flex justify-between mb-2">
              <div className="flex items-center justify-center w-[34px] h-[34px] bg-blue-500 rounded-full">
                <MdCalendarViewDay className="w-[22px] h-[22px] " />
              </div>
              <p className="text-[22px] font-bold">{WeekDatas[0]?.size ?? 0}</p>
            </div>
            <p className="opacity-30">Semaine</p>
          </div>
        </div>

        <div className="flex-col flex-1 px-4 mt-5 mb-4 overflow-y-scroll no-scrollbar ">
          {!isLoading && planning.map((item) => (
            <PlanningItem key={item.id} item={item} />
          ))}

          
          {isLoading && [1,2,3,4,5,].map((item) => (
            <PlanningItemShimmer key={item}  />
          ))}
        </div>
       {isLoading ?
       
       <div
          onClick={() => {
            setIsNewListItem(true);
            setAddNewListModal(true);
          }}
          className="absolute flex gap-2 font-bold text-teal-500 cursor-default bottom-16 right-9 rounded-full h-[25px] w-[140px]  animate-pulse duration-100    bg-[#ffffff1f] "
        >
       
        </div>
       : <div
          onClick={() => {
            setIsNewListItem(true);
            setAddNewListModal(true);
          }}
          className="absolute flex gap-2 font-bold text-teal-500 cursor-pointer bottom-16 right-6"
        >
          <p>Ajouter une liste </p>
          <IoMdAddCircle className="w-6 h-6 " />
        </div>}
      </div>
    );
  }
  function ItemCardShimmer({ item = null, handleClick = (e) => {}, isPopup = false }) {
    return (
     <div className="pt-1 overflow-hidden">
       <div
        onClick={handleClick}
        className={` cursor-pointer   relative flex flex-col animate-pulse duration-100    bg-[#ffffff1f]   px-6 pt-5 pb-5 ${
          isPopup
            ? " max-w-[420px]  min-w-[420px]  min-h-[420px]   rounded-md"
            : " w-[230px] h-[230px]"
        } `}
      >
        {!isPopup && (
          //060606
          <>
         
            <div className="absolute z-10 rotate-45 bg-[#060606] w-[40px] h-[40px] -top-5 -right-5 "></div>
            <div className="absolute z-40 rotate-30 bg-[#0606064b] w-[29px] h-[29px] top-0 right-0 "></div>
          </>
        )}
      
        
      </div>
     </div>
    );
  }
  function ItemCard({ item = null, handleClick = (e) => {}, isPopup = false }) {
    return (
      <div
        onClick={handleClick}
        className={` cursor-pointer   relative flex flex-col ${
          item?.color ?? currentplanningItem?.color
        } text-black px-6 pt-5 pb-5 ${
          isPopup
            ? " max-w-[420px]  min-w-[420px]  min-h-[420px]   rounded-md"
            : " w-[230px] h-[230px]"
        } `}
      >
        {!isPopup && (
          //060606
          <>
            {/*  <div className="absolute z-20 rotate-45 bg-[#5740ef] w-[20px] h-[20px] -top-[9px] right-[5px] "></div>
             <div className="absolute z-20 rotate-45 bg-[#ef5240] w-[20px] h-[20px] bottom-[198px] -right-[3px] top-[14px] "></div> */}
            <div className="absolute z-10 rotate-45 bg-[#060606] w-[40px] h-[40px] -top-5 -right-5 "></div>
            <div className="absolute z-40 rotate-30 bg-[#0606064b] w-[29px] h-[29px] top-0 right-0 "></div>
          </>
        )}
        <p className="font-bold  line-clamp-2 text-[18px] leading-5 mb-1">
          {item?.name ?? currentplanningItem?.name}
        </p>
        <p className="flex-1 pt-2  mb-2  overflow-hidden text-[13.5px] leading-4 font-normal overscroll-y-scroll ">
          {item?.content ?? currentplanningItem?.content}
        </p>
        <div className="flex items-end justify-between">
          <div className="flex flex-col leading-4 ">
            {isPopup ? (
              <>
                <p className="text-[15px] font-normal">
                  {currentplanningItem?.date?.toString().substr(11, 5)}
                </p>
                <p className="text-[15px] font-normal">
                  {" "}
                  {daysFr(currentplanningItem?.date)}
                </p>
              </>
            ) : (
              <>
                <p className="text-[15px] font-normal">
                  {item?.date?.toString().substr(11, 5)}
                </p>
                <p className="text-[15px] font-normal"> {daysFr(item?.date)}</p>
              </>
            )}
          </div>
          <div className="flex gap-1 ">
            {!isPopup && (
              <div
                onClick={async (e) => {
                  e.stopPropagation();

                  if (!isPopup) {
                    await togglePlanningItem(
                      item.id,
                      item.isCompleted == true ? false : true
                    );

                    if (showToday) {
                      await updatePlanningItem(
                        currentplanningItem?.id,
                        currentplanningItem
                      );
                      await fetchTodayAllDatas();
                      setAddNewItem((x) => (x = false));
                      setIsLoading((x) => (x = false));
                      return;
                    }
                    setIsLoadingItem((x) => (x = true));
                    await updatePlanningItem(
                      currentplanningItem?.id,
                      currentplanningItem
                    );

                    setAddNewItem(false);
                    setIsLoadingItem((x) => (x = false));
                  } else {
                    await togglePlanningItem(
                      currentplanningItem.id,
                      currentplanningItem.isCompleted == true ? false : true
                    );

                    if (showToday) {
                      await updatePlanningItem(
                        currentplanningItem?.id,
                        currentplanningItem
                      );
                      await fetchTodayAllDatas();
                      setAddNewItem((x) => (x = false));
                      setIsLoading((x) => (x = false));
                      return;
                    }
                    setIsLoadingItem((x) => (x = true));
                    await updatePlanningItem(
                      currentplanningItem?.id,
                      currentplanningItem
                    );

                    setAddNewItem(false);
                    setIsLoadingItem((x) => (x = false));
                  }
                }}
                className={`flex items-center justify-center rounded-full cursor-pointer w-9 h-9 ${
                  item?.isCompleted == true
                    ? getIconColor(item?.color).toString()
                    : "bg-[#00000028]"
                }  `}
              >
                {item?.isCompleted == true ? (
                  <BiCheckDouble className="w-6 h-6 text-white" />
                ) : (
                  <BsCheck className="w-6 h-6 text-white" />
                )}
              </div>
            )}

            {isPopup && (
              <div
                onClick={async (e) => {
                  e.stopPropagation();

                  await togglePlanningItem(
                    currentplanningItem.id,
                    currentplanningItem.isCompleted == true ? false : true
                  );

                  if (showToday) {
                    await updatePlanningItem(
                      currentplanningItem?.id,
                      currentplanningItem
                    );
                    await fetchTodayAllDatas();
                    setAddNewItem((x) => (x = false));
                    setIsLoading((x) => (x = false));
                    currentplanningItem.isCompleted =
                      !currentplanningItem.isCompleted;
                    setCurrentPlanningItem(currentplanningItem);
                    return;
                  }
                  setIsLoadingItem((x) => (x = true));
                  await updatePlanningItem(
                    currentplanningItem?.id,
                    currentplanningItem
                  );

                  setAddNewItem(false);
                  setIsLoadingItem((x) => (x = false));
                  currentplanningItem.isCompleted =
                    !currentplanningItem.isCompleted;
                  setCurrentPlanningItem(currentplanningItem);
                  //  setShowItmeTodo((x) => (x = false));
                }}
                className={`flex items-center justify-center rounded-full cursor-pointer w-9 h-9 ${
                  currentplanningItem?.isCompleted == true
                    ? "bg-gray-500"
                    : "bg-[#00000028]"
                }  `}
              >
                {" "}
                <BsCheck className="w-6 h-6 text-white" />
              </div>
            )}
            {item?.isCompleted == false && (
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  if (!isPopup) {
                    setCurrentPlanningItem((x) => (x = item));
                  }
                  setTime(item?.date?.toString().substring(11, 16));
                  setAddNewItem((x) => (x = true));
                }}
                className="flex items-center justify-center bg-black rounded-full cursor-pointer w-9 h-9"
              >
                {" "}
                <HiPencil className="w-[18px] h-[18px] text-white" />
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  function PlanningItemShimmer() {
    return (
      <div className="relative flex items-center border-b cursor-pointer border-white/10">
   
        <p
         
          className="flex-1 py-3 pl-0 leading-10 line-clamp-1"
        >
           <div className="text-[#9a9768] text-[18px] font-bold  rounded-full h-[40px] max-w-[200px]  animate-pulse duration-100     py-[8px]  ">
           <h2 className="text-[#9a9768] text-[18px] font-bold h-full  rounded-full w-[220px]  animate-pulse duration-100    bg-[#ffffff1f] "></h2>
          
         
           </div>
          
         
        </p>
        <div className='rounded-full p-1  animate-pulse duration-100    bg-[#ffffff1f]'> 
     <div className="w-5 h-5 opacity-60 hover:opacity-100" ></div>
     </div>
      </div>
    );
  }

  function PlanningItem({ item }) {
    return (
      <div className="relative flex items-center border-b cursor-pointer border-white/10">
        <div
          onClick={() => {

            setShowIndex((x) => (x = 0));
            setDoneTodo((x) => (x = false));
            setSearchValue((x) => (x = ""));
            setShowToday((x) => (x = false));
            setShowWeek((x) => (x = false));
            setIsLoadingItem((x) => (x = false));
            setCurrentPlanning((x) => (x = item));
            setIsLoadingItem((x) => (x = true));
          }}
          className={`flex items-center justify-center w-8 h-8  bg-${item.color} rounded-full`}
        >
          <IoListSharp className="w-6 h-6 " />
        </div>
        <p
          onClick={() => {

            setShowIndex((x) => (x = 0));
            setDoneTodo((x) => (x = false));
            setSearchValue((x) => (x = ""));
            setShowToday((x) => (x = false));
            setShowWeek((x) => (x = false));
            setIsLoadingItem((x) => (x = false));
            setCurrentPlanning((x) => (x = item));
            setIsLoadingItem((x) => (x = true));
          }}
          className="flex-1 py-3 pl-4 leading-10 line-clamp-1"
        >
          {item.name}
        </p>
        <DropdownPlanningItem className="">
          <Menu.Item>
            {({ active }) => (
              <div
                onClick={(e) => {
                  e.stopPropagation();
                
                  setColorItemSelect(x => x =getIconColorIndex(item.color))
               
                  setCurrentPlanningModal((x) => (x = item));
                  setListName((x) => (x = item.name));
                  setIsNewListItem(false);
                  setAddNewListModal(true);
                }}
                className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                  active
                    ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                    : " "
                }`}
              >
                <RiFileEditLine className="min-w-10 min-h-10 " />
                Modifier
              </div>
            )}
          </Menu.Item>
          <Menu.Item>
            {({ active }) => (
              <div
                onClick={async () => {
                  modal.onSubmit = (
                    <ButtonComponent
                      handleClick={async () => {
                        setIsLoading(true);
                        setIsLoadingItem(false);
                        const data = await deletePlanning(item.id);

                        if (data) {
                          modal.onClose();
                          setIsLoading(true);
                          setIsLoadingItem(true);
                          setCurrentPlanning(
                            (x) =>
                              (x =
                                currentplanning?.id == item.id
                                  ? null
                                  : currentplanning)
                          );
                        }
                      }}
                      label={"Supprimer"}
                      className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                    />
                  );
                  modal.onOpen();
                  modal.setTitle("Êtes-vous sûr ?");
                  modal.setMessage(
                    "Voulez-vous vraiment supprimer cette liste ?"
                  );
                }}
                className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                  active
                    ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                    : " "
                }`}
              >
                <IoMdTrash className="min-w-10 min-h-10 " />
                Supprimer
              </div>
            )}
          </Menu.Item>
        </DropdownPlanningItem>
      </div>
    );
  }
}

export default Planning;
