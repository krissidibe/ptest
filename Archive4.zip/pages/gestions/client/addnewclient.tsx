import React, { useEffect, useState } from "react";
import {
  IoIosNotifications,
  IoIosPeople,
  IoIosRefresh,
  IoMdTrash,
} from "react-icons/io";
import ButtonComponent from "../../../components/UI/ButtonComponent";
import InputComponent from "../../../components/UI/InputComponent";
import { PiListBulletsFill } from "react-icons/pi";
import FolderComponent from "../../../components/UI/FolderComponent";
import { HiFolder } from "react-icons/hi";
import { BiSolidDashboard } from "react-icons/bi";
import { IoIosArrowBack } from "react-icons/io";
import { useRouter } from "next/router";
import InputDropdownCountryComponent from "../../../components/UI/InputDropdownCountryComponent";
import { useGlobalModal } from "../../../utils/use-global-modal";
import InputDropdownActivityComponent from "../../../components/UI/InputDropdownActivityComponent";

function AddNewClient() {
  const [isLoading, setIsLoading] = useState(false);
  const [indexView, setIndexView] = useState(0);
  const modal = useGlobalModal();
  const router = useRouter();
  const customerInfo: any = router.query;
  console.log(customerInfo);
  const [data, setData] = useState<Customer>({
    externalContact: customerInfo.externalContact ?? "",
    externalEmail: customerInfo.externalEmail ?? "",
    externalName: customerInfo.externalName ?? "",
    poste: customerInfo.poste ?? "",
    activity: customerInfo.activity ?? "",
    address: customerInfo.address ?? "",
    country: customerInfo.country ?? "",
    email: customerInfo.email ?? "",
    image: customerInfo.image ?? "",
    name: customerInfo.name ?? "",
    type: "ENTERPRISE",
  });

  const [openDropCountry, setOpenDropCountry] = useState(false);
  const [dropValueCountry, setDropValueCountry] = useState(
    customerInfo.country ?? ""
  );
  const [openDropActivity, setOpenDropActivity] = useState(false);
  const [dropValueActivity, setDropValueActivity] = useState(
    customerInfo.activity ?? ""
  );
  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const updateCustomer = async () => {
    const request = await fetch(
      `${
        process.env.BASE_API_URL
      }/api/protected/customer?userId=${window.localStorage.getItem(
        "userId"
      )}&customerId=${customerInfo.id}`,
      {
        headers: {
          "Content-type": "application/json",
          Authorization: window.localStorage.getItem("accessToken"),
        },
        method: "PATCH",
        body: JSON.stringify(data),
      }
    );

    const datas = await request.json();

    if (request.ok) {
      router.replace({ pathname: "/gestions/client/clientshow", query: datas });
    }

    return datas;
  };

  const trashCustomer = async () => {
    const request = await fetch(
      `${
        process.env.BASE_API_URL
      }/api/protected/customer?userId=${window.localStorage.getItem(
        "userId"
      )}&customerId=${customerInfo.id}&intrash=intrash`,
      {
        headers: {
          "Content-type": "application/json",
          Authorization: window.localStorage.getItem("accessToken"),
        },
        method: "PATCH",
        body: JSON.stringify(data),
      }
    );

    const datas = await request.json();

    if (request.ok) {
      router.replace({ pathname: "/gestions/client" });
    }

    return datas;
  };

  const postCustomer = async () => {
    const request = await fetch(
      `${
        process.env.BASE_API_URL
      }/api/protected/customer?userId=${window.localStorage.getItem("userId")}`,
      {
        headers: {
          "Content-type": "application/json",
          Authorization: window.localStorage.getItem("accessToken"),
        },
        method: "POST",
        body: JSON.stringify(data),
      }
    );

    const datas = await request.json();

    if (request.ok) {
      router.back();
    }

    return datas;
  };

  return (
    <div className="flex w-full h-full overflow-x-hidden select-none">
      <div className="flex flex-col w-full h-full ">
        <SearchElement />

        <div
          className={` ${
            indexView == 0
              ? "flex  ml-20 flex-row  px-[60px]  mr-36  overflow-scroll md:items-start "
              : "flex-col  px-8  mr-40 ml-16  overflow-x-scroll"
          } flex-wrap flex-1   w-auto no-scrollbar `}
        >
          <div className="flex w-full mt-[48px]">
            <div className="w-full">
              <div className="grid w-full grid-cols-2 gap-16    text-[14.5px] font-bold">
                <p>Information sur l'entreprise </p>
                <p className=" ml-[39px]">Contact interne</p>
              </div>
              <div className="grid w-full grid-cols-2 gap-3 mt-[10px] gap-x-4">
                <InputComponent
                  name="name"
                  value={data.name}
                  onChange={handleChange}
                  label="Nom du client *"
                  labelClassName="text-white/40 text-[14px]"
                  className="rounded-[4px] text-[14px] text-[14px] border-opacity-30 focus:border-[#ffffff] focus:border-opacity-100  "
                />
                <InputComponent
                  name="externalName"
                  value={data.externalName}
                  onChange={handleChange}
                  label="Nom & prénom * "
                  labelClassName="text-white/40 text-[14px] ml-[62px]"
                  className="rounded-[4px] text-[14px] border-opacity-30 ml-[62px] focus:border-[#ffffff]"
                />

                <InputDropdownCountryComponent
                  label="Pays *"
                  placeholder="---"
                  inputDrop={true}
                  readOnly={true}
                  openDrop={openDropCountry}
                  onClick={() => {
                    setOpenDropCountry(true);
                  }}
                  handleClickClose={()=>{
                    setOpenDropCountry(false);
                  }}
                  handleClick={(item) => {
                    setOpenDropCountry(false);
                    setDropValueCountry(item.Name);
                    setData({
                      ...data,
                      country: item.Name + "",
                    });

                    console.log(data);
                  }}
                  value={dropValueCountry}
                  labelClassName="text-white/40 text-[14px]"
                  className=" rounded-[4px] text-[14px] mb-0 h-[50px] text-[14px] font-light border-opacity-30 focus:border-[#ffffff] focus:border-opacity-100  "
                />

                <InputComponent
                  name="externalEmail"
                  value={data.externalEmail}
                  onChange={handleChange}
                  labelClassName="text-white/40 text-[14px] ml-[62px]"
                  label="Email * "
                  className="rounded-[4px] text-[14px] border-opacity-30 ml-[62px] focus:border-[#ffffff]"
                />

                <InputDropdownActivityComponent
                  label="Secteur d'activité * "
                  placeholder="---"
                  inputDrop={true}
                  readOnly={true}
                  handleClickClose={()=>{
                    setOpenDropActivity(false);
                  }}
                  openDrop={openDropActivity}
                  onClick={() => {
                    setOpenDropActivity(true);
                  }}
                  handleClick={(item) => {
                    setOpenDropActivity(false);
                    setDropValueActivity(item);
                    setData({
                      ...data,
                      activity: item + "",
                    });

                    console.log(data);
                  }}
                  value={dropValueActivity}
                  labelClassName="text-white/40 text-[14px]"
                  className=" rounded-[4px] text-[14px] mb-0 h-[50px] text-[14px] font-light border-opacity-30 focus:border-[#ffffff] focus:border-opacity-100  "
                />

                <div className="grid w-full grid-cols-2 gap-6 ml-[62px]">
                  <InputComponent
                    name="poste"
                    value={data.poste}
                    onChange={handleChange}
                    label="Poste * "
                    labelClassName="text-white/40 text-[14px]  "
                    className="rounded-[4px] text-[14px] border-opacity-30 focus:border-[#ffffff]"
                  />
                  <InputComponent
                    name="externalContact"
                    value={data.externalContact}
                    type="number"
                    onChange={handleChange}
                    label="Contact * "
                    labelClassName="text-white/40 text-[14px]  "
                    className="rounded-[4px] text-[14px] border-opacity-30 focus:border-[#ffffff]"
                  />
                </div>
                <InputComponent
                  label="Email du client *"
                  name="email"
                  value={data.email}
                  onChange={handleChange}
                  labelClassName="text-white/40 text-[14px]  "
                  className="rounded-[4px] text-[14px] border-opacity-30 focus:border-[#ffffff]"
                />
                <div className="grid w-full  grid-cols-1  ml-[62px] min-[1520px]:grid-cols-2 leading-[13px]  gap-6">
                  <div className="flex flex-col pt-3 space-y-2 opacity-30">
                    <p className="text-[11px] ">
                      Votre confidentialité est importante pour nous.
                      <p>
                        Voir{" "}
                        <span className="text-teal-300">
                          la politique de confidentialité
                        </span>
                      </p>
                    </p>
                    <p className="text-[11px] ">
                      En utilisant Payme, vous acceptez nos termes
                      <p>
                        {" "}
                        et{" "}
                        <span className="text-teal-300">
                          conditions d'utilisation.
                        </span>
                      </p>
                    </p>
                  </div>
                </div>
                <InputComponent
                  label="Adresse du client * "
                  name="address"
                  value={data.address}
                  onChange={handleChange}
                  labelClassName="text-white/40 text-[14px]  "
                  className="rounded-[4px] text-[14px] border-opacity-30 focus:border-[#ffffff]"
                />
                <div className="grid w-full grid-cols-1 ml-[62px] gap-6">
                  {/*  <div className="flex flex-row items-center pt-3 pr-12 space-y-2 mb-28 ">
                    <input
                      type="checkbox"
                      className="opacity-70 accent-gray-100"
                    />
                    <p className="text-[11px] opacity-30 pb-2 ml-2 ">
                      J'accepte les conditions générales
                    </p>
                  </div> */}
                </div>
              </div>
            </div>

            <div className="w-[340px] mt-10  gap-6   flex justify-center items-end">
              <ButtonComponent
                key={1}
                label={"Annuler"}
                handleClick={() => {
                  router.back();
                }}
                className="bg-[#ffffff4b]  border-none min-h-[45px] w-[130px] font-bold "
              />
              <ButtonComponent
                key={2}
                handleClick={async () => {
                  if (
                    data.name.trim().length < 3 ||
                    data.country.trim() == "---" ||
                    data.activity.trim() == "---" ||
                    data.address.trim().length < 3 ||
                    data.externalName.trim().length < 3 ||
                    data.externalContact.trim().length < 3 ||
                    data.poste.trim().length < 3
                  ) {
                    modal.onSubmit = (
                      <ButtonComponent
                        handleClick={async () => {
                          modal.onClose();
                        }}
                        label={"Ok"}
                        className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                      />
                    );
                    modal.onOpen();
                    modal.setTitle("Attention !");
                    modal.setMessage(
                      "Vous devez remplir tous les champs obligatoires (*) avant de poursuivre."
                    );
                    return;
                  }
                  if (customerInfo.id) {
                    await updateCustomer();
                    return;
                  }
                  await postCustomer();
                }}
                label={customerInfo.id ? "Modifier" : "Enregistré"}
                className="bg-[#2d2d2d]  border-none min-h-[45px] w-[130px] font-bold "
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  function SearchElement() {
    return (
      <div className=" relative min-h-[130px] px-10 mr-36 ml-[100px]   pr-0 flex items-end pb-[17px]  justify-between   border-b-[1px]  border-white border-opacity-10">
        <IoIosArrowBack
          onClick={() => {
            customerInfo.id
              ? router.replace({
                  pathname: "/gestions/client/clientshow",
                  query: customerInfo,
                })
              : router.back();
          }}
          className="absolute w-8 h-8 font-bold cursor-pointer bottom-[22px] -left-2"
        />
        <div className="flex items-center space-x-2">
          <h3 className="ml-0 text-[32px] font-bold">
            {" "}
            {customerInfo.id
              ? "Modifier une entreprise"
              : "Ajouter une entreprise"}{" "}
          </h3>
        </div>

        <div className="flex">
          {customerInfo!.id && (
            <ButtonComponent
              Icon={IoMdTrash}
              iconClassName="w-[20px] h-[20px] mr-0"
              key={3}
              handleClick={async () => {
                modal.onSubmit = (
                  <ButtonComponent
                    handleClick={async () => {
                      await trashCustomer();
                      modal.onClose();
                    }}
                    label={"Supprimer"}
                    className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                  />
                );
                modal.onOpen();
                modal.setTitle("Êtes-vous sûr ?");
                modal.setMessage(
                  "Êtes-vous sûr de vouloir supprimer ce client ?"
                );
                //  await postCustomer();
              }}
              label={"Supprimer"}
              className="bg-[#9a9768] pr-4  border-none min-h-[45px] w-[130px] font-bold "
            />
          )}
          {/*  <ButtonComponent
          label={"Ajouter"}
          className="bg-[#9a9768] border-none max-h-[35px] w-[130px] ml-10"
        /> */}
        </div>
      </div>
    );
  }
}
/*
 */
export default AddNewClient;
