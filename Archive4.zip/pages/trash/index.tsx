import React, { useEffect, useState } from "react";
import SideBar from "../../components/Items/SideBar";
import { HiFolder, HiFolderAdd } from "react-icons/hi";
import { RxUpdate } from "react-icons/rx";
import { MdEmail, MdFolder, MdRestore } from "react-icons/md";
import { FaBuilding, FaUserCog, FaUserTie } from "react-icons/fa";
import { MdViewTimeline } from "react-icons/md";
import {
  BsFileEarmarkSpreadsheet,
  BsFillFileEarmarkTextFill,
  BsSortDownAlt,
  BsSortUp,
  BsSortUpAlt,
} from "react-icons/bs";
import {
  IoIosArrowBack,
  IoIosNotifications,
  IoIosPeople,
  IoMdBusiness,
  IoMdTrash,
} from "react-icons/io";
import InputComponent from "../../components/UI/InputComponent";
import FolderComponent from "../../components/UI/FolderComponent";
import PdfBuilder from "../../components/PdfDemo";
import { useRouter } from "next/router";
import { RiBankCardFill, RiFileEditLine } from "react-icons/ri";
import { IoListSharp, IoPersonSharp } from "react-icons/io5";
 
import { Menu } from "@headlessui/react";
import ButtonComponent from "../../components/UI/ButtonComponent";
import {
  deleteAllCustomerInTrash,
  deleteCustomerInTrash,
  fetchAllCustomerTrash,
  outTrashCustomer,
} from "../../services/customerModel";
import dayjs from "dayjs";
import { daysFr } from "../../utils/helpers";
 
import {
  deletProjectInTrash,
  deleteAllProjectInTrash,
  fetchAllProjectTrash,
  outTrashProject,
} from "../../services/projectService";
import { LiaFileAltSolid } from "react-icons/lia";
import DropdownTrashItem from "../../components/menu/DropdownTrashItem";
import { useGlobalModal } from "../../utils/use-global-modal";
import DropdownGlobalTrash from "../../components/menu/DropdownGlobalTrash";
function Trash() {
  /* people
business
handyman
bookmarks
assignment_turned_in_rounded 
 
*/
const modal = useGlobalModal()
  const [isLoading, setIsLoading] = useState(true);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [projets, setProjets] = useState<Project[]>([]);
  const [datas, setDatas] = useState<any[]>([]);
  const [searchValue, setSearchValue] = useState("");
  const [datasFiltered, setDatasFiltered] = useState<any[]>([]);
  useEffect(() => {
    const datasFilter = datas.filter((item) =>
      item.name.toLowerCase().includes(searchValue.toLowerCase())
    );
    
    setDatasFiltered(datasFilter);
  }, [searchValue,isLoading]);
  useEffect(() => {
    (async () => { 
      //const dataProjects = await fetchAllProject();
      //setProjects(dataProjects);
      setCustomers(await fetchAllCustomerTrash());
      setProjets(await fetchAllProjectTrash());
      customers.forEach((i) =>{
        setDatas((current) => [...current, i])
        setDatasFiltered((current) => [...current, i])
      });
      projets.forEach((it) => {
        setDatas((current) => [...current, it])
        setDatasFiltered((current) => [...current, it])
      });

    
      setIsLoading(false);
    })();

    return () => {};
  }, [isLoading]);

  return (
    <div className="flex flex-col w-full h-full ">
      {SearchElement()}

      <div className="flex-1 overflow-scroll no-scrollbar">
        <div className="flex flex-col flex-1 h-full ml-4 mr-8 space-y-4 p-12 pt-[22px] ">
          <div className="flex p-2 mt-0 mb-2 pb-2  text-[14px]   px-1 2xl:ml-14 ml-10  mr-20 border-b border-white/10 ">
          
          
           {isLoading && <div className="w-[120px] md:w-[380px] xl:w-[500px] opacity-40   2xl:w-[620px] ">
           <h2 className="text-[#9a9768] text-[18px] font-bold   rounded-md h-[15px] w-[140px]  animate-pulse duration-100    bg-[#ffffff1f] "></h2>
            
            </div>}
           {!isLoading && <p className="w-[120px] md:w-[380px] xl:w-[500px] opacity-40   2xl:w-[620px]">
              Nom
            </p>}
            {isLoading && <p className="w-[120px] md:w-[300px] xl:w-[250px] opacity-40   2xl:w-[480px]">
            <h2 className="text-[#9a9768] text-[18px] font-bold   rounded-md h-[15px] w-[140px]  animate-pulse duration-100    bg-[#ffffff1f] "></h2>
            
            </p>}
            {!isLoading && <p className="w-[120px] md:w-[300px] xl:w-[250px] opacity-40   2xl:w-[480px]">
              Emplacement
            </p>}
           {isLoading && <p className="w-[120px] md:w-[350px] xl:w-[250px] opacity-40   2xl:w-[250px]">
           <h2 className="text-[#9a9768] text-[18px] font-bold   rounded-md h-[15px] w-[140px]  animate-pulse duration-100    bg-[#ffffff1f] "></h2>
            
            </p>}
           {!isLoading && <p className="w-[120px] md:w-[350px] xl:w-[250px] opacity-40   2xl:w-[250px]">
              Date de suppression
            </p>}
          </div>
          <div className="flex-1 overflow-y-scroll no-scrollbar">
         
             
           {isLoading && [1,2,3,4,5,6,7].map((item) => (
              <ItemTrashShimmer key={item} item={item} />
            ))}   
              {!isLoading &&datasFiltered.map((item) => (
              <ItemTrash key={item.id} item={item} />
            ))}   
              <h3 className="flex w-full pr-10 text-[14px] pb-2 pt-4 pl-12 text-white/20">
            Les éléments placés dans la corbeille sont définitivement supprimés
            au bout de 30 jours.
          </h3>  
          </div>
        
        </div>
      </div>
    </div>
  );

  function SearchElement() {
    const router = useRouter();
    return (
      <div className=" min-h-[125px] px-16 flex items-end mr-0 pb-6 pr-24    relative    justify-between  border-b-[1px]  border-white/10 border-opacity-20">
      
       
        <div>
          <h3 className="text-4xl font-bold">Corbeille</h3>
         
        </div>
        {isLoading &&   <div className="absolute flex gap-4 right-[135px] bottom-[30px]">
     <div className="min-w-[200px] h-8 rounded-full  animate-pulse duration-100    bg-[#ffffff1f] ">  </div>
    
     </div>}
       {!isLoading && <div className="flex">
        
          <InputComponent
            key={"item12"}
              value={searchValue}
            onChange={(e) => {
              setSearchValue(x => x = e.target.value)
            }}
            placeholder="Rechercher"
            className="px-[0px] border-b-white border-t-transparent border-x-transparent"
          />{" "}
          <DropdownGlobalTrash className="max-w-[100px]">
            <Menu.Item>
              {({ active }) => (
                <div
                  onClick={() => {
                    // setTypeValue("ENTERPRISE");
                  }}
                  className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                    active
                      ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                      : " "
                  }`}
                >
                  <BsSortUpAlt className="w-6 h-6 " />
                  Croissant
                </div>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <div
                  onClick={() => {
                    // setTypeValue("PERSONAL");
                  }}
                  className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                    active
                      ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                      : " "
                  }`}
                >
                  <BsSortDownAlt className="w-6 h-6 " />
                  Décroissant
                </div>
              )}
            </Menu.Item>
            
          </DropdownGlobalTrash>
          <ButtonComponent
            label={"Vider la corbeille"}
            labelClassName="font-bold text-[15px]"
            handleClick={() => {


            modal.onSubmit = (
              <ButtonComponent
                handleClick={async () => {
                 

                  setIsLoading((x) => (x = false));
                  const presentValue = searchValue;
                  setSearchValue(x => x = "")
                  setDatas([]);
                  setCustomers([]);
                  setProjets([]);
                  await deleteAllProjectInTrash();
                  await deleteAllCustomerInTrash();
                  
                  setSearchValue(x => x = presentValue)
                  setIsLoading((x) => (x = true));
                

                  if (true) {
                   
                    
                   modal.onClose();
                  }
                }}
                label={"vider"}
                className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
              />
            );
            modal.onOpen();
        modal.setTitle("Êtes-vous sûr ?");
        modal.setMessage("Êtes-vous vraiment sûr de vouloir vider la corbeille ?");
            }}
            className="bg-[#9a9768] border-none min-h-[35px] min-w-[160px] font-semibold ml-8 mr-10"
          />
        </div>}
      </div>
    );
  }

  function ItemGestionShimmer() {
 
    return (
      <div
     
      className="flex cursor-pointer w-full  rounded-md  bg-gradient-to-r    from-[#ffffff11]   to-[#ffffff08]     flex-1 min-h-[40px] items-center  text-[15px] mt-3    pb-[9px]  text-[#ffffff82]   "
    >
      <div className="flex-1 pt-2 ">
        <div
          className={`flex flex-col     pl-4   leading-[1rem]`}
        >
          <p className=" p-[6px] max-w-[160px]  rounded-md animate-pulse duration-100    bg-[#ffffff1f]  text-[14.5px] font-bold mt-2  line-clamp-1">
            {" "}
           
          </p>
          <span className="text-[14px] p-1 max-w-[340px] rounded-md  animate-pulse duration-100    bg-[#ffffff1f]  mt-[7px] mb-[1px] line-clamp-1">
          
          </span>
          <span className={`text-[12px]  mt-2  mb-1 p-1 max-w-[400px] rounded-md  animate-pulse duration-100    bg-[#ffffff1f]  line-clamp-1`}>
            {" "}
       
          </span>
        </div>
      </div>
  
      
    </div>
    )
  }
  function ItemTrashShimmer({ item }) {
    return (
      <div className="flex p-2 rounded-md  bg-gradient-to-r    from-[#ffffff11]   to-[#ffffff08]   relative mt-0 mb-2 pb-4  text-[14px] select-none cursor-pointer  mr-20  px-1 2xl:ml-14 ml-10  border-white/10 ">
         
       
       
        <div className="w-[120px] pl-5 mt-2 flex flex-col md:w-[380px] xl:w-[500px] opacity-40    uppercase 2xl:w-[620px]   gap-2 items-start">
        <p className=" p-[6px] min-w-[120px]  rounded-md animate-pulse duration-100    bg-[#ffffff1f]  text-[14.5px] font-bold   line-clamp-1">
        
         
        </p>
        <p className=" p-[4px] min-w-[240px]  rounded-md animate-pulse duration-100    bg-[#ffffff1f]  text-[14.5px] font-bold mt-0  line-clamp-1">
        
         
        </p>
        
        </div>
        <p className="w-[120px] md:w-[300px] xl:w-[250px] opacity-40 flex items-center uppercase 2xl:w-[480px]">
        <p className=" p-[6px] min-w-[120px]  rounded-md animate-pulse duration-100    bg-[#ffffff1f]  text-[14.5px] font-bold   line-clamp-1">
        
         
        </p>
        </p>
        <p className="w-[120px] md:w-[350px] xl:w-[140px] pl-[2px] 2xl:pl-[5px] opacity-40 flex items-center  uppercase 2xl:w-[250px]">
        <p className=" p-[6px] min-w-[120px]  rounded-md animate-pulse duration-100    bg-[#ffffff1f]  text-[14.5px] font-bold   line-clamp-1">
        
         
        </p>
        </p>
       
      </div>
    );
  }
  function ItemTrash({ item }) {
    return (
      <div className="flex p-2  relative mt-0 mb-2 pb-4  text-[14px] select-none cursor-pointer  mr-20  px-1 2xl:ml-14 ml-10  border-b border-white/10 ">
        <div className="absolute -right-[140px] z-20 flex w-[200px]  opacity-100  items-center">
          <DropdownTrashItem className="">
            <Menu.Item>
              {({ active }) => (
                <div
                  onClick={async () => {
                    const presentValue = searchValue;
                    setSearchValue(x => x = "")
                    setIsLoading((x) => (x = false));
                    setDatas([]);
                    setCustomers([]);
                    setProjets([]);
                    if (item.customer?.name) {
                      await outTrashProject(item.id);
                    } else {
                      await outTrashCustomer(item.id);
                    }

                    setSearchValue(x => x = presentValue)
                    setIsLoading((x) => (x = true));
                  }}
                  className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                    active
                      ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                      : " "
                  }`}
                >
                  <MdRestore className="min-w-10 min-h-10 " />
                  Restaurer
                </div>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <div
                  onClick={async() => {
                    setIsLoading((x) => (x = false));
                    const presentValue = searchValue;
                    setSearchValue(x => x = "")
                    setDatas([]);
                    setCustomers([]);
                    setProjets([]);
                    if (item.customer?.name) {
                      await deletProjectInTrash(item.id);
                    } else {
                      await deleteCustomerInTrash(item.id);
                    }
                    setSearchValue(x => x = presentValue)
                    setIsLoading((x) => (x = true));
                  }}
                  className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                    active
                      ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                      : " "
                  }`}
                >
                  <IoMdTrash className="min-w-10 min-h-10 " />
                  Supprimer
                </div>
              )}
            </Menu.Item>
          </DropdownTrashItem>
        </div>
       
       
        <div className="w-[120px] md:w-[380px] xl:w-[500px] opacity-40  uppercase 2xl:w-[620px] flex  gap-2 items-center">
          {item.customer?.name ? (
            <LiaFileAltSolid className="w-[30px] h-[30px] mb-0 " />
          ) : (
            <MdFolder className="w-[30px] h-[30px] mb-0 " />
          )}
          <p>{item.name}</p>{" "}
        </div>
        <p className="w-[120px] md:w-[300px] xl:w-[250px] opacity-40 flex items-center uppercase 2xl:w-[480px]">
          {item.customer?.name ?? "Client"}
        </p>
        <p className="w-[120px] md:w-[350px] xl:w-[140px] pl-[2px] 2xl:pl-[5px] opacity-40 flex items-center  uppercase 2xl:w-[250px]">
          {daysFr(item.deletedAt)}
        </p>
       
      </div>
    );
  }
}

export default Trash;
