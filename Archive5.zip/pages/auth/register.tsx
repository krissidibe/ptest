import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { IoIosArrowBack, IoIosFolder } from "react-icons/io";
import { IoMdMap, IoMdAttach } from "react-icons/io";
import { BiCrop, BiImageAlt, BiSolidDashboard } from "react-icons/bi";
import { MdOutlineAttachment } from "react-icons/md";
import InputComponent from "../../components/UI/InputComponent";
import ButtonComponent from "../../components/UI/ButtonComponent";
import { useRouter } from "next/router";
import InputDropdownComponent from "../../components/UI/InputDropdownComponent";
import { useCropImage } from "../../utils/use-crop-image-modal";
import { ModalProvider } from "../../components/Items/modal-provider";
import InputDropdownActivityComponent from "../../components/UI/InputDropdownActivityComponent";
import InputDropdownCountryComponent from "../../components/UI/InputDropdownCountryComponent";
/* import { readFile } from "fs"; */
import { saveAs } from "file-saver";
import { v4 as uuidv4 } from "uuid";
import {
  getCroppedImg,
  getRotatedImage,
} from "../../components/Modals/canvasUtils";
import Cropper from "react-easy-crop";
function Register(props) {
  const [indexStep, setIndexStep] = useState(0);
  const [openDrop, setOpenDrop] = useState(false);
  const modalCropImage = useCropImage();

  const [openDropActivity, setOpenDropActivity] = useState(false);
  const [logoChoose, setLogoChoose] = useState(false);
  const [signatureChoose, setSignatureChoose] = useState(false);
  const [dropValueActivity, setDropValueActivity] = useState("");

  const [openDropCountry, setOpenDropCountry] = useState(false);
  const [dropValueCountry, setDropValueCountry] = useState("");
  const routerData = useRouter().query;

  const [data, setData] = useState<Enterprise>({
    id: "",
    email: "",
    activity: "",
    address: "",
    numbers: "",
    currency: "",
    name: "",
    rccm: "",
    nif: "",
    statut: "---",
    bankNumber: "",
    website: "",
  });


 
  const [contactList, setContactList] = useState([
    {
      id: uuidv4(),
      indicatif: "",
      number: "",
    },
  ])
  const [identificationsList, setIdentificationsList] = useState([
    {
      id: uuidv4(),
      content: "",
    },
  ])

  const [dropValue, setDropValue] = useState(data.statut);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const imageRef = useRef(null);
  function readFile(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.addEventListener("load", () => resolve(reader.result), false);
      
      if (!file) {
       return;
      }else{
        reader.readAsDataURL(file as Blob);
      }
    });
  }
  const imageRef2 = useRef(null);
 

  const [imageLogo, setImageLogo] = useState(null);
  const [imageSignature, setImageSignature] = useState(null);

  const handleSubmit = async () => {

 

    const requestOne = await fetch(`${process.env.BASE_API_URL}/api/userfree`, {
      headers: {
        "Content-type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(routerData),
    });
   const resultUser = await requestOne.json();
 
 
  
 if(requestOne.status == 200){

   

  const request = await fetch(
    `${process.env.BASE_API_URL}/api/enterprise?id=${resultUser.data.id!}&email=${resultUser.data.email!}`,
    {
      headers: {
        "Content-type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(data),
    }
  );
  const result = await request.json();
  console.log(result);

  fetch(imageLogo)
  .then((res) => res.blob())
  .then(async (blob) => {
    const file = new File([blob], "logo.png", {
      type: "image/png",
    });
    console.log(file);
    const formData = new FormData();
    formData.append("image", file);
    formData.append("name", "logo-"+result.id!);
    const res = await fetch(
      `${process.env.BASE_API_URL}/api/storagetest`,
      {
        body: formData,

        method: "POST",
      }
    );
    const data = await res.json();
  });

  fetch(imageSignature)
  .then((res) => res.blob())
  .then(async (blob) => {
    const file = new File([blob], "signature.png", {
      type: "image/png",
    });
    console.log(file);
    const formData = new FormData();
    formData.append("image", file);
    formData.append("name", "signature-"+result.id!);
    const res = await fetch(
      `${process.env.BASE_API_URL}/api/storagetest`,
      {
        body: formData,

        method: "POST",
      }
    );
    const data = await res.json();
  });







  if (request.status == 200) {
  
 router.back()
}  
 }
  };

  function CropImageModal({ handleDone = () => {}, imageData = "" }) {
    useEffect(() => {
      (async () => {
        let imageDataUrl = await readFile(imageData);

        setImage(imageDataUrl);
      })();
      return () => {};
    }, []);

    const imageRef = useRef(null);
    const imageRef2 = useRef(null);
    const [image, setImage] = useState(null);
    const [index, setIndex] = useState(0);
    const router = useRouter();

    const [crop, setCrop] = useState({ x: 0, y: 0 });
    const [croppedImage, setCroppedImage] = useState(null);
    const [rotation, setRotation] = useState(0);
    const [zoom, setZoom] = useState(1);
    const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);
    const onCropComplete = useCallback((croppedArea, croppedAreaPixels) => {
      setCroppedAreaPixels(croppedAreaPixels);
    }, []);

    const onFileChange = async (e) => {
      if (e.target.files && e.target.files.length > 0) {
        const file = e.target.files[0];
        let imageDataUrl = await readFile(file);

        try {
          // apply rotation if needed

          if (rotation) {
            imageDataUrl = await getRotatedImage(imageDataUrl, rotation);
          }
        } catch (e) {
          console.warn("failed to detect the orientation");
        }

        setImage(imageDataUrl);
      }
    };

    const showCroppedImage = useCallback(async () => {
      try {
        const croppedImage = await getCroppedImg(
          image,
          croppedAreaPixels,
          rotation
        );
        console.log("donee", croppedImage);
        setCroppedImage(croppedImage);
      } catch (e) {
        console.error(e);
      }
    }, [image, croppedAreaPixels, rotation]);
const [apercuIncrement, setApercuIncrement] = useState(0)
  /*   if (!logoChoose || !signatureChoose) {
      return null;
    } */
    return (
      <div   className="absolute inset-0 z-50 flex items-center justify-center pb-20 transition bg-black/40 ">
        <div className="p-4 bg-[#323232]  z-50  w-[474px]  pt-10 px-8 flex flex-col items-center justify-center text-white rounded-xl">
          <div className="flex justify-between w-full gap-6">
            <input
              ref={imageRef}
              type="file"
              className="hidden"
              onChange={onFileChange}
            />
            <div className="bg-zinc-500 relative h-[300px] w-[300px] rounded-xl">
              {image ? (
                <Cropper
                  style={{}}
                  image={image}
                  crop={crop}
                  zoom={zoom}
                  aspect={4 / 4}
                  onCropChange={setCrop}
                  onCropComplete={onCropComplete}
                  onZoomChange={setZoom}
                />
              ) : null}
            </div>
            <div className="flex flex-col items-center gap-4">
              <div className="bg-white h-[150px] w-[150px] rounded-xl">
                <img src={croppedImage} />
              </div>
              <div
                onClick={()=> {
                  setApercuIncrement(x=> x =x+1)
                  showCroppedImage()
                
             
                
                }}
                className="flex  bg-gradient-to-r items-center gap-2 justify-center from-[#757575]  to-[#4c4c4c] w-[120px] p-1 text-center text-white text-sm cursor-pointer rounded-md shadow-md  "
              >
                <BiImageAlt className="w-6 h-6" />
                <span>Aperçu</span>
              </div>
              <div
                onClick={() => {
                  imageRef.current.click();
                }}
                className="flex  bg-gradient-to-r items-center gap-2 justify-center from-[#757575]  to-[#4c4c4c] w-[120px] p-1 text-center text-white text-sm cursor-pointer rounded-md shadow-md  "
              >
                <BiCrop className="w-6 h-6" />
                <span>Fichier</span>
              </div>
            </div>
          </div>

          <div className="flex justify-center w-full gap-4 pt-6 pb-4 mt-10 border-t-[1px] border-t-white border-opacity-40">
            <ButtonComponent
            key={121}
              label={"Annuler"}
              handleClick={() => {
                setLogoChoose((x) => (x = false));
                setSignatureChoose((x) => (x = false));
              }}
              className="  min-h-[45px] w-[150px] font-bold "
            />
            <div onClick={showCroppedImage}>

            </div>
            {apercuIncrement>0 &&<ButtonComponent
            key={143}
              label={"Appliquer"}
              handleClick={  () => {
         
          if(logoChoose){
            setImageLogo(croppedImage);
          }else{
             setImageSignature(croppedImage);

           }
            setLogoChoose((x) => (x = false));
            setSignatureChoose((x) => (x = false));
   
            setApercuIncrement(x=> x =0)
                // console.log("donee", croppedImage);

                //  modal.setImage(croppedImage);
              }}
              className="bg-[#ffffff1c]  border-none min-h-[45px] w-[150px] font-bold "
            />}
          </div>
        </div>
      </div>
    );
  }

  function Step1() {
    return (
      <div className="flex-1  min-h-[340px]">
        <h2 className="pb-2 mt-4 text-2xl font-bold tracking-wider">
          Personnalisez votre profil d'entreprise
        </h2>
        <p className="text-sm opacity-50">
          Créez votre compte et définissez la structure de votre entreprise
        </p>

        <div className="w-full h-[1px] opacity-20 mt-10 bg-white"></div>
        <div className="grid w-full grid-cols-1 gap-8 mt-8 ">
          <InputComponent
            name="name"
            value={data.name}
            onChange={handleChange}
            label="Nom de l'entreprise *"
            placeholder="Entrez le nom de l'entreprise"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />

          <InputDropdownActivityComponent
            label="Secteur d'activité * "
            placeholder="---"
            inputDrop={true}
            readOnly={true}
            handleClickClose={() => {
              setOpenDropActivity(false);
            }}
            openDrop={openDropActivity}
            onClick={() => {
              setOpenDropActivity(true);
            }}
            handleClick={(item) => {
              setOpenDropActivity(false);
              setDropValueActivity(item);
              setData({
                ...data,
                activity: item + "",
              });
            }}
            value={dropValueActivity}
            labelClassName="text-white opacity-100 "
            className={`rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100`}
          />

          {/*  <InputComponent
           name="activity"
           value={data.activity}
           onChange={handleChange}
            label="Secteur d'activité *"
            placeholder="Choisissez votre secteur d'activité"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          /> */}
        </div>
      </div>
    );
  }

  function Step2() {
    return (
      <div className="flex-1 min-h-[340px]   ">
        
        <div className="grid w-full grid-cols-1 gap-8 mt-4 ">
          <InputComponent
            name="address"
            value={data.address}
            onChange={handleChange}
            label="Siège social *"
            placeholder="Entrez l'adresse de l'entreprise"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />


          
          <InputComponent
            name="email"
            value={data.email}
            onChange={handleChange}
            label="Adresse email *"
            placeholder="Saisissez l'adresse email de l'entreprise"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
          
     <div className="flex gap-4 ">
        <div>
          <InputDropdownCountryComponent
            label="Indicatif *"
            placeholder="---"
            inputDrop={true}
            readOnly={true}
            handleClickClose={() => {
              setOpenDropCountry(false);
            }}
            openDrop={openDropCountry}
            onClick={() => {
              setOpenDropCountry(true);
            }}
            handleClick={(item) => {
             
              const newItem = contactList.map(shape => {
                if (shape.id != contactList[0].id) {
                  // No change
                  return shape;
                } else {
                  // Return a new circle 50px below
                  return {
                    ...shape,
                    indicatif:  item.Phone + "",
                  };
                }
              });
              // Re-render with the new array
              setContactList(newItem);
            
        
              setOpenDropCountry(false);
              setDropValueCountry(contactList[0].indicatif ?? "---");
             /*  setData({
                ...data,

                indicatif: item.Phone + "",
              }); */

          
            }}
            value={contactList[0]?.indicatif ?? "---"}
            iconClassName="bottom-[17px]"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]     border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
         
        </div>
        <div className="grid w-full grid-cols-2 gap-4 ">
          <InputComponent
            label="Contact primaire *"
            name="numberPrimary"
           // value={data.numberPrimary}
            value={contactList[0].number ?? "---"}
            onChange={(e)=>{
             
              const newItem = contactList.map(shape => {
                if (shape.id != contactList[0].id) {
                  // No change
                  return shape;
                } else {
                  // Return a new circle 50px below
                  return {
                    ...shape,
                    number:   e.target.value,
                  };
                }
              });
              // Re-render with the new array
              setContactList(newItem);
               
              return;
              
            }}
            type="number"
            onWheel={ event => event.currentTarget.blur() }
            placeholder="Numéro principale"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
       
        </div>
      </div>
    {contactList.length == 2 &&  <div className="flex gap-4 ">
        <div>
          <InputDropdownCountryComponent
          key={30}
            label="Indicatif *"
            placeholder="---"
            inputDrop={true}
            readOnly={true}
            handleClickClose={() => {
              setOpenDropCountry(false);
            }}
            openDrop={openDropCountry}
            onClick={() => {
              setOpenDropCountry(true);
            }}
            handleClick={(item) => {
              const newItem = contactList.map(shape => {
                if (shape.id != contactList[1].id) {
                  // No change
                  return shape;
                } else {
                  // Return a new circle 50px below
                  return {
                    ...shape,
                    indicatif:  item.Phone + "",
                  };
                }
              });
              // Re-render with the new array
              setContactList(newItem);
            
        
              setOpenDropCountry(false);
              setDropValueCountry(contactList[1].indicatif ?? "---");
             /*  setData({
                ...data,

                indicatif: item.Phone + "",
              }); */
            }}
            value={contactList[1]?.indicatif ?? "---"}
            iconClassName="bottom-[17px]"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]     border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
          
        </div>
        <div className="grid w-full grid-cols-2 gap-4 mb-7">
          
      <InputComponent
         key={230}
            name="numberSecondary"
            value={contactList[1].number}
            onChange={(e)=>{
             
              const newItem = contactList.map(shape => {
                if (shape.id != contactList[1].id) {
                  // No change
                  return shape;
                } else {
                  // Return a new circle 50px below
                  return {
                    ...shape,
                    number:   e.target.value,
                  };
                }
              });
              // Re-render with the new array
              setContactList(newItem);
               
              return;
              
            }}
            type="number"
            onWheel={ event => event.currentTarget.blur() }
            label="Contact secondaire"
            placeholder="Numéro secondaire"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />  
        </div>
      </div>}
         
        </div>
      </div>
    );
  }
  function Step3() {
    return (
      <div className="flex-1  min-h-[340px] ">
       <div >
       <h2 className="pb-2 mt-4 text-2xl font-bold tracking-wider">
          Enregistrez vos informations fiscales
        </h2>
        <p className="text-sm opacity-50">
          Évitez les retards en préparant vos documents administratifs à
          l'avance
        </p>

        <div className="w-full h-[1px] opacity-20 mt-10 bg-white"></div>
       </div>
        <div className="grid flex-1 w-full grid-cols-1 gap-8 pb-2 mt-8 ">
          <InputComponent
            name="rccm"
            value={data.rccm}
            onChange={handleChange}
            label="N° Registre du commerce"
            placeholder="Saisissez le n° RCCM"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
          <InputComponent
            name="nif"
            value={identificationsList[0].content}
            onChange={(e)=>{
              const newItem = identificationsList.map(shape => {
                if (shape.id != identificationsList[0].id) {
                  // No change
                  return shape;
                } else {
                  // Return a new circle 50px below
                  return {
                    ...shape,
                    content:  e.target.value,
                  };
                }
              });
              // Re-render with the new array
              setIdentificationsList(newItem);
            
            }}
            label="Numéro d’identification"
            
            placeholder="Saisissez le numéro d’identification en fonction de votre pays"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
        {identificationsList.length ==2 &&   <InputComponent
            name="nif"
            value={identificationsList[1].content}
            onChange={(e)=>{
              const newItem = identificationsList.map(shape => {
                if (shape.id != identificationsList[1].id) {
                  // No change
                  return shape;
                } else {
                  // Return a new circle 50px below
                  return {
                    ...shape,
                    content:  e.target.value,
                  };
                }
              });
              // Re-render with the new array
              setIdentificationsList(newItem);
            
            }}
            label="Autre numéro d’identification"
            placeholder="Saisissez le second numéro d’identification "
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          /> }
             
        </div>
         
      </div>
    );
  }

  function Step4() {
    return (
      <div className="flex-1 min-h-[340px]   ">
        <div className="grid w-full grid-cols-1 gap-8 mt-4 ">
          <InputDropdownComponent
            label="Statut juridique *"
            placeholder="---"
            inputDrop={true}
            readOnly={true}
            openDrop={openDrop}
            onClick={() => {
              setOpenDrop(true);
            }}
            handleClick={(item) => {
              setOpenDrop(false);
              setDropValue(item);
              setData({ ...data, statut: item });
            }}
            value={dropValue}
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
          <InputComponent
            name="bankNumber"
            value={data.bankNumber}
            onChange={handleChange}
            label="N° Compte bancaire"
            placeholder="Indiquez vos coordonnées bancaires pour les paiements"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
          <InputComponent
            name="website"
            value={data.website}
            onChange={handleChange}
            label="Site internet"
            placeholder="Saissisez l'adresse de votre site internet"
            labelClassName="text-white opacity-100 "
            className="rounded-[14px] text-[14px] h-[55px]  border-opacity-50 focus:border-[#ffffff] focus:border-opacity-100 "
          />
        </div>
      </div>
    );
  }

  function Step5() {
    return (
      <div className="flex-1  min-h-[340px]">
        <h2 className="pb-2 mt-4 text-2xl font-bold tracking-wider">
          Ajoutez les fichiers joints nécessaires
        </h2>
        <p className="text-sm opacity-50">
          Assurez-vous que les fichiers sont dans un format compatible et de
          bonne gualité
        </p>
        <input
          ref={imageRef}
          type="file"
          className="hidden"
          onChange={(e) => {
            if (!e.target.files[0].type.startsWith("image/")) return;
            setImageLogo(e.target.files[0]);
            setLogoChoose(true);
          }}
        />
        <input
          ref={imageRef2}
          type="file"
          className="hidden"
          onChange={(e) => {
            if (!e.target.files[0].type.startsWith("image/")) return;
            setImageSignature(e.target.files[0]);
            setSignatureChoose(true);
          }}
        />
        <div className="w-full h-[1px] opacity-20 mt-10 bg-white"></div>
        <div className="grid w-full grid-cols-1 gap-8 mt-8 ">
  {/*  <div
            onClick={async () => {
              fetch(imageSignature)
                .then((res) => res.blob())
                .then(async (blob) => {
                  const file = new File([blob], "logo.png", {
                    type: "image/png",
                  });
                  console.log(file);
                  const formData = new FormData();
                  formData.append("image", file);
                  formData.append("name", "file");
                  const res = await fetch(
                    `${process.env.BASE_API_URL}/api/storagetest`,
                    {
                      body: formData,

                      method: "POST",
                    }
                  );
                  const data = await res.json();
                });

              
 
            }}
          >
            Download blob image
          </div>   */}
          {modalCropImage.image && (
            <img
              src={modalCropImage.image + ""}
              alt="image"
              className="object-contain w-full h-full rounded-lg"
            />
          )}

          <div
            onClick={() => {
              setImageLogo(null);

              console.log(imageLogo);
              
              imageRef.current.click();
             setLogoChoose(x => x = true);
             setSignatureChoose(x => x = false);
            }}
            className="bg-[#06060600] flex justify-between cursor-pointer items-center border-[1px] placeholder:opacity-40  text-white border-white  px-6 outline-none w-full  rounded-[8px] text-[14px] h-[75px]  border-opacity-50   "
          >
            <div className="flex flex-col text-[12px] leading-4">
              <p className="text-sm">
                Téléchargez le logo de l'entreprise  
              </p>
              <p className="opacity-40">Taille de fichier Max. de 2 Mo</p>
            </div>
            <MdOutlineAttachment className="w-6 h-6" />
          </div>

          <div
            onClick={() => {
              setImageSignature(null);

              console.log(imageSignature);
              
              imageRef2.current.click();
              setSignatureChoose(x => x = true);
              setLogoChoose(x => x = false);
            }}
            className="bg-[#06060600] flex justify-between cursor-pointer items-center border-[1px] placeholder:opacity-40  text-white border-white  px-6 outline-none w-full  rounded-[8px] text-[14px] h-[75px]  border-opacity-50   "
          >
            <div className="flex flex-col text-[12px] leading-4">
              <p className="text-sm">
                Téléchargez la signature de l'entreprise 
              </p>
              <p className="opacity-40">Taille de fichier Max. de 2 Mo</p>
            </div>
            <MdOutlineAttachment className="w-6 h-6" />
          </div>
        </div>
      </div>
    );
  }
  const router = useRouter();
  return (
    <div className="flex flex-col px-[10px] xl:py-[140px] lg:py-[130px] h-screen    items-center justify-center  bg-gradient-to-b from-[#212121]">
      <ModalProvider />
      <div className="mr-60">
        <h1 className="flex self-start gap-2 mb-4 text-3xl font-bold">
          {" "}
          <IoIosArrowBack
            onClick={() => {
              router.back();
            }}
            className="w-8 h-8 cursor-pointer"
          />{" "}
          Payme, votre allié pour une gestion financière simplifiée
        </h1>
      </div>

      <div className="flex flex-1 w-full   border-t-[1px] h-1/2 max-w-[1040px] border-opacity-20 border-white">
        <LefSection indexStep={indexStep} />
       
        

<div className="flex-1 pt-10 pl-12">
<p className="mb-2 text-sm opacity-50">Etapes {indexStep + 1}/5</p>
<div className="h-full overflow-scroll no-scrollbar">
 
          
          {indexStep == 0 && Step1()}
          {indexStep == 1 && Step2()}
          {indexStep == 2 && Step3()}
          {indexStep == 3 && Step4()}
          {indexStep == 4 && Step5()}

          {indexStep == 4 && <>
            {logoChoose &&    <CropImageModal imageData={imageLogo} />}
            {signatureChoose &&    <CropImageModal imageData={imageSignature} />}
            
            </>
        
            
          }

{(indexStep == 1  ) &&<div
          onClick={()=>{
          if(contactList.length == 1){
            setContactList([...contactList,{
              id: uuidv4(),
              indicatif: "",
              number: "",
            }
          ])
          }else{
            const newArray = contactList.slice(0,-1)
            setContactList(newArray)
          }
          }}
          
          className="flex gap-3  cursor-pointer w-[300px] pl-2 py-2 mt-0">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="24" height="24" rx="12" fill="#505050"/>
<path d="M19 12.998H13V18.998H11V12.998H5V10.998H11V4.998H13V10.998H19V12.998Z" fill="#ACACAC"/>
</svg>

            <p className="text-base ">{contactList.length == 1 ? "Ajouter un contact" :"Supprimer un contact"}</p></div> }

            {(indexStep == 2  ) &&<div
          onClick={()=>{
          if(identificationsList.length == 1){
            setIdentificationsList([...identificationsList,{
              id: uuidv4(),
             
              content: "",
            }
          ])
          }else{
            const newArray = identificationsList.slice(0,-1)
            setIdentificationsList(newArray)
          }
          }}
          
          className="flex gap-3  cursor-pointer w-[full] pl-2 py-2 mt-3">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="24" height="24" rx="12" fill="#505050"/>
<path d="M19 12.998H13V18.998H11V12.998H5V10.998H11V4.998H13V10.998H19V12.998Z" fill="#ACACAC"/>
</svg>

            <p className="text-base ">{identificationsList.length == 1 ? "Ajouter un numéro d’identification" :"Supprimer le second numéro d’identification"}</p></div> }

          <div className="flex self-end justify-start gap-4 mt-10 ">
           
          <ButtonComponent
              label={"Retour"}
              handleClick={() => {
                if (indexStep > 0) {
                  setIndexStep((prev) => prev - 1);
                }
              }}
              className="bg-[#212121]  border-none min-h-[45px] w-[140px] font-bold "
            />
            {((indexStep == 0 &&
              data.name.trim().length >= 2 &&
              data.activity.trim().length >= 2) ||
              (indexStep == 1 &&
                data.address.trim().length >= 2 &&
                data.email.trim().length >= 2 &&
               // data.indicatif.trim().length >= 0 &&
             //  data.numberPrimary.trim().length >= 6) ||
                contactList[0].indicatif.trim() != "" &&
                contactList[0].number.trim().length >= 6  ) ||
              (indexStep == 2 &&
                data.rccm.trim().length >= 0 &&
                data.nif.trim().length >= 0) ||
              (indexStep == 3 && data.statut.trim() != "---") ||
              (indexStep == 4 && true)) ?(
                <ButtonComponent
                  label={"Suivant"}
                  handleClick={() => {
                    if (indexStep == 4) {
                      data.currency =contactList[0].indicatif;
                      data.numbers =JSON.stringify(contactList);
                      data.nif =JSON.stringify(identificationsList);
                      //console.log(data);
                      
                      handleSubmit();
                      //router.back();
                      return;
                    }
                    setIndexStep((prev) => prev + 1);
                  }}
                  className=" bg-[#9a9768]  border-none min-h-[45px] w-[140px] font-bold "
                />
              ): 
              (
                <ButtonComponent
                  label={"Suivant"}

                  labelClassName="opacity-20"
                 
                  className=" bg-[#212121]/30 cursor-default  border-none min-h-[45px] w-[140px] font-bold "
                />
              )
              }
          </div>
        
       </div>

</div>
      
      </div>
    </div>
  );

  function newFunction() {
    return <div className="w-[100px]">{JSON.stringify(data)}</div>;
  }
}

export default Register;

function LefSection({ indexStep }) {
  return (
    <div className="border-r-[1px] pt-12 relative border-opacity-20 border-white w-[275px]">
      <ItemLeftSection
        index={0}
        indexStep={indexStep}
        Icon={BiSolidDashboard}
        label="Structure"
        subLabel="Modèle d'organisation"
      />
      <ItemLeftSection
        index={1}
        indexStep={indexStep}
        Icon={IoMdMap}
        label="Adresses"
        subLabel="Correspondance"
      />
      <ItemLeftSection2
        index={2}
        indexStep={indexStep}

        
        Icon={<svg width="19" height="24" viewBox="0 0 19 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10.5 8.16667V1.75L16.9167 8.16667M2.33333 0C1.03833 0 0 1.03833 0 2.33333V21C0 21.6188 0.245833 22.2123 0.683417 22.6499C1.121 23.0875 1.71449 23.3333 2.33333 23.3333H16.3333C16.9522 23.3333 17.5457 23.0875 17.9832 22.6499C18.4208 22.2123 18.6667 21.6188 18.6667 21V7L11.6667 0H2.33333Z" fill="#FFFFFF"/>
        </svg>
        }
        label="Documents"
        subLabel="Docs. administrative"
      />
      <ItemLeftSection
        index={3}
        indexStep={indexStep}
        Icon={IoIosFolder}
        label="Coordonnées"
        subLabel="Données enregistrées"
      />
      <ItemLeftSection
        index={4}
        indexStep={indexStep}
        Icon={IoMdAttach}
        label="Fichier joint"
        subLabel="Ajout de fichier"
      />
    </div>
  );

  function ItemLeftSection2({ label, subLabel, Icon, indexStep, index }) {
    return (
      <div className="relative h-[105px]   flex items-start gap-8">
        <div className="flex flex-col leading-[18px]  min-w-[145px] items-end justify-end">
          <p className="font-bold text-[18px] mt-2">{label}</p>
          <p className="text-sm opacity-50">{subLabel}</p>
        </div>
        <div
          className={`p-2 rounded-full z-20  ${
            indexStep >= index ? "bg-[#b9b9b9]" : "bg-[#4f4f4f]"
          } transition-all`}
        >
        <div  className={`w-8 h-8 ${
              indexStep >= index ? "opacity-100" : "opacity-50"
            } transition-all flex justify-center items-center`}>

          {Icon}
        </div>
        </div>

        <div
          className={`absolute w-3 h-3 rounded-full top-5  z-10 -right-[7px] ${
            indexStep >= index
              ? "border-2 bg-white border-[#757575]"
              : "bg-[#2b2b2b]  border-[#474747] border-2"
          }`}
        ></div>
        {label != "Fichier joint" && (
          <div
            className={`absolute w-[1px] z-10 h-full rounded-full top-5 bg-zinc-400 right-[73px] ${
              indexStep > index ? "opacity-50" : "opacity-20 transition-all"
            }`}
          ></div>
        )}
        {label != "Fichier joint" && (
          <div
            className={`absolute w-[1px] z-10 h-full rounded-full top-5 bg-zinc-400 -right-[1px] ${
              indexStep > index ? "opacity-100" : "opacity-20 transition-all"
            }`}
          ></div>
        )}
      </div>
    );
  }
  function ItemLeftSection({ label, subLabel, Icon, indexStep, index }) {
    return (
      <div className="relative h-[105px]   flex items-start gap-8">
        <div className="flex flex-col leading-[18px]  min-w-[145px] items-end justify-end">
          <p className="font-bold text-[18px] mt-2">{label}</p>
          <p className="text-sm opacity-50">{subLabel}</p>
        </div>
        <div
          className={`p-2 rounded-full z-20  ${
            indexStep >= index ? "bg-[#b9b9b9]" : "bg-[#4f4f4f]"
          } transition-all`}
        >
         { <Icon
            className={`w-8 h-8 ${
              indexStep >= index ? "opacity-100" : "opacity-50"
            } transition-all`}
          />}
        </div>

        <div
          className={`absolute w-3 h-3 rounded-full top-5  z-10 -right-[7px] ${
            indexStep >= index
              ? "border-2 bg-white border-[#757575]"
              : "bg-[#2b2b2b]  border-[#474747] border-2"
          }`}
        ></div>
        {label != "Fichier joint" && (
          <div
            className={`absolute w-[1px] z-10 h-full rounded-full top-5 bg-zinc-400 right-[73px] ${
              indexStep > index ? "opacity-50" : "opacity-20 transition-all"
            }`}
          ></div>
        )}
        {label != "Fichier joint" && (
          <div
            className={`absolute w-[1px] z-10 h-full rounded-full top-5 bg-zinc-400 -right-[1px] ${
              indexStep > index ? "opacity-100" : "opacity-20 transition-all"
            }`}
          ></div>
        )}
      </div>
    );
  }
}
