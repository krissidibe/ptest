import React, { useEffect } from "react";
import type { AppProps } from "next/app";

import "../styles/globals.css";
import UserLayout from "../components/Layout/UserLayout";
import useMenuStore from "../utils/MenuStore";
import Head from "next/head";
import { ModalProvider } from "../components/Items/modal-provider";
//const { webFrame } = require("electron");

function MyApp({ Component, pageProps }: AppProps) {
/*   useEffect(() => {
    if (window.innerWidth < 1440) {
      webFrame.setZoomFactor(0.9);
    } else {
      webFrame.setZoomFactor(1);
    }
  }, []); */

  const menuIndex = useMenuStore();

  if (menuIndex.index >= 0) {
    return (
      <>
        <Head>
          <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
          />
        </Head>
        <UserLayout>
         
          <Component {...pageProps} />
        </UserLayout>
      </>
    );
  } else {
    return <Component {...pageProps} />;
  }
}

export default MyApp;
