import React, { useState } from "react";
import { CiCircleCheck } from "react-icons/ci";

function Subscribe(props) {
  const [type, setType] = useState(0)
  return (
    <div className="flex flex-col items-center w-auto h-full px-24  pt-[105px]">
      <div className="flex flex-col items-center justify-center gap-1 tracking-wider xl:scale-75 xl:items-center">
        <h1 className="text-[42px]  xl:text-[78px]  leading-[40px] xl:leading-[80px]  font-semibold ">Des prix simples & transparents</h1>
        <h2 className="text-[24px] xl:text-[38px] opacity-50">
          Il y a forcément un plan pour vous. Commencez maintenant !
        </h2>
      </div>

      <div className="flex flex-1 flex-col items-center w-full h-full mt-14 rounded-tl-[30px]  justify-start pt-14 rounded-tr-[30px] overflow-scroll no-scrollbar  bg-gradient-to-b from-[#2b2b2b] via-[#00000000] to-[#00000000] ">
     {/*  <div className="flex h-[52px] min-w-[318px] items-center justify-center  font-bold bg-[#525252] rounded-full">
          <div onClick={()=> setType(0)} className={`${type == 0 ? "bg-white text-black" :"text-black"} flex items-center h-full text-[19px] px-6   rounded-full cursor-pointer`}>Mensuelle</div>
          <div onClick={()=> setType(1)} className={`${type == 1 ? "bg-white text-black" :"text-black"} flex items-center h-full text-[19px] px-6   rounded-full cursor-pointer`}>Abonnements</div>
        </div> */}

      { type ==0 ? <div className="flex items-center max-[1200px]:scale-75 max-[1200px]:flex-wrap  h-[300px] min-[1500px]:h-[370px] mt-14  max-[1200px]:mt-1 w-auto justify-center gap-5" >
               {/*   <ItemSubscribeCard key={1} number={1} price={10000}  /> */}
                 <ItemSubscribeCard style={"bg-transparent border border-[#9a9768]"} key={1} svg={<svg width="73" height="98" viewBox="0 0 73 98" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M36.1364 97.8519C29.1912 97.8519 23.0057 96.6582 17.5799 94.2708C12.185 91.8524 7.92179 88.5349 4.79028 84.3182C1.68977 80.0705 0.093015 75.1717 0 69.6218H20.2773C20.4013 71.9472 21.1609 73.9935 22.5562 75.7608C23.9824 77.4971 25.8737 78.8458 28.2301 79.807C30.5865 80.7681 33.2374 81.2487 36.1829 81.2487C39.2524 81.2487 41.9653 80.7061 44.3217 79.6209C46.6781 78.5358 48.5229 77.032 49.8561 75.1097C51.1893 73.1874 51.8559 70.9705 51.8559 68.4591C51.8559 65.9167 51.1428 63.6688 49.7166 61.7155C48.3214 59.7312 46.306 58.181 43.6706 57.0648C41.0662 55.9486 37.9657 55.3905 34.3691 55.3905H25.4861V40.6011H34.3691C37.4076 40.6011 40.0895 40.074 42.4149 39.0198C44.7713 37.9657 46.6006 36.5084 47.9028 34.6481C49.205 32.7568 49.8561 30.5555 49.8561 28.0441C49.8561 25.6567 49.2825 23.5638 48.1353 21.7655C47.0191 19.9362 45.4379 18.51 43.3916 17.4868C41.3762 16.4637 39.0198 15.9521 36.3224 15.9521C33.594 15.9521 31.0981 16.4482 28.8347 17.4403C26.5713 18.4015 24.7575 19.7812 23.3933 21.5795C22.0291 23.3778 21.3005 25.4861 21.2074 27.9045H1.90681C1.99982 22.4166 3.56558 17.5799 6.60407 13.3942C9.64257 9.2085 13.7352 5.93746 18.8821 3.58108C24.0599 1.19369 29.9044 0 36.4154 0C42.9885 0 48.7399 1.19369 53.6697 3.58108C58.5995 5.96847 62.4286 9.19299 65.1571 13.2547C67.9165 17.2853 69.2808 21.812 69.2498 26.8349C69.2808 32.1677 67.622 36.617 64.2734 40.1825C60.9559 43.7481 56.6307 46.0115 51.2978 46.9726V47.7168C58.305 48.6159 63.6378 51.0498 67.2964 55.0184C70.986 58.9561 72.8153 63.8859 72.7843 69.8078C72.8153 75.2337 71.2496 80.055 68.0871 84.2717C64.9556 88.4884 60.6304 91.8059 55.1115 94.2243C49.5926 96.6427 43.2675 97.8519 36.1364 97.8519Z" fill="white"/>
</svg>}  price={9890} />
                 <ItemSubscribeCard style={"bg-gradient-to-b from-[#8F8F91] to-[#424244]  "} key={2} svg={<svg width="74" height="99" viewBox="0 0 74 99" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M38.0432 98.3021C33.1444 98.2711 28.4161 97.4495 23.8584 95.8372C19.3316 94.2249 15.27 91.605 11.6734 87.9774C8.07681 84.3498 5.22435 79.5441 3.11601 73.5601C1.03867 67.5761 0 60.2279 0 51.5155C0.031005 43.5162 0.945654 36.3695 2.74395 30.0755C4.57324 23.7505 7.17767 18.3866 10.5572 13.9839C13.9678 9.58118 18.0449 6.23263 22.7887 3.93826C27.5325 1.61288 32.8498 0.450195 38.7408 0.450195C45.0968 0.450195 50.7087 1.6904 55.5765 4.1708C60.4443 6.6202 64.351 9.95324 67.2964 14.1699C70.2729 18.3866 72.0712 23.1149 72.6913 28.3547H52.8326C52.0575 25.0372 50.4297 22.4328 47.9493 20.5415C45.4689 18.6502 42.3994 17.7045 38.7408 17.7045C32.5398 17.7045 27.827 20.4019 24.6025 25.7968C21.409 31.1917 19.7812 38.5244 19.7192 47.7949H20.3703C21.7965 44.9734 23.7189 42.5705 26.1372 40.5862C28.5866 38.5709 31.3616 37.0361 34.4621 35.982C37.5936 34.8968 40.8956 34.3542 44.3682 34.3542C50.0111 34.3542 55.0339 35.6874 59.4367 38.3539C63.8394 40.9893 67.3119 44.6169 69.8544 49.2366C72.3968 53.8564 73.668 59.1427 73.668 65.0957C73.668 71.5448 72.1642 77.2807 69.1567 82.3035C66.1803 87.3263 62.0101 91.264 56.6462 94.1164C51.3133 96.9379 45.1123 98.3331 38.0432 98.3021ZM37.9502 82.4895C41.0507 82.4895 43.8256 81.7454 46.275 80.2572C48.7244 78.7689 50.6467 76.7536 52.042 74.2112C53.4372 71.6688 54.1348 68.8163 54.1348 65.6538C54.1348 62.4913 53.4372 59.6543 52.042 57.1429C50.6777 54.6315 48.7864 52.6317 46.368 51.1434C43.9496 49.6552 41.1902 48.9111 38.0897 48.9111C35.7643 48.9111 33.6095 49.3451 31.6251 50.2133C29.6718 51.0814 27.951 52.2906 26.4628 53.8409C25.0056 55.3911 23.8584 57.1894 23.0212 59.2358C22.1841 61.2511 21.7655 63.4059 21.7655 65.7003C21.7655 68.7698 22.4632 71.5758 23.8584 74.1182C25.2846 76.6606 27.2069 78.6914 29.6253 80.2107C32.0747 81.7299 34.8497 82.4895 37.9502 82.4895Z" fill="white"/>
</svg>
}  price={19750} />

                 <ItemSubscribeCard  style={"bg-gradient-to-b from-[#B7B781] to-[#999967] "} key={3} svg={<svg width="134" height="97" viewBox="0 0 134 97" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M42.5079 1.75241V96.9999H22.3701V20.867H21.812L0 34.5402V16.6813L23.5793 1.75241H42.5079Z" fill="white"/>
<path d="M65.1455 96.9999V82.4895L99.0495 51.0969C101.933 48.3065 104.351 45.7951 106.305 43.5627C108.289 41.3303 109.793 39.1445 110.816 37.0051C111.839 34.8348 112.351 32.4939 112.351 29.9825C112.351 27.192 111.715 24.7892 110.444 22.7738C109.173 20.7275 107.436 19.1617 105.235 18.0766C103.034 16.9604 100.538 16.4023 97.7473 16.4023C94.8328 16.4023 92.2904 16.9914 90.12 18.1696C87.9497 19.3478 86.2754 21.0375 85.0972 23.2389C83.919 25.4403 83.3299 28.0602 83.3299 31.0987H64.2153C64.2153 24.8667 65.626 19.4563 68.4475 14.8675C71.269 10.2788 75.2221 6.72872 80.3069 4.21731C85.3918 1.7059 91.2517 0.450195 97.8868 0.450195C104.708 0.450195 110.645 1.65939 115.699 4.07779C120.784 6.46517 124.737 9.78271 127.559 14.0304C130.38 18.2781 131.791 23.1459 131.791 28.6338C131.791 32.2304 131.078 35.7804 129.651 39.284C128.256 42.7876 125.76 46.6787 122.164 50.9574C118.567 55.2051 113.498 60.3054 106.956 66.2584L93.05 79.8851V80.5362H133.047V96.9999H65.1455Z" fill="white"/>
</svg>
}  price={39500} />
        </div>
      
      :<div className="flex flex-col items-center xl:w-[800px] justify-center bg-gradient-to-b from-[#303030] to-[#00000000] mt-14 px-[80px] pt-10 pb-10 rounded-3xl">
      <CiCircleCheck className="w-[120px] h-[120px] xl:w-[200px] xl:h-[200px] mb-3"/>
      
        <p className="text-[22px] xl:text-[28px] xl:leading-[30px] font-light">Félicitaion ! vous avez déjà un abonnement</p>
        <p className="text-[22px] xl:text-[28px] font-light">en cours valable jusqu'au 31/12/2023</p>
      </div>
      }
        <div>
            
        </div>
      </div>
    </div>
  );
}

export default Subscribe;
function ItemSubscribeCard({svg,price,style}) {
    return <div className={` relative h-full min-w-[215px]  ${style}  cursor-pointer rounded-[10px]  justify-center       px-8     flex flex-col    `}>

<div className="flex flex-col items-start leading-none border-b-[1px]  border-white/10 pb-2 ">
{svg}

<p className="text-[33px] mt-[18px] mb-[4px]" >MOIS</p>
<p className="text-[15px] text-[#ffffff]/40" >Offre spéciale</p>
</div>
<p className="text-[30px] flex items-start">{price.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")} <span className="pt-2 pl-2 text-base " >FCFA</span> </p>



    </div>;
}
function ItemSubscribeCardOld({number,price}) {
    return <div className={` relative h-full min-w-[215px] min-[1500px]:min-w-[275px] cursor-pointer rounded-[10px]   bg-gradient-to-bl from-[#929292] leading-[100px] px-8 pb-11  to-[#626262] flex flex-col justify-end ${number == 12 ? "from-[#e0da91] to-[#aaa670]  " : "" } `}>
<p className="text-[90px] min-[1500px]:text-[120px] min-[1500px]:mb-6 font-bold tracking-wider ">{number}</p>
<p className="mb-8 text-2xl tracking-wider min-[1500px]:mb-10 ">MOIS</p>
<p className="absolute text-[14px] opacity-50 bottom-[65px] min-[1500px]:bottom-[70px]">Offre spéciale</p>
<p className="flex gap-1 pt-2 text-3xl border-t-[1px] " > <span className="text-[24px] min-[1500px]:text-[30px] " >{price.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}</span>  <span className="text-sm">FCFA</span></p>
  
    </div>;
}

function ItemSubscribeCard2({number,price}) {
    return <div className={`relative h-full min-w-[215px] min-[1500px]:min-w-[275px] cursor-pointer rounded-[10px]   bg-gradient-to-bl from-[#929292] leading-[100px] px-8 pb-11  to-[#ffc7676f] flex flex-col justify-end ${number == 12 ? "from-[#e0da91] to-[#aaa670]  " : "" } `}>
<p className="text-[90px] min-[1500px]:text-[120px] min-[1500px]:mb-6 font-bold tracking-wider ">{number}</p>
<p className="mb-8 text-2xl tracking-wider min-[1500px]:mb-10 ">MOIS</p>
<p className="absolute text-[14px] opacity-50 bottom-[65px] min-[1500px]:bottom-[70px]">Offre spéciale</p>
<p className="flex gap-1 pt-2 text-3xl border-t-[1px] " > <span className="text-[24px] min-[1500px]:text-[30px] " >{price.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}</span>  <span className="text-sm">FCFA</span></p>
    </div>;
}

