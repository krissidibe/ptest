import React, { useState } from "react";
import { HiFolder, HiFolderAdd } from "react-icons/hi";
import { IoIosArrowBack, IoIosNotifications, IoIosPeople, IoMdBusiness } from "react-icons/io";

import { useRouter } from "next/router";
import ButtonComponent from "../../../components/UI/ButtonComponent";
import { HuePicker,AlphaPicker } from "react-color";
import PdfBuilder from "../../../components/PdfDemo";
import { LiaFileAltSolid } from "react-icons/lia";


function Factures(props) {

  function convertAlphaToHex(alphaDecimal) {
    // Convert alphaDecimal to a value between 0 and 1
    const alpha = alphaDecimal / 100;
  
    // Calculate the equivalent alpha value in the range of 0 to 255
    const alphaInt = Math.round(alpha * 255);
  
    // Convert alphaInt to hexadecimal string
    const alphaHex = alphaInt.toString(16).toUpperCase();
  
    // Pad the hexadecimal value with leading zero if needed
    const paddedAlphaHex = alphaHex.padStart(2, '0');
  
    return paddedAlphaHex;
  }
  const typeFactures = [
    {
      id: 1,
      label: "Tous",
    },
    {
      id: 2,
      label: "Classique",
    },
    {
      id: 3,
      label: "Moderne",
    },
    {
      id: 4,
      label: "Epuré",
    },
    {
      id: 5,
      label: "Minimaliste",
    },
    {
      id: 6,
      label: "Dynamique",
    },
    {
      id: 7,
      label: "Artistique",
    },
    {
      id: 8,
      label: "Personnalisé",
    },
    {
      id: 9,
      label: "Sombre",
    },
  ];
  
  const [saturationColor, setSaturationColor] = useState("100");
  const [saturationValue, setSaturationValue] = useState("FF");

  const [primaryColor, setPrimaryColor] = useState(`#ff60FF`);
  const [secondaryColor, setSecondaryColor] = useState(`#F8FF6A`);
  return (
    <div className="flex w-full h-full select-none">
      <div className="flex flex-col w-full h-full ">
        <SearchElement />
        <div className="flex p-10 ml-5 space-x-3 overflow-x-scroll text-sm pb-7 pt-7 no-scrollbar xl:w-full ">
          {typeFactures.map((item) => (
            <div
              key={item.id}
              className="p-2 px-3 flex justify-center items-center min-h-[28px] bg-white rounded-[10px] cursor-pointer group hover:text-white hover:bg-opacity-20 bg-opacity-10"
            >
              <p className="opacity-60 group-hover:opacity-100">
                {" "}
                {item.label}
              </p>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap w-full px-8 ml-6 overflow-scroll no-scrollbar md:items-start">
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
          <ItemFacture />
        </div>
      </div>

      <div className="h-full flex flex-col bg-[#151515] min-w-[340px]">
        <div className="h-[130px] border-b-[1px] flex items-end mx-10 pb-6  border-white border-opacity-20">
          <p className="flex items-center justify-center opacity-50"> 
          <LiaFileAltSolid className="mr-2 w-[20px] h-[20px] opacity-50" />
          Aperçu Fichier</p>
        </div>

        <div className="flex justify-center w-full mt-10">
          <div className=" rpv-print__body-printing  print__zone  min-h-[324px] cursor-pointer min-w-[244px] w-[244px] flex 0   bg-gradient-to-b from-[#ffffff] to-[#ffffff] gradient-opacity-10 m-[6px]">
          <PdfBuilder color={primaryColor.toString().substring(0,7) + saturationValue} />
          </div>
        </div>

        <div className="flex flex-col leading-[1.2rem] px-12 py-4 text-[15px] font-normal space-y-1  text-white text-opacity-40">
          <p className="">
            <span className="mr-2 font-bold text-white">Modèle :</span>{" "}
            <span>Classique 1</span>{" "}
          </p>
          <div className="flex flex-col leading-[1.2rem] px-2 py-4 space-y-1  border-white border-opacity-30">
            <div className="flex items-center justify-between space-x-4">
              <span className="ml-[20px] opacity-70" >Primaire</span>
              <HuePicker
                color={primaryColor}
                onChange={(color) => {
                  setPrimaryColor(color.hex+saturationValue);
                }}
                className="flex-1 max-w-[135px] scale-75"
              />{" "}
            </div>
            <div>

            <div className="flex items-center justify-between space-x-4">
              <span className=" opacity-70">Secondaire</span>
              <HuePicker
                color={secondaryColor}
                onChange={(color) => {
                  setSecondaryColor(color.hex + saturationValue);
                }}
                className="flex-1 max-w-[155px] scale-75"
              />{" "}
            </div>
            
            </div>
            
          </div>
          <div className="flex flex-col leading-[1.2rem] px-2 py-3 space-y-1 border-t border-white border-opacity-30">
        
            <div className="flex items-center justify-between space-x-[22px] pr-4 ">
              <span className=" opacity-70">Saturation  </span>
              <input id="small-range" type="range" onChange={(e) =>{
                 setSaturationColor(e.target.value)
                
              setSaturationValue(prev => convertAlphaToHex(e.target.value));
             
              
              }
                
               } value={saturationColor} className="w-full max-w-[100px]    h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer range-sm dark:bg-[#515151]"/>

             
            </div>
            <div className="hidden">
              <span className="ml-[30px]  opacity-70" >Corps   </span>{" "}
            </div>
              {/* <span>1 {JSON.stringify(primaryColor.toString().substring(0,5) + saturationValue   )}</span> 
              <span>2 {JSON.stringify(secondaryColor.toString().substring(0,5) + saturationValue   )}</span>  */}
          </div>

          <div className="flex justify-between gap-4 px-0 pt-8 border-t border-white border-opacity-30">
            <ButtonComponent
              label={"Aperçu"}
              labelClassName="text-[15px]"
              className="max-h-[35px] w-full border-none text-[12px] text-center items-center justify-center bg-[#2b2b2b]  text-opacity-60  "
            />
            <ButtonComponent
              label={"Appliquer"}
              labelClassName="text-[15px]"
              className="max-h-[35px] w-full border-none text-[12px] text-center items-center justify-center  text-opacity-60 bg-[#9a9768] "
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Factures;

function ItemFacture() { 
  
  return (
    <div className=" min-h-[280px] cursor-pointer min-w-[200px] flex p-4  rounded-md  bg-gradient-to-b from-[#ffffff13] to-[#ffffff25] gradient-opacity-10 m-[6px]">
      <div className="flex flex-col self-end text-sm ">
        <h3>Classique</h3>
        <h3 className="opacity-40">1</h3>
      </div>
    </div>
  );
}
function SearchElement() {
  const router = useRouter()
  return (
    <div className=" min-h-[130px] px-14 flex items-end mr-10 pb-6    relative    justify-start pr-10 border-b-[1px]  border-white border-opacity-20">
       <IoIosArrowBack
        onClick={() => {
          router.back();
        }}
        className="absolute w-8 h-8 font-bold cursor-pointer bottom-[25px] left-3"
      />
      
      <h3 className="ml-2 text-4xl font-bold">Modèles de Facture</h3>
    </div>
  );
}
