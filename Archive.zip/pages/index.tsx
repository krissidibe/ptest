import React from "react";
import Head from "next/head";
import Link from "next/link";
import ReactCrop, { type Crop } from "react-image-crop";
import { useState, useEffect } from "react";
import { FcGoogle } from "react-icons/fc";
import { AiFillApple } from "react-icons/ai";
import InputComponent from "../components/UI/InputComponent";
import ButtonComponent from "../components/UI/ButtonComponent";
import { useRouter } from "next/router";
import useMenuStore from "../utils/MenuStore";
import PdfBuilder from "../components/PdfDemo";

import { saveAs } from "file-saver";
import { useGlobalModal } from "../utils/use-global-modal";
import { IoMdClose } from "react-icons/io";

function Home(props) {
  async function fetchFacture() {
 
  
    const request = await fetch("paymefinance.com/api/pupe?email=Abouba");
    const dataBlob = await request.blob();

    const blob = new Blob([dataBlob], { type: "application/pdf" });
    console.log(blob);

    return blob;
  }

  /*   const [posts, setPosts] = useState([])
 
  async function fetchPosts() {
      const request = await fetch("https://jsonplaceholder.typicode.com/posts")
      const data = await request.json()
      setPosts(data)
  }

useEffect(()=>{
  fetchPosts()
}, []) 

*/

const [accessToken, setAccessToken] = useState("")
useEffect(()=>{

  setAccessToken(window.localStorage.getItem("accessToken"))
}, []) 

  const router = useRouter();
  const menuIndex = useMenuStore();
  const [modalView, setModalView] = useState(false);
  const [modalViewContent, setModalViewContent] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [data, setData] = useState<User>({
    email: "",
    image: "",
    name: "",
    address: "",
    country: "",
    countryPhoneCode: "",
    lockCode: false,
    code: "",
    number: "",
    password: "",
    normalSignUp: true,

    emailVerified: true,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (data.email.trim().length <= 5 && data.password.trim().length <= 5) {
      alert("Error ");
      return;
    }



    if(isLogin){
      const request = await fetch(`${process.env.BASE_API_URL}/api/login`, {
        headers: {
          "Content-type": "application/json",
        },
        method: "POST",
        body: JSON.stringify(data),
      });

      const result = await request.json();

    if(request.status ==200){
console.log(result.accessToken);

        window.localStorage.setItem("accessToken",result.accessToken)
        window.localStorage.setItem("userId",result.id)

        menuIndex.setMenuIndex(0)
        router.replace("/user")

    }
      


    if(request.status ==401){
      
      setModalView(x=> x=true);
      setModalViewContent(x=> x = result.message);
          }
      return;
    }

    /* 
    
    const request = await fetch(`${process.env.BASE_API_URL}/api/userfree`, {
      headers: {
        "Content-type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(data),
    });
    const result = await request.json();
    
    */


    const request = await fetch(`${process.env.BASE_API_URL}/api/userfree?email=${data.email}&password=${data.password}`, {
      headers: {
        "Content-type": "application/json",
      },
      method: "GET",
      
    });
    const result = await request.json();

    if (request.status == 200) {
      menuIndex.setMenuIndex(-10);
      router.push({
        pathname: "/auth/register",
        query: data as any,
      },"/auth/register");
    }else{
      setModalView(x=> x=true);
      setModalViewContent(x=> x = result.message);

 
    }
  };

  function InfoView() {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center pb-0 transition bg-black/40 ">
        <div
          onClick={() => {
            setModalView(false);
          
          }}
          className="absolute inset-0 z-30 flex items-center justify-center transition "
        ></div>
        <div className="p-4 py-0 bg-[#323232] z-50 w-[384px] min-h-[130px] px-7 flex flex-col items-center justify-start text-white rounded-xl">
          <IoMdClose
            onClick={() => {
              setModalView(false);
            }}
            className="w-[24px] h-[24px] opacity-60 mr-0 mt-5 cursor-pointer self-end"
          />
  
  <div className="px-10">
    <p>  {modalViewContent}</p>
  </div>

  <ButtonComponent
            key={2}
            handleClick={() => {
             // setInputValue("");
              setModalView(false);
            }}
            label={"Daccord"}
            className="max-h-[32px] min-w-[100px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#484848] border-none  rounded-md"
          />
  
          
  
         
        </div>
        
      </div>
    );
  }
  
  return (
    
    <React.Fragment>
       {modalView && InfoView()}
      <div className="h-screen bg-gradient-to-b p-10 pt-14 from-[#2e2e2ee3] flex justify-center items-center flex-col   to-[#060606]">
       <div className="flex items-center justify-center">
       <img className="h-[70px]  mb-10  " src="/images/logo-payme-complet.png" />
    
       </div>
        <form
          onSubmit={handleSubmit}
          className="w-[590px]  transition-all duration-500 flex flex-col p-8 px-16 items-center bg-gradient-to-b from-[#515151] to-[#2a2a2a] rounded-[50px]"
        >
       
          <p className="text-2xl font-light opacity-40">Identifiez-vous</p>
   
          <InputComponent
            name="email"
            value={data.email}
            onChange={handleChange}
            className="p-7  pl-[28px] my-6 font-normal mb-4  rounded-xl border-2 border-opacity-30"
            placeholder="Votre identifiant *"
          />

     { !isLogin &&    <InputComponent
            name="Nom & prenom"
            value={data.password}
            onChange={handleChange}
            className="p-7  pl-[28px] mb-4  mt-0 font-normal  rounded-xl border-2 border-opacity-30"
            placeholder="Nom & prenom *"
            type="text"
          />}
          <InputComponent
            name="password"
            value={data.password}
            onChange={handleChange}
            className="p-7  pl-[28px] mb-4  font-normal  rounded-xl border-2 border-opacity-30"
            placeholder="Votre mot de passe *"
            type="password"
          />
          {!isLogin && (
            <InputComponent
              className="p-7  pl-[25px] mb-4  rounded-xl border-2 border-opacity-30"
              placeholder="Repetter Votre mot de passe *"
              type="password"
            />
          )}

          <p className="self-end mb-8 mr-4 text-[13px]  font-light opacity-60">
            Mot de passe perdu ?
          </p>
          <div className="flex items-center justify-center w-full space-x-2 ">
            <div className="border rounded-full border-white/40">
            <ButtonComponent
              /*   handleClick={()=>{
              menuIndex.setMenuIndex(0)
              router.push("/user")
             
            }} */
              type="submit"
              labelClassName="text-[16px] "
              label={isLogin ? "Se connecter" : "S'inscrire"}
              className="flex-1 hover:bg-[#0606062E] h-[46px] border-1 border-opacity-100 border-white "
            />
            </div>
            <p className="text-sm opacity-50"> ou </p>

            <ButtonComponent
              handleClick={() => {
                menuIndex.setMenuIndex(-10);
                router.push("/auth/register");
              }}
              Icon={FcGoogle}
              label="Google"
              labelClassName="text-[16px] "
              className="bg-[#515151] border-none w-[130px] h-[46px]  "
            />
            <ButtonComponent
              handleClick={() => {
                menuIndex.setMenuIndex(0);
                router.push("/factureCalculator");
              }}
              Icon={AiFillApple}
              label="Apple ID"
              labelClassName="text-[16px] "
              className="bg-[#515151] border-none w-[130px] h-[46px] "
            />
          </div>
        </form>
        <div className="flex my-8 text-xl">
          <p className="font-light opacity-40">Vous êtes nouveau ici ?</p>
          <span
            onClick={() => {
              setIsLogin((x) => (x = !x));
              /*   const dd =  await  fetchFacture()
       
        saveAs(dd, "my super facture.pdf"); */
            }}
            className="ml-2 text-white cursor-pointer"
          >
            {isLogin ? "Créez un compte" : "Se connecter"}
          </span>
        </div>
        <p className="mt-4 text-[12px] font-light opacity-40">
          En cliquant sur les boutons de connexion ci-dessus, vous reconnaissez
          avoir lu, compris et accepté les <span className="underline">Conditions générales</span> et la <span className="underline">Politique
          de confidentialité </span> de Payme.
        </p>
      </div>
    </React.Fragment>
  );
}

export default Home;
