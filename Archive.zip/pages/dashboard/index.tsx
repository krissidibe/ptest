import React, { useEffect, useState } from "react";
import { HiFolder } from "react-icons/hi";
import { IoIosNotifications, IoIosSearch, IoMdClose, IoMdRefresh } from "react-icons/io";

import InputComponent from "../../components/UI/InputComponent";
import FolderComponent from "../../components/UI/FolderComponent";
import { useNewClientModal } from "../../utils/use-new-client-modal";
import { useRouter } from "next/router";
import { fetchAllCustomer } from "../../services/customerModel";
import { fetchAllProject } from "../../services/projectService";
import { daysFr } from "../../utils/helpers";
import { MdKeyboardArrowDown } from "react-icons/md";


import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { fetchAllWeekPlanningItem, fetchAllWeekPlanningItemDashboard, todayAllPlanningItem, todayDashboardAllPlanningItem } from "../../services/planningItemService";



function Dashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [showTodayPlanning, setShowTodayPlanning] = useState(false);
  const [showWeeksPlanning, setShowWeeksPlanning] = useState(false);
  const [showNotif, setShowNotif] = useState(false);
  const modal = useNewClientModal();
  const [search, setSearch] = useState("");
  const router = useRouter();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customersFiltered, setCustomersFiltered] = useState<Customer[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);

  const [todayDatas, setTodayDatas] = useState<any[]>([]);
  const [weeksDatas, setWeeksDatas] = useState<PlanningItem[]>([]);

  useEffect(() => {
    (async () => {
      const datasToday = await todayDashboardAllPlanningItem();
      setTodayDatas((x) => (x = datasToday));
      const dataProjects = await fetchAllProject();
      setProjects(dataProjects);
      setCustomers(await fetchAllCustomer("last"));
      setIsLoading(false);


      let date_today = new Date();

  
            let first_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                              - date_today.getDay() +1 ));

let last_day_of_the_week = new Date(date_today.setDate(date_today.getDate() 
                               - date_today.getDay() + 6 +1));
                         const datasWeeks =      await fetchAllWeekPlanningItemDashboard(first_day_of_the_week,last_day_of_the_week)

                         setWeeksDatas(datasWeeks)
                            






    })();

    return () => {};
  }, []);

  useEffect(() => {
    const datasFilter = customers.filter((item) =>
      item.name.toLowerCase().includes(search.toLowerCase())
    );
    setCustomersFiltered(datasFilter);
  }, [search]);

  const emptyRow = (
    <>
      <div className="flex h-[45px]  mb-3 duration-75 p-4  items-center text-white text-opacity-40 text-sm px-7 bg-[#2c2c2cb6] rounded-[20px]">
        <p className="w-[120px]   duration-100 xl:w-[130px] bg-[#FFFFFF11] p-[10px] rounded-full mr-[69px]">
          {" "}
        </p>
        <p className="w-[200px] mr-[75px] line-clamp-1  bg-[#FFFFFF11] p-[10px] rounded-full ">
          {" "}
        </p>
        <p
          className={`w-[175px]  ml-1   duration-200  bg-[#FFFFFF11]   mr-10 text-white bg-color-red-400 p-[10px] rounded-full items-center text-center flex justify-center text-opacity-100`}
        >
          {" "}
        </p>
        <p className="w-[200px] bg-[#FFFFFF11] p-[10px] rounded-full"></p>
      </div>
    </>
  );
  return (
    <div className="flex flex-col h-full select-none min-w-max">
      {SearchElement()}
<div className="absolute bottom-12 right-12  w-[315px]">
{/* 
  <ItemNotif2 key={1} title={"Nouvelle mise à jour"} content=""/>
  <ItemNotif key={1} title={"Nouvelle mise à jour"} content=""/> 
*/}
</div>
      <div className="flex-1 overflow-scroll no-scrollbar">
        <div className="flex flex-col flex-1 h-full px-8 pt-6">
        
          <h1 className="text-[44px] font-bold ml-4 mb-0">Clients récents </h1>

          <div className="flex lg:flex-row mb-3 ml-1 min-h-[200px]   no-scrollbar overflow-x-auto ">
            {isLoading ? (
              <>
                {" "}
                <FolderComponent key={1} isShimmer={true} />
                <FolderComponent key={2} isShimmer={true} />
                <FolderComponent key={3} isShimmer={true} />
                <FolderComponent key={4} isShimmer={true} />
                <FolderComponent key={5} isShimmer={true} />
              </>
            ) : (
              <>
                {customers.slice(0, 4).map((item) => (
                  <FolderComponent
                    key={item.id}
                    item={item}
                    handleClick={() => {
                      router.push({
                        pathname: "/gestions/client/clientshow",
                        query: item as any,
                      });
                    }}
                  />
                ))}
                {/*   {[1,2,3,4].slice(0,
                customers.length >= 4 ? 0 : customers.length == 3 ? 1 : customers.length == 2 ? 2 : customers.length == 1 ? 3 :  customers.length == 0 ? 4 : 4
                ).map(item=>(
                <FolderComponent key={item}   item={{name:""}}  className="cursor-default opacity-30" />

              ))} */}

                <FolderComponent
                  key={100}
                  handleClick={() => {
                    setShowNotif(x=>x = false)
                    setSearch("");
                    modal.onOpen();
                  }}
                  item={{ name: "NOUVEAU" }}
                  add={true}
                  className="opacity-30"
                />
              </>
            )}
          </div>
          <div className="flex-1 flex flex-col  h-full p-8 pb-0 bg-gradient-to-b overflow-scroll no-scrollbar from-[#1f1f1f]   to-[#060606] rounded-xl">
            <div className="flex flex-col flex-1 h-full overflow-hidden">
              <div className="flex justify-between mt-2 mb-2">
                <h3 className="w-auto pb-1 mx-4 text-[22px] font-semibold border-b-2 border-[#9a9768] ">
                  Projets récents
                </h3>
                  <IoMdRefresh
                  
                  onClick={async ()=>{
                    setIsLoading(true);

                    setTimeout(async() => {
                      const dataProjects = await fetchAllProject();
                      setProjects(dataProjects);
                      setCustomers(await fetchAllCustomer("last"));
                      setIsLoading(false);
                    }, 2000);
                   
                  }}
                  className="min-w-[25px] cursor-pointer h-[25px] opacity-50 font-bold mr-6" />
                
              </div>
              <div className="flex p-2 mt-4 overflow-scroll text-[14px] no-scrollbar px-7">
                <p className="w-[150px] xl:w-[200px]">Date</p>
                <p className="w-[280px]">Projet</p>
                <p className="w-[220px]">Statut</p>
                <p className="w-[200px]">Client</p>
              </div>

              <div className="flex flex-col flex-1 overflow-scroll no-scrollbar">
                {isLoading ? (
                  <>
                    <ItemProject key={301} isShimmer={true} />
                    <ItemProject key={302} isShimmer={true} />
                    <ItemProject key={303} isShimmer={true} />
                    <ItemProject key={304} isShimmer={true} />
                    <ItemProject key={305} isShimmer={true} />
                    <ItemProject key={306} isShimmer={true} />
                    <ItemProject key={307} isShimmer={true} />
                    <ItemProject key={308} isShimmer={true} />
                    <ItemProject key={309} isShimmer={true} />
                  </>
                ) : (
                  <>
                    {projects.map((item) => (
                      <ItemProject
                        key={item.createdAt.toString()}
                        item={item}
                        handleClick={() => {
                          router.push({
                            pathname: "/gestions/client/clientshow/projet",
                            query: item as any,
                          });
                        }}
                      />
                    ))}
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                      .slice(
                        0,
                        projects.length >= 10
                          ? 0
                          : projects.length == 7
                          ? 2
                          : projects.length == 6
                          ? 2
                          : projects.length == 5
                          ? 3
                          : projects.length == 4
                          ? 4
                          : projects.length == 3
                          ? 4
                          : projects.length == 2
                          ? 6
                          : projects.length == 1
                          ? 8
                          : projects.length == 0
                          ? 10
                          : 10
                      )
                      .map((item) => emptyRow)}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  function SearchElement() {
    return (
      <div className=" min-h-[100px]  flex items-center   justify-center lg:justify-end   pr-24 border-b-[1px]  border-white border-opacity-20">
        {search.length >= 3 || showNotif ? (
          <div
            onClick={() => {
              setSearch("");
              setShowNotif(false)
            }}
            className="absolute inset-0 z-10 bg-black opacity-50 "
          ></div>
        ) : null}
        <div className="flex-1"></div>
        <div className="relative md:w-[360px] mr-6 h-[40px] ">
          <IoIosSearch className="min-w-[23px] opacity-50 z-20 top-4 left-4 h-[23px] absolute" />

          <div className="relative ">
            <InputComponent
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher"
              className={`${
                search.length > 2
                  ? "border-b-[2px] p-[27px] border-white/5 border-x-0 border-t-0  "
                  : "rounded-full"
              } w-full pl-12 z-20 h-[50px] pr-8 border-[1px] border-white border-opacity-50`}
            />
            {search.length >= 3 ? (
              <div className="absolute top-0 rounded-full h-[50px]  z-10 w-full bg-[#444444]"></div>
            ) : null}
            <div
              className={`${
                search.length <= 2 ? "hidden" : ""
              } absolute w-full h-[495px] pl-12 pt-16 z-10 pr-8 rounded-3xl top-0 flex gap-3 flex-col overflow-scroll no-scrollbar   bg-gradient-to-b  from-[#434343] to-[#323232] `}
            >
              {customersFiltered.length == 0 && <div className="flex items-center justify-center flex-1 pb-10 pr-2 font-light opacity-40">Aucun contenu</div> }
              {customersFiltered.map((item) => (
                <div onClick={()=>{
                  router.push({
                    pathname: "/gestions/client/clientshow",
                    query: item as any,
                  });
                }} className="flex items-center justify-start cursor-pointer gap-2 border-b-[1px] pb-[6px] border-opacity-10 border-white ">
                  <HiFolder className={`min-w-[30px] h-[30px]`} />
                  <p className="text-sm line-clamp-1">
                    {item.name.toUpperCase()}{" "}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="relative">
         
      { !isLoading &&   <div className="absolute bg-red-500 rounded-full flex justify-center items-center h-[24px] w-[24px] text-xs -right-1 -top-2 text-center">{todayDatas?.length}</div>}
        <IoIosNotifications onClick={ async()=>{
          if(isLoading){
            return
          }
          setShowNotif(x=>x = !x )
         
         
          
        }} className="min-w-[40px] cursor-pointer h-[40px]" />
        </div>


<div
              className={`${
                !showNotif ? "hidden" : ""
              } absolute w-[330px] h-[476px]  pt-6 z-20 pb-4  rounded-xl right-12 top-[70px] flex gap-3 flex-col overflow-scroll no-scrollbar   bg-gradient-to-b  from-[#434343] to-[#323232] `}
            >
              
          <div className="flex items-center justify-center pb-4 text-xl border-b border-white/10">
            Notifications
          </div>
         
          <div className="absolute bottom-0 z-20 w-full h-10 bg-[#323232bd] blur-md "></div>
          <div className="flex flex-col gap-0 px-4 pb-2 overflow-scroll no-scrollbar">

        

          
            {/*  <ItemNotif key={2} title={"Echéance de l'abonnement"} content="Natus corporis quaerat delectus, tenetur animi voluptas adipisci, illo tempora sapiente , joplui uppez illo tempora sapiente"/> */}
             


             
        { todayDatas.length > 0 &&  <div 
          onClick={()=>{
            setShowTodayPlanning(x=> x = !x)
          }}
          className="flex justify-between pl-3 opacity-50 cursor-pointer hover:opacity-80 ">   <h3 className="mb-2 ">Tâche du jour</h3>  
          
          <MdKeyboardArrowDown className={`w-6 mr-4 h-6 ${!showTodayPlanning ? "rotate-180":""} `}  />
          
          </div>}

          
            {todayDatas.length > 0 && !showTodayPlanning && <ItemNotifTodoCollapse
            handleClick={()=>{
              setShowTodayPlanning(x=> x = !x)
            }}
            
           item={todayDatas[todayDatas.length-1]}  />}
          
             {showTodayPlanning && <>
             
      
           {todayDatas.map(item=>(
            <ItemNotifTodo key={item.id} mb={true}  item={item} />
           ))}
           
             </> }
             <div 
          onClick={()=>{
            setShowWeeksPlanning(x=> x = !x)
          }}
          className="flex justify-between pl-3 opacity-50 cursor-pointer hover:opacity-80 ">   <h3 className="mb-2 ">Tâche de la semaine</h3>  
          
          <MdKeyboardArrowDown className={`w-6 mr-4 h-6 ${!showWeeksPlanning ? "rotate-180":""} `}  />
          
          </div>

          
            {!showWeeksPlanning && <ItemNotifTodoCollapse
            handleClick={()=>{
              setShowWeeksPlanning(x=> x = !x)
            }}
            
           item={weeksDatas[weeksDatas.length-1]}  />}
          
             {showWeeksPlanning && <>
             
      
           {weeksDatas.map(item=>(
            <ItemNotifTodo key={item.id} mb={true}  item={item} />
           ))}
           
             </> }
           
            {/*  <div className="flex justify-between opacity-50 cursor-pointer hover:opacity-80 ">   <h3 className="mb-2 ">Tâche de demain</h3>  
          
          <MdKeyboardArrowDown className="w-6 h-6"  />
          
          </div>
       
             <ItemNotifTodo date={"10-10-2023"} heure={"14:30"} key={5} title={"Reunion avec Bank"} content="Natus corporis quaerat delectus, tenetur animi voluptas adipisci, illo tempora sapiente , joplui uppez illo tempora sapiente"/> */}
        
             <div className="w-full"></div>
          </div>
            </div>


      </div>
    );
  }
}

export default Dashboard;

function ItemNotifTodoCollapse({item,handleClick}) {
  return(
    <div onClick={handleClick} className="min-h-[140px]  relative">
       <div className="absolute left-0 z-50 w-full ">
    <ItemNotifTodoLast mb={false} date={daysFr(item?.date)} heure={item?.date.toString().substr(11, 5)} key={3} title={item?.name} content={item?.content}/>
    </div>

    <div className="z-40 w-[285px] left-[7px] absolute top-[10px]  bg-gradient-to-b from-[#666666]  to-[#545454]  min-h-[103px] rounded-md"></div>
   {/*  <div className="z-30 w-[280px] left-[9px] absolute top-[12px] bg-[#424242]  min-h-[103px] rounded-md"></div> */}
    <div className="z-20 w-[272px]   shadow-md shadow-[#323232]   left-[13px] absolute top-[14px] bg-gradient-to-r from-[#666666]    to-[#666666]   min-h-[103px] rounded-md"></div>
    </div>
  )
 
 
}
function ItemNotifTodoLast({title,content,date,heure,mb=true}) {
  return <div className={`flex flex-col p-4 py-3 ${mb ? "mb-2" : ""}  pt-[10px] h-[108px]  bg-gradient-to-b from-[#5b5b5b] to-[#4a4a4a]   cursor-pointer rounded-md opacity-100 hover:opacity-100 border-white/10`}>
    <h3 className={`${title == "Mise à jour de l'application" ? "text-teal-500" :" text-primary  " } text-[13px]`}>{title}</h3>
    <div className="flex flex-col flex-1 ">
    <p className="text-[12px] leading-[15px] flex-1 line-clamp-3  font-light opacity-90">{content}</p>
    <p className="mt-1 text-[11px] font-light text-teal-400 opacity-90">{date} <span className="ml-1">{heure}</span></p>
    <div>
    
    </div>
     
     </div>
  </div>;
}
function ItemNotifTodo({item,mb=true}:{item:PlanningItem,mb:boolean}) {
  const router = useRouter();
  return <div
  
  onClick={()=>{

    router.push({
      pathname: "/gestions/planning",
      query: item as any,
    });

  }}
  
  className={`flex flex-col p-4 py-3 ${mb ? "mb-2" : ""}  pt-[10px]  bg-gradient-to-b from-[#5b5b5b]   to-[#444444]   cursor-pointer rounded-md opacity-80 hover:opacity-100 border-white/10`}>
    <h3 className={`text-primary text-[13px]`}>{item.name}</h3>
    <div className="flex flex-col">
    <p className="text-[12px] leading-[15px] font-light opacity-90">{item.content}</p>
    <p className="mt-1 text-[11px] font-light text-teal-400 opacity-90">{daysFr(item.date)} <span className="ml-1">
    
      {item.date.toString().substr(11, 5)}</span></p>
    <div>
    
    </div>
     
     </div>
  </div>;
}
function ItemNotif2({title,content}) {

  return <div className="  flex flex-col p-4 py-3  mb-2  font-bold  pt-[10px]  bg-gradient-to-b from-[#ffffff] text-black   to-[#ffffffc0]   cursor-pointer rounded-md opacity-80 hover:opacity-100 border-white/10">
   <div className="flex justify-between">
    <h3 className={` " text-black text-sm`}>Échéance de l'abonnement   </h3>
    <IoMdClose
              onClick={() => {
        
               
              }}
              className="w-[20px] h-[20px] opacity-100 mr-0  absolute right-3   cursor-pointer "
            />
   </div>
   
    <div className="flex">
    <p className="text-xs font-light opacity-100
    text-[12px] leading-[15px]  
    
    ">
 Votre abonnement pour arrive bientôt à échéance. Renouvelez-le à temps pour ne pas interrompre votre utilisation. 
    </p>
    <div>
   
    </div>
     
     </div>
  </div>;
}
function ItemNotif({title,content}) {

  return <div className="  flex flex-col p-4 py-3  mb-2  font-bold  pt-[10px]  bg-gradient-to-b from-[#ffffff] text-black   to-[#ffffffc0]   cursor-pointer rounded-md opacity-80 hover:opacity-100 border-white/10">
   <div className="flex justify-between">
    <h3 className={` " text-black text-sm`}>{title}   </h3>
    <IoMdClose
              onClick={() => {
        
               
              }}
              className="w-[20px] h-[20px] opacity-100 mr-0  absolute right-3   cursor-pointer "
            />
   </div>
   
    <div className="flex">
    <p className="text-xs font-light opacity-100
    text-[12px] leading-[15px]  
    
    ">
Mise à jour 1.1 : Profitez des améliorations  <br /> et des nouvelles fonctionnalités en la téléchargeant maintenant.

    </p>
    <div>
   
    </div>
     
     </div>
  </div>;
}

function ItemProject({
  isShimmer = false,
  item = null,
  handleClick = () => {},
}) {
  let type = {
    border: "",
    color: "",
    label: "",
  };
  switch (item?.type) {
    case "INPROGRESS":
      type = {
        border: "border-amber-600/50 ",
        color: "bg-amber-600/50 ",
        label: "En cours de validation",
      };
      break;
    case "ISVALIDATE":
      type = {
        border: "border-green-600/50 ",
        color: "bg-green-600/50 ",
        label: "Proforma validée",
      };
      break;
    case "ISFINISH":
      type = {
        border: "border-teal-600/50 ",
        color: "bg-teal-600/50 ",
        label: "Projet terminer",
      };
      break;

    default:
      break;
  }
  return isShimmer ? (
    <>
      <div className="flex h-[49px] mb-3 duration-75 p-4    items-center text-white animate-pulse text-opacity-40 text-sm px-7 bg-[#2c2c2ce1] rounded-3xl">
        <p className="w-[120px] animate-pulse duration-100 xl:w-[170px] bg-[#ffffff1f] p-3 rounded-full mr-8">
          {" "}
        </p>
        <p className="w-[200px] mr-24 line-clamp-1  bg-[#ffffff1f] p-3 rounded-full ">
          {" "}
        </p>
        <p
          className={`w-[175px] animate-pulse   duration-200  bg-[#ffffff1f]   mr-10 text-white bg-color-red-400 p-3 rounded-full items-center text-center flex justify-center text-opacity-100`}
        >
          {" "}
        </p>
        <p className="w-[200px] bg-[#ffffff1f] p-3 rounded-full"></p>
      </div>
    </>
  ) : (
    <>
      <div
        onClick={handleClick}
        className="flex h-[49px] mb-3 p-4 items-center cursor-pointer text-white text-opacity-40 text-sm px-7 bg-[#2c2c2ce1] rounded-3xl"
      >
        <p className="w-[120px] xl:w-[170px] mr-8">
          {daysFr(`${item.createdAt}`)}{" "}
        </p>
        <p className="w-[280px] line-clamp-1  ">{item.name}</p>
        <p
          className={`w-[175px] mr-10 text-white ${type.color} p-3 rounded-full items-center text-center flex justify-center text-opacity-100 py-[2px] text-[12px]`}
        >
          {type.label}
        </p>
        <p className="w-[200px]">{item.customer.name}</p>
      </div>
    </>
  );
}
