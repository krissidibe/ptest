import React, { useEffect, useState } from "react";
import {
  IoIosArrowBack,
  IoMdInformationCircleOutline,
  IoMdArrowDropdown,
  IoMdTrash,
} from "react-icons/io";
import ButtonComponent from "../../../../components/UI/ButtonComponent";
import InputComponent from "../../../../components/UI/InputComponent";
import { v4 as uuidv4 } from "uuid";
import { useRouter } from "next/router";
import useMenuStore from "../../../../utils/MenuStore";
import { saveInvoice } from "../../../../services/projectService";
import { Menu } from "@headlessui/react";
import { ToWords } from "to-words";
import { useGlobalModal } from "../../../../utils/use-global-modal";
function FactureCalculator() {
  const router = useRouter();
  const modal = useGlobalModal();
  const projectInfo = router.query;
  const toWords = new ToWords({
    localeCode: "fr-FR",
    converterOptions: {
      currency: false,
    },
  });

  const [optionShow, setOptionShow] = useState(true);

  const factureType = ["0", "1"];
  const modalityValues = [
    "0",
    "10",
    "20",
    "30",
    "40",
    "50",
    "60",
    "70",
    "80",
    "90",
    "100",
  ];

  const device = "FCFA";
  const [modality, setModality] = useState(
    projectInfo?.modalite == undefined ? "0" : projectInfo.modalite
  );
  const [tvaValue, setTvaValue] = useState(
    projectInfo?.tva == undefined ? "" : projectInfo?.tva
  );
  const [remiseValue, setRemiseValue] = useState(
    projectInfo?.discount == undefined ? "" : projectInfo?.discount
  );
  const [factureTypeValue, setFactureTypeValue] = useState(
    projectInfo?.invoiceType == undefined ? "0" : projectInfo.invoiceType
  );
  const [remarque, setRemarque] = useState(
    projectInfo?.remarque == undefined ? "" : projectInfo.remarque
  );
  const menuIndex = useMenuStore();

  console.log(projectInfo);
  const [datas, setDatas] = useState([]);

  useEffect(() => {
    setDatas(
      projectInfo?.table != ""
        ? JSON.parse(projectInfo.table)
        : [
            {
              id: uuidv4(),
              designation: "",
              quantity: "",
              rate: "",
              amount: "",
            },
          ]
    );
  
    return () => {
      
    }
  }, [])
  

  function totalTTC() {
    const value = isNaN(totalsHT() - totalsRemise() + totalsTVA())
      ? 0
      : totalsHT() - totalsRemise() + totalsTVA();

    return parseInt(value);
  }

  function modaliteWithPourcent() {
    //  const value = (totalsHT() * parseInt(modalityValues == "" ? 0 : modalityValues))/100
    const value = (totalTTC() * parseInt(modality == "" ? 0 : modality)) / 100;

    return parseInt(value);
  }
  function totalsHT() {
    const value = datas.reduce(function (previousVal, currentVal) {
      return previousVal + currentVal.amount;
    }, 0);

    return parseInt(value);
  }
  function totalsRemise() {
    const value =
      (totalsHT() * parseInt(remiseValue == "" ? 0 : remiseValue)) / 100;

    return parseInt(value);
  }
  function totalsTVA() {
    const value =
      ((totalsHT() - totalsRemise()) *
        parseInt(tvaValue == "" ? 0 : tvaValue)) /
      100;

    return parseInt(value);
  }

  const saveData = async () => {
const totalAmount = totalTTC()
    
    const data = await saveInvoice(projectInfo.id, {
      table: JSON.stringify(datas),
      tva: tvaValue.trim(),
      discount: remiseValue.trim(),
      modalite: modality.trim(),
      invoiceType: parseInt(factureTypeValue.trim()),
      remarque: remarque.trim(),
      amountTotal: totalAmount,
    });


    
    if (data) {
      modal.onClose();
      router.back();
    }
  };

  return (
    <>
      <div className="flex flex-row h-screen ">
        <div className="flex-1">
          <div className="flex flex-col w-full h-full ">
            {SearchElement()}
            {/*             <SearchElement handleToggle={()=>{setOptionShow(x => x = !x)}} /> */}

            <div className="flex flex-col flex-1 px-10 pt-2 overflow-hidden ">
              <div className="flex py-2 mt-4  font-bold bg-[#b6b6b618]    border-2 border-[#ffffff00] ">
                <p className="select-none flex-1 min-w-[200px]  max-h-5 text-center border-r  border-[#ffffff] ">
                  Désignation
                </p>
                <p className="select-none w-[170px] border-r  max-h-5 border-[#ffffff] text-center ">
                  Quantité
                </p>
                <p className="select-none w-[170px] border-r  max-h-5 border-[#ffffff] text-center ">
                  Prix unitaire
                </p>
                <p className="select-none w-[170px]   text-center ">Montant</p>
              </div>

              <div className="flex flex-col  flex-1  overflow-scroll  no-scrollbar border-0 border-[#ffffff20]  ">
                {datas.map((item) => (
                  <ItemGestion
                
                    handleDelete={() => {
                      const datasNew = datas.filter((x) => x.id != item.id);
                    
                      setDatas(datasNew);
                      modal.onClose();
                    }}
                    item={item}
                    key={item.id}
                    updateTable={(
                      designationValue,
                      quantityValue,
                      rateValue,
                      amount
                    ) => {
                      const dataFind = datas.find((x) => x.id == item.id);
                      dataFind.designation = designationValue;
                      dataFind.quantity = quantityValue;
                      dataFind.rate = rateValue;
                      dataFind.amount = isNaN(amount) ? 0 : amount;

                      setDatas([...datas]);
                    }}
                  />
                ))}
                {/*                 {JSON.stringify(datas)} */}
              </div>
              {ItemFooter()}
            </div>
          </div>
        </div>

        {optionShow && (
          <div className="min-w-[440px] max-w-[440px] p-10 px-8 bg-gradient-to-b pt-[60px] from-[#736f40] to-[#615e38] h-full">
            <IoIosArrowBack
              onClick={() => {
                setOptionShow(false);
              }}
              className="w-8 h-8 cursor-pointer"
            />
            <div className="text-[#fff134] mt-4 mb-4 flex justify-start font-bold text-xl">
              <p className="mr-10"> Montant {tvaValue == 0 ? "HT" : "TTC"} :</p>
              <p className="">
                {" "}
                {totalTTC().toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")} {device}
              </p>
            </div>
            <div className="pb-4 mb-4 border-b border-white/10 ">
              <p className="text-sm">
                Arrêtée la présente facture à la somme de :
              </p>
              <p className="text-sm ">
                {toWords
                  .convert(totalTTC())
                  .replaceAll("Et", "")
                  .replaceAll("-", " ")}{" "}
                {device}
              </p>
            </div>

            <div className="w-48 bg-white shadow-md"></div>

            <div className="flex flex-col gap-4 pt-2 mb-4">
              <div className="flex items-center justify-between">
                <p className="text-[17px] font-bold">Modalité du paiement</p>
                <div className="flex relative  min-w-[50px]   cursor-pointer text-[#fff134]  border-b  border-[#fff134]   items-center">
                  <Menu>
                    <Menu.Button className="relative flex items-center gap-0 pb-1 pr-6 text-sm font-medium ">
                      <p className="self-start text-sm font-bold">{modality}</p>
                      <p className="self-end ml-1 text-sm font-bold ">%</p>
                      <IoMdArrowDropdown className="absolute right-0 w-6 h-6"  />
                    </Menu.Button>
                    <Menu.Items className="absolute min-w-[70px] z-20 right-0  flex flex-col justify-center w-full   bg-[#313131] top-8">
                      {modalityValues.map((item) => (
                        <Menu.Item>
                          {({ active }) => (
                            <p
                            key={item}
                              onClick={() => {
                                setModality((x) => (x = item));
                              }}
                              className={`block px-4 py-2 ${
                                active ? " bg-[#313131]" : "bg-white/10"
                              }`}
                            >
                              {item}
                            </p>
                          )}
                        </Menu.Item>
                      ))}
                    </Menu.Items>
                  </Menu>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold">Type de facture : </p>
                <div className="flex relative  min-w-[160px]    cursor-pointer text-[#fff134]  border-b  border-[#fff134]   items-center">
                  <Menu>
                    <Menu.Button  className="flex items-center justify-between gap-2 pb-0 text-sm font-medium ">
                      <p className="self-start mr-1 text-sm ">
                        {factureTypeValue == "0"
                          ? "Facture d'acompte"
                          : "Facture de reliquat"}
                      </p>{" "}
                      <IoMdArrowDropdown className="w-6 h-6" />
                    </Menu.Button>
                    <Menu.Items className="absolute  min-w-[100px] z-20 right-0  flex flex-col justify-center w-full   bg-[#2f2d1a] top-8">
                      <Menu.Item>
                        {({ active }) => (
                          <p
                            onClick={() => {
                              setFactureTypeValue((x) => (x = "0"));
                            }}
                            className={`block px-4 py-2 text-sm ${
                              active ? " bg-[#615d36] opacity-100 " : " opacity-50"
                            }`}
                          >
                            Facture d'acompte
                          </p>
                        )}
                      </Menu.Item>
                      <Menu.Item>
                        {({ active }) => (
                          <p
                            onClick={() => {
                              setFactureTypeValue((x) => (x = "1"));
                            }}
                            className={`block px-4 py-2 text-sm ${
                              active ? " bg-[#615d36] opacity-100 " : " opacity-50"
                            }`}
                          >
                            Facture de reliquat
                          </p>
                        )}
                      </Menu.Item>
                    </Menu.Items>
                  </Menu>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2 pt-6 pb-4 mb-4 border-b border-white/10">
              <div className="flex items-center justify-between">
                <p className="text-sm ">
                  {factureTypeValue == "0"
                    ? "Acompte à payer"
                    : "Acompte déjà payé"}{" "}
                </p>
                <p className="text-sm ">
                  {modaliteWithPourcent().toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
                </p>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm ">
                  {factureTypeValue == "0"
                    ? "Reliquat a la livraison"
                    : "Reliquat à payer"}{" "}
                </p>
                <p className="text-sm ">
                  {(totalTTC() - modaliteWithPourcent()).toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
                </p>
              </div>
            </div>

            <p className="pt-3 text-sm">Remarque :</p>

            <textarea
              value={remarque}
              onChange={(e) => {
                setRemarque(e.target.value);
              }}
              className="w-full p-2 mt-2 outline-none bg-transparent border rounded-md text-sm min-h-[140px]  border-white/10 border-opacity-10"
            ></textarea>
          </div>
        )}
      </div>
    </>
  );

  function SearchElement() {
    return (
      <div className="w-full min-h-[110px] flex items-end  bg-[#b6b6b618] pb-4    justify-between pr-[60px] pl-8  ">
        <div className="flex space-x-4">
          <IoIosArrowBack
            onClick={() => {
              menuIndex.setMenuIndex(2);
              router.back();
            }}
            className="w-8 h-8 cursor-pointer"
          />
          <h3 className="text-2xl font-bold">Faire un devis</h3>
        </div>
        <div className="flex space-x-4">
          <ButtonComponent
          labelClassName="text-[16px]"
            key={"option"}
            label={"Option"}
            handleClick={() => {
              setOptionShow((x) => (x = !x));
            }}
            className="bg-[#838383] border-none w-[100px] font-bold py-2"
          />
          <ButtonComponent
          labelClassName="text-[16px]"
            key={"Enregistré"}
            handleClick={() => {
              saveData();
              return;

              modal.onSubmit = (
                <ButtonComponent
                key={"submit"}
                  handleClick={async () => {
                  

                    // handleSubmit()
                  }}
                  label={"Oui"}
                  className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                />
              );
              modal.onOpen();
              modal.setTitle("Êtes-vous sûr ?");
              modal.setMessage("Voulez vousxxx");
            }
          }
            label={"Enregistré"}
            className="bg-[#9a9768] border-none w-[130px] font-bold py-2"
          />
        </div>
      </div>
    );
  }
  function ItemFooter() {
    return (
      <div className="flex  flex-col  my-4 gap-1  select-none   border-[#ffffff20] ">
        <div className="flex w-full ">
          <p
            onClick={() => {
              setDatas([
                ...datas,
                {
                  id: uuidv4(),
                  designation: "",
                  quantity: "",
                  rate: "",
                  amount: "",
                },
              ]);
            }}
            className="flex-1 min-w-[20px]  font-bold cursor-pointer py-2 text-center text-primary bg-[#b6b6b618]   border-[#00000020] border-r-4 mr-1 "
          >
            + Nouveau élément
          </p>
          <div className="py-2 w-[340px]   bg-[#ffffff13]  text-center ">
            <p className="border-[#ffffff] max-h-5  font-bold border-r ">
              MONTANT TOTAL HT
            </p>
          </div>

          <p className="w-[170px] border-[#ffffff20] py-2  bg-[#ffffff13]  text-center ">
            {isNaN(totalsHT()) ? 0 : totalsHT().toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
          </p>
        </div>
        <div className="flex w-full">
          <p className="flex-1 min-w-[20px] text-center text-primary bg-[#b6b6b600]   border-[#00000020] border-r "></p>

          <div className="py-1 w-[340px]   bg-[#ffffff09]   text-center ">
            <div className="border-[#ffffff] flex text-teal-500/80  self-end justify-end w-full pr-4 i border-r ">
              <div className="flex items-center self-end gap-2">
                <span className="text-[14px] font-bold  ">Remise</span>
                <InputComponent
                  placeholder="0"
                  maxLength={2}
                  value={remiseValue}
                  onChange={(e) => {
                    if (!/[0-9]/.test(e.target.value) && e.target.value != "") {
                      return;
                    }

                    setRemiseValue(e.target.value);
                  }}
                  className="max-w-[40px]  px-[1px]  text-center self-end max-h-[30px]"
                />
                <span className="text-sm text-white ">%</span>
              </div>
            </div>
          </div>

          <p className="w-[170px]  text-teal-500 bg-[#ffffff09] border-[#ffffff20] flex justify-center items-center   text-center ">
            {remiseValue == "" ? "" : "-"}{" "}
            {isNaN(totalsRemise()) ? 0 : totalsRemise().toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
          </p>
        </div>
        <div className="flex w-full">
          <p className="flex-1 min-w-[20px] text-center text-primary bg-[#b6b6b600]   border-[#00000020] border-r "></p>

          <div className="py-1 w-[340px]   bg-[#ffffff09]   text-center ">
            <div className="border-[#ffffff] flex text-primary  self-end justify-end w-full pr-4 i border-r ">
              <div className="flex items-center self-end gap-2">
                <span className="text-[15px] font-bold">TVA</span>
                <InputComponent
                  type="text"
                  value={tvaValue}
                  maxLength={2}
                  onChange={(e) => {
                    if (!/[0-9]/.test(e.target.value) && e.target.value != "") {
                      return;
                    }
                    setTvaValue(e.target.value);
                  }}
                  placeholder="0"
                  className="max-w-[40px]  px-[1px] text-center self-end max-h-[30px]"
                />
                <span className="text-sm text-white">%</span>
              </div>
            </div>
          </div>

          <p className="w-[170px] text-primary bg-[#ffffff09] border-[#ffffff20] flex justify-center items-center   text-center ">
            {isNaN(totalsTVA()) ? 0 : totalsTVA().toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
          </p>
        </div>
        <div className="flex w-full">
          <p className="flex-1 min-w-[20px] py-2 text-center text-primary bg-[#b6b6b600]   border-[#00000020] border-r "></p>

          <div className="py-2 w-[340px]   bg-[#ffffff13]  text-center ">
            <p className="border-[#ffffff] font-bold max-h-5  border-r ">
              MONTANT TOTAL TTC
            </p>
          </div>

          <p className="w-[170px]  bg-[#ffffff13] border-[#ffffff20] flex justify-center items-center  text-center ">
            {totalTTC().toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
          </p>
        </div>
      </div>
    );
  }
}

export default FactureCalculator;

 


function ItemGestion({
  item,
  designationDefult = "",

  handleDelete = () => {},
  updateTable = (designation, quantity, rate, amount) => {},
}) {
  const [designation, setDesignation] = useState(item.designation);
  const [quantity, setQuantity] = useState(parseInt(item.quantity));
  const [rate, setRate] = useState(parseInt(item.rate));
  const [amount, setAmount] = useState(quantity * rate);
  const modal = useGlobalModal();
  return (
    <div className="flex group   relative   pt-[0px]  border-b border-x-2  border-[#ffffff11] ">
      {/*  <IoMdInformationCircleOutline
     //   onClick={handleDelete}
        className="absolute hidden w-6 h-6 cursor-pointer group-hover:block hover:block right-1 top-5"
      /> */}

      <Menu>
        <Menu.Button className="absolute items-center justify-between hidden w-6 h-6 gap-2 py-2 text-sm font-medium cursor-pointer opacity-40 top-1 group-hover:block hover:block right-2 ">
          <p className="self-start mr-6 text-sm font-bold">
            <IoMdInformationCircleOutline
              //   onClick={handleDelete}
              className="w-6 h-6 cursor-pointer group-hover:block hover:block "
            />
          </p>
        </Menu.Button>
        <Menu.Items className="absolute  max-w-[220px]    z-20 right-0  flex flex-col justify-center w-full   bg-[#2b2b2b] top-2">
          <Menu.Item>
            {({ active }) => (
              <p
                onClick={() => {
                  modal.onSubmit = (
                    <ButtonComponent
                      handleClick={async () => {
                        handleDelete();
                      }}
                      label={"Supprimer"}
                      className="   mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  "
                    />
                  );
                  modal.onOpen();
              modal.setTitle("Êtes-vous sûr ?");
              modal.setMessage("Êtes-vous sûr de vouloir supprimer cet élément ?");
                }}
                className={`  px-0   py-4 flex justify-center items-center gap-2 rounded-md text-[17px] cursor-pointer ${
                  active ? " bg-[#212121]" : " "
                }`}
              >
             <IoMdTrash className="w-6 h-6 " />  <p> Supprimer la liste </p>
              </p>
            )}
          </Menu.Item>
        </Menu.Items>
      </Menu>

      <div className="flex-1 min-w-[20px] text-center border-[#ffffff20] border-r ">
        <InputComponent
          key={item.id}
          value={designation}
          placeholder="-"
          onChange={(e) => {
            setDesignation((x) => (x = e.target.value));
            updateTable(e.target.value, rate, quantity, amount);
          }}
          
          className="h-10 p-0 text-center text-white border-none"
        />
      </div>
      <div className="w-[170px] border-[#ffffff20]  border-r text-center ">
        <InputComponent
          key={item.id}
          type="number"
          value={item.quantity}
          placeholder="0"
          onChange={(e) => {
            setAmount((x) => (x = parseInt(e.target.value) * parseInt(rate)));
            setQuantity((x) => (x = e.target.value));
            updateTable(
              designation,
              e.target.value,
              rate,
              parseInt(e.target.value) * parseInt(rate)
            );
          }}
          className="h-10 p-0 text-center border-none "
        />
      </div>
      <div className="w-[170px] border-[#ffffff20] border-r text-center ">
        <InputComponent
          key={item.id}
          type="number"
          placeholder="0"
          onChange={(e) => {
            setAmount(
              (x) => (x = parseInt(quantity) * parseInt(e.target.value))
            );
            setRate((x) => (x = e.target.value));

            updateTable(
              designation,
              quantity,
              e.target.value,
              parseInt(e.target.value) * parseInt(quantity)
            );
          }}
          value={item.rate}
          className="h-10 p-0 text-center border-none"
        />
      </div>
      <div className="w-[170px] border-[#ffffff20]   text-center ">
        <InputComponent
          key={item.id}
          readOnly={true}
          value={isNaN(amount) ? 0 : parseInt(amount).toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".")}
          className="h-10 p-0 pr-6 text-center border-none"
        />
      </div>
    </div>
  );
}
