import React, { useEffect, useState } from "react";
import {
  IoIosNotifications,
  IoIosPeople,
  IoIosRefresh,
  IoMdClose,
  IoMdTrash,
} from "react-icons/io";
import ButtonComponent from "../../../../components/UI/ButtonComponent";
import InputComponent from "../../../../components/UI/InputComponent";
import { PiListBulletsFill } from "react-icons/pi";
import FolderComponent from "../../../../components/UI/FolderComponent";
import { FiMoreHorizontal } from "react-icons/fi";
import { MdEditDocument, MdInfo, MdMail } from "react-icons/md";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { useRouter } from "next/router";
import { useNewProjectModal } from "../../../../utils/use-new-project-modal";
import { fetchAllCustomerProject } from "../../../../services/projectService";
import { daysFr } from "../../../../utils/helpers";
import StarRatings from "react-star-ratings";
import {
  addNewFolderUser,
  deleteFolderUser,
  editFolderUser,
  fetchAllFolderUser,
} from "../../../../services/folderUserService";
import { Menu } from "@headlessui/react";
import Select from "react-select";
import InputDropdownComponent from "../../../../components/UI/InputDropdownComponent";
import InputDropdownSexeComponent from "../../../../components/UI/InputDropdownSexeComponent";
import InputDropdownCountryComponent from "../../../../components/UI/InputDropdownCountryComponent";
import { useGlobalModal } from "../../../../utils/use-global-modal";
import { deleteFolder, updateFolder } from "../../../../services/folderService";
import DropdownComponent from "../../../../components/menu/DropdownComponent";
import { RiFileEditLine } from "react-icons/ri";
import DropdownProfileComponent from "../../../../components/menu/DropdownProfileComponent";
import { BsFillTelephoneFill } from "react-icons/bs";
import { BiWorld } from "react-icons/bi";
import { FaFileContract } from "react-icons/fa";
import InputDropdownContractComponent from "../../../../components/UI/InputDropdownContractComponent";
function FolderShow() {
  const [openDrop, setOpenDrop] = useState(false);
  const [dropValue, setDropValue] = useState("");
  const [openDrop2, setOpenDrop2] = useState(false);
  const [dropValue2, setDropValue2] = useState("");
  const [openDropCountry, setOpenDropCountry] = useState(false);
  const [dropValueCountry, setDropValueCountry] = useState("");
  const [currentDocName, setCurrentDocName] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [rating, setRaging] = useState(0);
  const [datas, setDatas] = useState<FolderUser[]>([]);
  const modal = useNewProjectModal();
  const [modalView, setModalView] = useState(false);
  const [modalProfilView, setProfilModalView] = useState(false);
  const router = useRouter();
  const customerInfo = router.query;
  const modalGlobal = useGlobalModal();
  const [modalViewName, setModalViewName] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const options = [
    { value: "chocolate", label: "Chocolate" },
    { value: "strawberry", label: "Strawberry" },
    { value: "vanilla", label: "Vanilla" },
  ];
  const [currentDataShow, setCurrentDataShow] = useState<FolderUser>({
    contact: "",
    country: "",
    name: "",
    email: "",
    function: "",
    indicatif: "",
    rate: "",
    sexe: "",
    poste: "",
    contrat: "",
    birthDate:  null,
  });
  const [customersFiltered, setCustomersFiltered] = useState<FolderUser[]>([])
  const [data, setData] = useState<FolderUser>({
    contact: "",
    country: "",
    name: "",
    email: "",
    function: "",
    indicatif: "",
    rate: "",
    sexe: "",
    poste: "",
    contrat: "",
    birthDate:  null,
  });
  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const fetch = async () => {
    const datas: FolderUser[] = await fetchAllFolderUser(
      customerInfo.id.toString()
    );
    if (datas) {
     // setIsLoading(false);
      setIsLoading(false);
      setDatas(datas);
      setCustomersFiltered(datas);

      setInputValue(customerInfo?.name.toString());
    }
  };

  useEffect(() => {
    fetch();
  }, [modal.isOpen]);
  const [searchValue, setSearchValue] = useState("");

  useEffect(() => {
    const datasFilter = datas.filter((item) =>
      item.name.toLowerCase().includes(searchValue.toLowerCase())
    );
    setCustomersFiltered(datasFilter);
  }, [searchValue]);



  return (
    <div className="flex w-full h-full overflow-x-hidden select-none no-scrollbar">
      {modalView && NewUserModal()}
      {modalViewName && AddNewFolder()}
      {modalProfilView && (
        <div
          onClick={() => {
            setProfilModalView((x) => (x = false));
          }}
          className="absolute inset-0 z-10 flex items-center justify-center bg-black/50"
        >
          <ItemGestionShow
            //  key={item!.id}
            handleClick={() => {}}
            indexType={1}
            item={currentDataShow}
          />
        </div>
      )}

      <div className="flex flex-col w-full h-full ">
        {SearchElement()}
        
        <div
          className={`  "flex-row  flex   pl-16   justify-start w-auto   pr-[120px] ml-2 pt-16  gap-[20px]     overflow-y-scroll flex-wrap      no-scrollbar `}
        >

         


          {isLoading ? 
  <>
  {" "}

  {[1,2,3,4,5,6,7,8,9,10,].map(i=>(  <ShimmerFolderUser key={i}/>))}
 
  
</> :


          customersFiltered.map((item) => (
            <ItemGestion
              key={item!.id}
              handleClick={() => {}}
              indexType={1}
              item={item}
            />
          ))}
          {isLoading == false && (
            <div
              onClick={() => {
                setModalView(true);
              }}
              className="relative cursor-pointer hover:bg-[#ffffff08] text-[11px] text-white/30 justify-center w-[145px] h-[220px] flex  items-center  flex-col rounded-[10px]    border   border-dashed border-white/20          text-[#ffffff]   "
            >
              <div className="text-4xl">+</div>
              <div>Ajouter un profil</div>
            </div>
          )}
        </div>
      </div>

      <div className="min-w-[370px] max-w-[370px]  h-full  border-l-[1px]   via-[#6462462c]  bg-gradient-to-b from-black to-[#64624691]  border-l-[#9a9768]  text-[#ffffff66] text-sm border-opacity-40">
        <div className="w-full relative min-h-[130px] px-12    pr-24 flex items-end pb-6  justify-between   border-b-[1px]  border-white border-opacity-10">
          <div className="flex items-center justify-center space-x-2 ">
            <div className="flex items-center justify-center p-2 text-[25px] font-bold text-white bg-teal-600 rounded-xl w-11 h-11">
              i
            </div>
            <h1 className="text-3xl font-bold text-white">Infos</h1>
          </div>
        </div>
       {isLoading &&  <div className="w-full flex-col relative min-h-[130px] px-12   pr-4 flex items-start pt-10   pb-10     border-b-[1px]  border-white border-opacity-10">
          <h2 className="font-bold text-[21px] text-[#9a9768] h-[15px] max-w-[100px] line-clamp-2 mb-4 rounded-md  animate-pulse duration-100     bg-[#ffffff1f]  min-w-[100px]">
            
          </h2>
          <div className="flex items-center justify-between w-full pr-8">
            <p className="rounded-md  animate-pulse duration-100    bg-[#ffffff1f] h-[10px] w-[180px] "> </p>{" "}
           
          </div>
          <div className="flex items-center justify-between w-full pr-8 mt-3" >
          <p className="rounded-md  animate-pulse duration-100    bg-[#ffffff1f] h-[10px] w-[140px] "> </p>{" "}
           
          </div>
        </div>}
       {!isLoading &&  <div className="w-full flex-col relative min-h-[130px] px-12   pr-4 flex items-start pt-10   pb-10     border-b-[1px]  border-white border-opacity-10">
          <h2 className="font-bold text-[21px] text-[#9a9768] line-clamp-2 mb-4">
            {currentDocName == "" ? customerInfo.name : currentDocName}
          </h2>
          <div className="flex justify-between w-full pr-8">
            <p>Date de création :</p>{" "}
            <p className="text-primary">{daysFr(customerInfo.createdAt)}</p>
          </div>
          <div className="flex justify-between w-full pr-8 mt-0">
            <p>Quantité :</p> <p className="text-primary">{datas.length}</p>
          </div>
        </div>}
        <div className="w-full flex-col relative min-h-[10px] px-12    pr-4 flex items-start pt-4         border-white border-opacity-10"></div>
      
        {datas.length == 0 && (
          <div className="flex items-center justify-center w-full pb-0 mt-10">
            <div className="flex flex-col items-center justify-center leading-[8px]">
              <p className="mb-4 font-bold opacity-50 text-md">Aucun contenu</p>
              <p className="text-[12px] opacity-50 font-light leading-[15px]">
                Ce fichier client ne contient aucun profil,
              </p>
              <p className="text-[12px] opacity-50 font-light leading-[15px]">
                Veuillez cliquez sur le bouton "Ajouter"
              </p>
              <p className="text-[12px] opacity-50 font-light leading-[15px]">
                afin d'en créer un.
              </p>
            </div>
          </div>
        )}

        {isLoading && 
        
        <div className="flex items-center justify-center w-auto mt-[80px] px-14">
       
        
        <ButtonComponent
            label={""}
            onClick={()=>{
              
            }}
            className={` border-none font-bold   h-[60px] text-[15px] w-full    animate-pulse duration-100    bg-[#ffffff1f]  cursor-default `} 
            labelClassName={` text-[16px]   `}
          />
           </div>
          }
        {!isLoading && 
        
        <div className="flex items-center justify-center w-auto mt-[80px] px-14">
       
        
       <ButtonComponent
            handleClick={() => {
              setModalViewName(true);
            }}
            labelClassName="text-[16px]"
            label={"Modifier"}
            className="border-none h-[58px] font-bold  w-full bg-[#ffffff20]"
          />
           </div>
          }
      
        
      </div>
    </div>
  );

  function ShimmerFolderUser() {
    return <div
      onClick={() => {
        setModalView(true);
      } }
      className="relative cursor-default text-[11px] text-white/30 justify-center w-[145px] h-[220px] flex  items-center  flex-col rounded-[10px]      animate-pulse duration-100    bg-[#ffffff1f]         text-[#ffffff]   "
    >


    </div>;
  }

  function NewUserModal() {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center pb-0 transition bg-black/50 ">
        <div
          onClick={() => {
            setData({
              id: "",
              contact: "",
              country: "",
              name: "",
              email: "",
              function: "",
              indicatif: "",
              rate: "",
              sexe: "",
            });
            setModalView(false);
          }}
          className="absolute inset-0 z-30 flex items-center justify-center transition "
        ></div>
        <div className="p-4 py-0 bg-[#323232] z-50 w-[810px] ml-8 px-12 mr-8 pt-10 flex flex-col items-center justify-center text-white rounded-[20px]">
          <div className="flex items-center justify-between w-full">
           
            <h2 className="font-bold text-[21px] mt-2 ">
            
             {data.id ? " Modifier un nouveau profil " : " Ajouter un nouveau profil "}
            </h2>
            <IoMdClose
              onClick={() => {
                setData({
                  id: "",
                  contact: "",
                  country: "",
                  name: "",
                  email: "",
                  function: "",
                  indicatif: "",
                  rate: "",
                  sexe: "",
                });
                setModalView(false);
              }}
              className="w-[24px] h-[24px] opacity-60 mr-0  cursor-pointer "
            />
          </div>

          <div className="grid w-full grid-cols-2 px-0 mt-7 gap-y-1 gap-x-10">
        
            <InputComponent
              key={1}
              name="name"
              value={data.name}
              onChange={handleChange}
              label="Nom et prénom *"
              labelClassName="text-white/40 text-[15px]"
              className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light  border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
            />

            {/* 
             
            */}
            <InputDropdownSexeComponent
              label="Sexe *"
              placeholder="---"
              inputDrop={true}
              readOnly={true}
              openDrop={openDrop}
              onClick={() => {
                setOpenDrop(true);
              }}
              handleClick={(item) => {
                setOpenDrop(false);
                setDropValue(item);
                setData({ ...data, sexe: item });
              }}
              value={dropValue}
              labelClassName="text-white/40 text-[15px]"
              className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100  "
            />
            
    
            {customerInfo.type == "PERSONAL" ? (
              <InputComponent
                key={3}
                name="birthDate" 
                value={data.birthDate == null ? null : new Date(data.birthDate).toISOString().substr(0, 10)}
                
                type="date"
               onChange={handleChange}
                label="Date de naissance *"
                labelClassName="text-white/40 text-[15px]"
                size={51}
                className="rounded-[4px] dark:[color-scheme:dark] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
              />
            ) : (
              <InputComponent
                key={3}
                name="function"
                value={data.function}
                onChange={handleChange}
                label="Fonction / spécialité *"
                labelClassName="text-white/40 text-[15px]"
                className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
              />
            )}
            
            <InputComponent
              key={4}
              name="email"
              value={data.email}
              onChange={handleChange}
              label="Email *"
              labelClassName="text-white/40 text-[15px]"
              className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
            />

            <InputDropdownCountryComponent
              label="Pays *"
              placeholder="---"
              inputDrop={true}
              readOnly={true}
              openDrop={openDropCountry}
              onClick={() => {
                setOpenDropCountry(true);
              }}

              handleClickClose={()=>{
                setOpenDropCountry(false);
                
              }}
              handleClick={(item) => {
                setOpenDropCountry(false);
                setDropValueCountry(item.Name);
                setData({
                  ...data,
                  country: item.Name + "",
                  indicatif: item.Phone + "",
                });

                console.log(data);
              }}
              value={dropValueCountry}
              labelClassName="text-white/40 text-[15px]"
              className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100  "
            />

            {/*   <InputComponent
            key={5}
            name="country"
            value={data.country}
            onChange={handleChange}
              label="Pays"
              labelClassName="text-white/40 text-[15px]"
              
              className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
            /> */}
            <div className="flex space-x-4">
              <div>
                <InputComponent
                  key={6}
                  name="indicatif"
                  value={data.indicatif}
                  readOnly={true}
                  onChange={handleChange}
                  label="Indicatif *"
                  labelClassName="text-white/40 text-[15px]"
                  className="rounded-[4px] mb-0 h-[50px] max-w-[100px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
                />
              </div>
              <InputComponent
                key={7}
                name="contact"
                type="number"
                value={data.contact}
                onChange={handleChange}
                label="Contact *"
                labelClassName="text-white/40 text-[15px]"
                className="rounded-[4px] mb-0 h-[50px] flex-1 text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
              />
            </div>
            {customerInfo.type == "PERSONAL" && (
              <>
                <InputComponent
                  key={12}
                  name="poste"
                  value={data.poste}
                  onChange={handleChange}
                  label="Poste *"
                  labelClassName="text-white/40 text-[15px]"
                  className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light  border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
                />
                 <InputDropdownContractComponent
              label="Contrat *"
              placeholder="---"
              inputDrop={true}
              readOnly={true}
              openDrop={openDrop2}
              onClick={() => {
                setOpenDrop2(true);
              }}
              handleClick={(item) => {
                setOpenDrop2(false);
                setDropValue2(item);
                setData({ ...data, contrat: item });
              }}
              value={dropValue2}
              labelClassName="text-white/40 text-[15px]"
              className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100  "
            />
            
             {/*    <InputComponent
                  key={1}
                  name="contrat"
                  value={data.contrat}
                  onChange={handleChange}
                  label="Type de contrat *"
                  labelClassName="text-white/40 text-[15px]"
                  className="rounded-[4px] mb-0 h-[50px] text-[14px] font-light  border-opacity-20 focus:border-[#ffffff] focus:border-opacity-100 "
                /> */}
              </>
            )}
          </div>

          <div className="flex items-end justify-between w-full mt-[40px] mb-12">
            <StarRatings
            
              starDimension="32px"
              className="w-4 h-4"
              starSpacing="3px"
              rating={rating}
              starEmptyColor="#8F8F8F"
              starHoverColor="#F8DA2F"
              starRatedColor="#F8DA2F"
              changeRating={(rating) => {
                setRaging(rating);

                setData((prevState) => ({
                  ...prevState,
                  rate: rating + "",
                }));
              }}
              numberOfStars={5}
              name="rating"
            />

            <div className="flex items-end self-end justify-center gap-5 ">
              <ButtonComponent
                label={"Annuler"}
                handleClick={() => {
                  setDropValue("---");
                  setDropValue2("---");
                  setDropValueCountry("---");
                  setData({
                    id: "",
                    contact: "",
                    contrat: "",
                    country: "",
                    name: "",
                    email: "",
                    function: "",
                    indicatif: "",
                    rate: "",
                    sexe: "",
                  });
                  setModalView(false);
                  setRaging(0);
                }}
                className="bg-[#ffffff2a]  border-none min-h-[45px] w-[150px] font-bold "
              />
              <ButtonComponent
                handleClick={async () => {

 
                
if(customerInfo.type == "PERSONAL"){
  if (
    data.name.trim().length < 3 ||
    data.country.trim() == "" || 
    data.sexe.trim() == "" ||
    data.poste.trim().length < 3  ||
    data.birthDate == null  ||
    data.email.trim().length < 2  ||
    data.contact.trim().length < 3  ||
    data.contrat.trim() == ""  
    
  ) {
    modalGlobal.onSubmit = (
      <ButtonComponent
        handleClick={async () => {
          modalGlobal.onClose();
        }}
        label={"Ok"}
        className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
      />
    );
    modalGlobal.onOpen();
    modalGlobal.setTitle("Attention !");
    modalGlobal.setMessage(
      "Vous devez remplir tous les champs obligatoires (*) avant de poursuivre."
    );
    return;
  }

}else{
  if (
    data.name.trim().length < 3 ||
    data.country.trim() == "" || 
    data.sexe.trim() == "" ||
    data.email.trim().length < 2  || 
    data.function.trim().length < 3  ||
    data.contact.trim().length < 3    
    
  ) {
    modalGlobal.onSubmit = (
      <ButtonComponent
        handleClick={async () => {
          modalGlobal.onClose();
        }}
        label={"Ok"}
        className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
      />
    );
    modalGlobal.onOpen();
    modalGlobal.setTitle("Attention !");
    modalGlobal.setMessage(
      "Vous devez remplir tous les champs obligatoires (*) avant de poursuivre."
    );
    return;
  }

}

 
             


                  setModalView(false);
                  setIsLoading(true);
                  setDropValue("---");
                  setDropValue2("---");
                  setDropValueCountry("---");
                  setData({
                    contact: "",
                    country: "",
                    name: "",
                    email: "",
                    function: "",
                    indicatif: "",
                    rate: "",
                    sexe: "",
                    poste: "",
                    contrat: "",
                    birthDate: null,
                  });
                  setRaging(0);
                  const dataCome = data.id
                    ? await editFolderUser(data!.id.toString(), data)
                    : await addNewFolderUser(customerInfo!.id.toString(), data);
                  if (dataCome) {
                    fetch();
                  }
                  //     await  postCustomer()
                }}
                label={data.id ? "Modifier" : "Enregistré"}
                className="bg-[#ffffff4b]  border-none min-h-[45px] w-[150px] font-bold "
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  function SearchElement() {
    return (
      <div className="w-full relative min-h-[130px] px-14   pr-24 flex items-end pb-[17px]  justify-between   border-b-[1px]  border-white border-opacity-10">
        <IoIosArrowBack
          onClick={() => {
            router.back();
          }}
          className="absolute w-8 h-8 font-bold cursor-pointer bottom-[25px] left-5"
        />
        <div className="flex items-center space-x-2">
          <h3 className="mb-1 ml-4 text-4xl font-bold">
            {currentDocName == "" ? customerInfo.name : currentDocName}
          </h3>
        </div>
        {isLoading &&   <div className="absolute right-0 flex gap-4 right-10">
     <div className="min-w-[200px] h-8 rounded-full  animate-pulse duration-100    bg-[#ffffff1f] ">  </div>
    
     </div>}
       {!isLoading && <div className="flex">
          <InputComponent
            placeholder="Rechercher"
            value={searchValue}
            onChange={(e) => {
              setSearchValue((x) => (x = e.target.value));
            }}
            className="px-[0px]  border-b-white border-t-transparent border-x-transparent"
          />{" "}
          
          <ButtonComponent
            handleClick={() => {
              setModalView(true);
            }}
            label={"Ajouter"}
            labelClassName="text-[17px]  "
            className="bg-[#ffffff56] text-normal border-none min-h-[35px] min-w-[110px] font-semibold ml-4"
          />
          <DropdownComponent className="absolute items-center justify-between w-6 h-6 gap-2 py-2 mb-1 text-sm font-medium cursor-pointer right-10 top-14 bottom-1 group-hover:block hover:block">
            <Menu.Item>
              {({ active }) => (
                <p
                  onClick={() => {
                    setModalViewName(true);
                  }}
                  className={`  px-2  py-3 flex  justify-start pl-6  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                    active
                      ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                      : " "
                  }`}
                >
                  <RiFileEditLine className="w-6 h-6 " />
                  Modifier le dossier
                </p>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <p
                  onClick={() => {
                    modalGlobal.onSubmit = (
                      <ButtonComponent
                        handleClick={async () => {
                          setIsLoading(true);
                          const data = await deleteFolder(
                            customerInfo!.id.toString()
                          );

                          if (data) {
                            modalGlobal.onClose();
                            router.back();
                          }
                        }}
                        label={"Supprimer"}
                        className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                      />
                    );
                    modalGlobal.onOpen();
                    modalGlobal.setTitle("Êtes-vous sûr ?");
                    modalGlobal.setMessage(
                      "Êtes-vous sûr de vouloir supprimer ce dossier ?"
                    );
                  }}
                  className={`  px-2  py-3 flex  justify-start pl-6  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                    active
                      ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                      : " "
                  }`}
                >
                  <IoMdTrash className="w-6 h-6 " />
                  Supprimer le dossier
                </p>
              )}
            </Menu.Item>
          </DropdownComponent>
          {/* 
          <Menu>
            <Menu.Button className="absolute items-center justify-between w-6 h-6 gap-2 py-2 mb-1 text-sm font-medium cursor-pointer right-10 top-14 bottom-1 group-hover:block hover:block">
              <MdInfo className="w-8 h-8 " />
            </Menu.Button>
            <Menu.Items className=" absolute  top-20   max-w-[220px] rounded-md z-20 right-10  flex flex-col justify-center w-full   bg-[#2b2b2b] ">
              <Menu.Item>
                {({ active }) => (
                  <p
                    onClick={() => {}}
                    className={`  px-2  py-3 flex  justify-start pl-5 items-center gap-2 rounded-md text-sm cursor-pointer ${
                      active ? " bg-[#212121]" : " "
                    }`}
                  >
                    <MdEditDocument className="w-6 h-6 " />
                    Modifier le dossier
                  </p>
                )}
              </Menu.Item>
              <Menu.Item>
                {({ active }) => (
                  <p
                    onClick={() => {
                      modalGlobal.onSubmit = (
                        <ButtonComponent
                          handleClick={async () => {
                            setIsLoading(true);
                            const data = await deleteFolder(
                              customerInfo!.id.toString()
                            );

                            if (data) {
                              modalGlobal.onClose();
                              router.back();
                            }
                          }}
                          label={"Supprimer"}
                          className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                        />
                      );
                      modalGlobal.onOpen();
                      modalGlobal.setTitle("Êtes-vous sûr ?");
                      modalGlobal.setMessage(
                        "Êtes-vous sûr de vouloir supprimer ce dossier ?"
                      );
                    }}
                    className={`  px-2  py-3 flex  justify-start pl-5 items-center gap-2 rounded-md text-sm cursor-pointer ${
                      active ? " bg-[#212121]" : " "
                    }`}
                  >
                    <IoMdTrash className="w-6 h-6 " />
                    Supprimer le dossier
                  </p>
                )}
              </Menu.Item>
            </Menu.Items>
          </Menu> */}
        </div>}
      </div>
    );
  }
  function ItemGestion({ item, indexType, handleClick = () => {} }) {
    /*   INPROGRESS,
    ISVALIDATE,
    ISFINISH */
    let type = {
      border: "",
      color: "",
      label: "",
    };
    switch (item.type) {
      case "INPROGRESS":
        type = {
          border: "border-amber-500 ",
          color: "text-amber-500 ",
          label: "En cours de validation de la proforma",
        };
        break;
      case "ISVALIDATE":
        type = {
          border: "border-green-500 ",
          color: "text-green-500 ",
          label: "Proforma validée",
        };
        break;
      case "ISFINISH":
        type = {
          border: "border-teal-500 ",
          color: "text-teal-500 ",
          label: "Projet terminé",
        };
        break;

      default:
        break;
    }

    return (
      <div
        onClick={handleClick}
        className="relative cursor-pointer w-[145px]   max-h-[220px] min-h-[220px]    flex justify-start pt-4 items-center  flex-col rounded-[10px]  bg-gradient-to-b from-[#626262] to-[#2f2f2f]    text-[15px]        text-[#ffffff]   "
      >
        <DropdownProfileComponent className="absolute items-center justify-between w-6 h-6 gap-2 py-2 mb-1 text-sm font-medium cursor-pointer top-1 bottom-5 group-hover:block hover:block right-1">
          <Menu.Item>
            {({ active }) => (
              <div
                onClick={() => {
                  setData(item);
                  setModalView(true);
                  setDropValue(item.sexe);
                  setDropValue2(item.contrat);
                  setDropValueCountry(item.country);
                  setRaging(parseInt(item.rate == "" ? 0 : item.rate));
                }}
                className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                  active
                    ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                    : " "
                }`}
              >
                <RiFileEditLine className="min-w-10 min-h-10 " />
                Modifier
              </div>
            )}
          </Menu.Item>
          <Menu.Item>
            {({ active }) => (
              <div
                onClick={() => {
                  modalGlobal.onSubmit = (
                    <ButtonComponent
                      handleClick={async () => {
                        setIsLoading(true);
                        const data = await deleteFolderUser(item!.id);

                        if (data) {
                          await fetch();
                          modalGlobal.onClose();
                        }
                      }}
                      label={"Supprimer"}
                      className="max-h-[36px] min-w-[120px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
                    />
                  );
                  modalGlobal.onOpen();
                  modalGlobal.setTitle("Êtes-vous sûr ?");
                  modalGlobal.setMessage(
                    "Êtes-vous sûr de vouloir supprimer ce profil ?"
                  );
                }}
                className={`  px-2  py-2 flex  justify-start pl-4  items-center gap-2   text-[17px] cursor-pointer mx-2 ${
                  active
                    ? " bg-gradient-to-r from-[#44444419] via-[#444444] to-[#4444444a]"
                    : " "
                }`}
              >
                <IoMdTrash className="min-w-10 min-h-10 " />
                Supprimer
              </div>
            )}
          </Menu.Item>
        </DropdownProfileComponent>

        <div className="bg-[#929292] h-[59px]  mt-5 w-[59px] flex justify-center items-center rounded-full">
          <img
            className="h-10 "
            src={`${
              item.sexe == "Homme"
                ? "/images/HommePM.png"
                : "/images/FemmePM.png"
            } `}
          />
        </div>
        <p className="px-2 mt-2 text-sm text-center line-clamp-1 max-w-[145px] overflow-hidden">
          {item.name}
        </p>
        <p className="px-2 text-[11px] text-center opacity-50 line-clamp-1 max-w-[145px] overflow-hidden">
          {customerInfo.type == "PERSONAL" ? item.poste : item.country}
        </p>
        <div
          onClick={() => {
            setProfilModalView(true);
            setCurrentDataShow(item);
          }}
          className="px-4 py-[3px] tracking-tight shadow-md text-white/60 my-2 mb-[3px] rounded-[3px] text-[12px] font-normal bg-[#707070]"
        >
          Voir profil
        </div>
        <StarRatings
          starDimension="14px"
          starSpacing="1px"
          className="w-4 h-4"
          rating={item.rate == "" ? 0 : parseInt(item.rate)}
          starHoverColor="#F8DA2F"
          starRatedColor="#F8DA2F"
          numberOfStars={5}
          name="rating"
        />
      </div>
    );
  }
  function ItemGestionShow({ item, indexType, handleClick = () => {} }) {
    /*   INPROGRESS,
    ISVALIDATE,
    ISFINISH */
    let type = {
      border: "",
      color: "",
      label: "",
    };
    switch (item.type) {
      case "INPROGRESS":
        type = {
          border: "border-amber-500 ",
          color: "text-amber-500 ",
          label: "En cours de validation de la proforma",
        };
        break;
      case "ISVALIDATE":
        type = {
          border: "border-green-500 ",
          color: "text-green-500 ",
          label: "Proforma valider",
        };
        break;
      case "ISFINISH":
        type = {
          border: "border-teal-500 ",
          color: "text-teal-500 ",
          label: "Projet terminer",
        };
        break;

      default:
        break;
    }

    return (
      <div
        onClick={handleClick}
        className="relative cursor-pointer w-[275px] px-1 h-[350px] flex justify-start pt-8 items-center  flex-col rounded-[10px]  bg-gradient-to-b from-[#8a8a8a] to-[#464646]    text-[15px]        text-[#ffffff]   "
      >

 
        <div className="bg-[#a7a7a7] h-[82px]  mt-5 w-[82px] flex justify-center items-center rounded-full">
          <img
            className="h-12 "
            src={`${
              item.sexe == "Homme"
                ? "/images/HommePM.png"
                : "/images/FemmePM.png"
            } `}
          />
        </div>
        <p className="px-2 mt-2 leading-[22px] text-center text-[18px] line-clamp-1">
          {item.name}
        </p>
        <p className="px-2 text-[13px] text-center opacity-50 line-clamp-1">
          {customerInfo.type == "PERSONAL" ? item.poste : item.function}
        </p>

        <StarRatings
          starDimension="19px"
          starSpacing="1px"
          className="w-4 h-4"
          rating={item.rate == "" ? 0 : parseInt(item.rate)}
          starHoverColor="#F8DA2F"
          starRatedColor="#F8DA2F"
          starEmptyColor="#8F8F8F"
          numberOfStars={5}
          name="rating"
        />

        <div className="px-2 gap-2 text-[13px] mt-6 opacity-50 line-clamp-1 w-full  mt-4 flex items-center justify-center">
          <BsFillTelephoneFill className="w-[16px] h-[16px]" /> 
          <p className="text-center line-clamp-1">
            {"+(" + item.indicatif + ")" + item.contact}
          </p>{" "}
        </div>
        <div className="px-2 gap-2 text-[13px] mt-1 opacity-50 line-clamp-2 w-full      flex items-center justify-center">
          <MdMail className="w-[20px] h-[20px] mb-1 " />{" "}
          <p className="mb-1 overflow-y-hidden text-center ">{item.email}</p>{" "}
        </div>
        <div className="px-2 gap-2 text-[13px]  line-clamp-2 w-full     mt-0 flex items-center justify-center">
        {customerInfo.type == "PERSONAL" ?<FaFileContract className="w-[18px] mb-1 h-[18px] opacity-50  " /> :  <BiWorld className="w-[20px] h-[20px] opacity-50  " />}
         
      
          <p className={`mb-0 overflow-y-hidden text-center    `}>
            <span className="opacity-50 ">{customerInfo.type == "PERSONAL" ? "Type de contrat" : "Add"} :</span>{" "}
            <span className={` ${customerInfo.type == "PERSONAL" ? "text-primary" : "opacity-50"}  `}>{customerInfo.type == "PERSONAL" ? item.contrat: item.country}</span>
          </p>
        </div>
      </div>
    );
  }

  function AddNewFolder() {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center pb-0 transition bg-black/40 ">
        <div
          onClick={() => {
            setModalView(false);
            setInputValue("");
          }}
          className="absolute inset-0 z-30 flex items-center justify-center transition "
        ></div>
        <div className="p-4 py-0 bg-[#323232] z-50 w-[434px] px-7 flex flex-col items-center justify-center text-white rounded-xl">
          <IoMdClose
            onClick={() => {
              setModalView(false);
            }}
            className="w-[24px] h-[24px] opacity-60 mr-0 mt-5 cursor-pointer self-end"
          />

          <h2 className="font-bold text-[18px] mb-6 ">
            Modifier le nom du dossier
          </h2>

          <div className="w-full px-2">
            <InputComponent
              key={1}
              value={inputValue}
              onChange={(e) => {
                setInputValue(e.target.value);
              }}
              label="Nom du dossier"
              labelClassName="text-white/40 text-[15px]"
              placeholder="Veuillez entrer le nom du dossier"
              className="rounded-xl mb-0 h-[35px] text-[12px] font-light border-opacity-50"
            />
          </div>

          <div className="flex items-center justify-center w-full gap-4 mb-4">
            <ButtonComponent
              key={2}
              handleClick={async () => {
                setModalViewName(false);
              }}
              label={"Annuler"}
              className="max-h-[32px] min-w-[100px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#484848] border-none  rounded-md"
            />
            {inputValue.trim().length >= 2 && (
              <ButtonComponent
                key={30}
                handleClick={async () => {
                  //  const data = await updateNameProject(project!.id,inputValue)

                  const data = await updateFolder(
                    customerInfo!.id.toString(),
                    inputValue
                  );
                  if (data) {
                    setModalViewName(false);
                    setCurrentDocName(inputValue);
                  }
                }}
                label={"Modifier"}
                className="max-h-[32px] min-w-[100px] mt-6 mb-4 shadow-xl shadow-black/20 bg-[#9a9768] border-none  rounded-md"
              />
            )}
          </div>
        </div>
      </div>
    );
  }
}
/*
 */
export default FolderShow;
