import { create } from 'zustand'
 

 
 const useMenuStore = create((set) => ({
  index: -1,
  setMenuIndex: (i) => set((state) => ({ index:i })),
  removeAllindex: () => set({ index: 0 }),
}))

 

 
export default useMenuStore